--!strict
-- Lighting presets per location, post-processing, rain, graphics-quality
-- scaling and all ambient world animation (holograms, tunnel light chase,
-- showroom turntable, start lights, checkpoint highlight).

local CollectionService = game:GetService("CollectionService")
local Lighting = game:GetService("Lighting")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage.Shared.Config)
local MapDefinitions = require(ReplicatedStorage.Shared.MapDefinitions)
local RaceClient = require(script.Parent.RaceClient)
local Settings = require(script.Parent.Settings)

local RC = Config.Race

local Environment = {}

local atmosphere: Atmosphere
local bloom: BloomEffect
local cc: ColorCorrectionEffect
local sunRays: SunRaysEffect
local dof: DepthOfFieldEffect
local rainPart: Part
local rainEmitter: ParticleEmitter
local currentPreset: MapDefinitions.LightingPreset? = nil

local function ensure<T>(className: string, name: string, parent: Instance): T
	local existing = parent:FindFirstChild(name)
	if existing and existing.ClassName == className then
		return existing :: any
	end
	local inst = Instance.new(className :: any)
	inst.Name = name
	inst.Parent = parent
	return inst :: any
end

local function applyPreset(p: MapDefinitions.LightingPreset, instant: boolean)
	currentPreset = p
	local info = TweenInfo.new(if instant then 0 else 1.4, Enum.EasingStyle.Sine)
	local scale = Settings.preset().BloomScale
	Lighting.ClockTime = p.ClockTime
	TweenService:Create(Lighting, info, {
		Brightness = p.Brightness,
		Ambient = p.Ambient,
		OutdoorAmbient = p.OutdoorAmbient,
		ExposureCompensation = p.ExposureCompensation,
	}):Play()
	TweenService:Create(atmosphere, info, {
		Density = p.AtmosphereDensity,
		Offset = p.AtmosphereOffset,
		Color = p.AtmosphereColor,
		Decay = p.AtmosphereDecay,
		Glare = p.AtmosphereGlare,
		Haze = p.AtmosphereHaze,
	}):Play()
	TweenService:Create(bloom, info, {
		Intensity = p.BloomIntensity * scale,
		Size = p.BloomSize,
		Threshold = p.BloomThreshold,
	}):Play()
	TweenService:Create(cc, info, {
		Brightness = p.CCBrightness,
		Contrast = p.CCContrast,
		Saturation = p.CCSaturation,
		TintColor = p.CCTint,
	}):Play()
	sunRays.Intensity = p.SunRays
	sunRays.Enabled = p.SunRays > 0
end

local function refreshLocation()
	local s = RaceClient.state
	if RaceClient.participating and s then
		local def = MapDefinitions.Maps[s.mapId]
		if def then
			applyPreset(def.lighting, false)
			return
		end
	end
	applyPreset(MapDefinitions.Lobby, false)
end

local function applyQuality()
	local q = Settings.preset()
	local i = 0
	for _, l in CollectionService:GetTagged("DecorLight") do
		if l:IsA("Light") then
			i += 1
			-- deterministic thinning: keep every Nth light
			local keep = q.DecorLightFraction >= 1 or (q.DecorLightFraction > 0 and (i % math.max(1, math.floor(1 / q.DecorLightFraction + 0.5))) == 0)
			l.Enabled = keep
		end
	end
	for _, e in CollectionService:GetTagged("DecorFX") do
		if e:IsA("ParticleEmitter") then
			e.Enabled = q.DecorFx
		end
	end
	rainEmitter.Rate = q.RainRate
	if currentPreset then
		bloom.Intensity = currentPreset.BloomIntensity * q.BloomScale
	end
end

-- ── Ambient animation registries ─────────────────────────────────────────
type Spinner = { model: Model, base: CFrame, pivot: Vector3, speed: number, bob: number }
local spinners: { Spinner } = {}
type Ring = { parts: { BasePart }, pos: Vector3, phase: number, underground: boolean }
local rings: { Ring } = {}
local gradients: { UIGradient } = {}
local pulses: { Model } = {}
local startLights: { [number]: BasePart } = {}
local gates: { [number]: Model } = {}

local function trackTag<T>(tag: string, add: (Instance) -> ())
	for _, inst in CollectionService:GetTagged(tag) do
		add(inst)
	end
	CollectionService:GetInstanceAddedSignal(tag):Connect(add)
end

local function collectParts(m: Instance): { BasePart }
	local list = {}
	for _, d in m:GetDescendants() do
		if d:IsA("BasePart") then
			table.insert(list, d)
		end
	end
	return list
end

local RING_DIM_A = Color3.fromRGB(70, 20, 60)
local RING_DIM_U = Color3.fromRGB(70, 30, 10)
local CP_IDLE = Config.UI.Cyan
local CP_NEXT = Config.UI.Pink

local lastNext = -1
local function highlightGate(nextIndex: number)
	if nextIndex == lastNext then
		return
	end
	lastNext = nextIndex
	for idx, gate in gates do
		if idx ~= 0 then
			local col = if idx == nextIndex then CP_NEXT else CP_IDLE
			for _, d in gate:GetChildren() do
				if d:IsA("BasePart") and d.Material == Enum.Material.Neon then
					d.Color = col
					d.Transparency = if idx == nextIndex then 0 else 0.45
				end
			end
		end
	end
end

local function animate(dt: number)
	local t = os.clock()
	local camPos = Workspace.CurrentCamera.CFrame.Position
	local q = Settings.preset()
	local range = q.AmbientAnimationRange
	local motion = if Settings.reducedMotion then 0.35 else 1

	for _, s in spinners do
		if (s.pivot - camPos).Magnitude < range then
			local angle = t * s.speed * motion
			local bob = math.sin(t * 1.3) * s.bob * motion
			local rot = CFrame.new(s.pivot) * CFrame.Angles(0, angle, 0) * CFrame.new(-s.pivot)
			s.model:PivotTo((rot * s.base) + Vector3.new(0, bob, 0))
		end
	end
	for i, g in gradients do
		g.Offset = Vector2.new(math.sin(t * 0.7 + i) * 0.6 * motion, 0)
	end
	for _, r in rings do
		if (r.pos - camPos).Magnitude < range then
			local wave = (math.sin(t * 7 * motion - r.phase * 0.7) + 1) / 2
			local bright = if r.underground then Color3.fromRGB(255, 130, 40) else (if r.phase % 2 == 0 then Config.UI.Pink else Config.UI.Cyan)
			local col = (if r.underground then RING_DIM_U else RING_DIM_A):Lerp(bright, wave ^ 2)
			for _, p in r.parts do
				p.Color = col
			end
		end
	end
	local pulse = (math.sin(t * 1.6) + 1) / 2
	for _, m in pulses do
		for _, p in m:GetChildren() do
			if p:IsA("BasePart") then
				p.Transparency = 0.1 + pulse * 0.35 * motion
			end
		end
	end

	-- start lights + checkpoint highlight
	local s = RaceClient.state
	if s and s.phase ~= "Idle" then
		local now = RaceClient.now()
		local cdStart = s.goTime - RC.CountdownSeconds
		local lit = 0
		local green = false
		if now >= s.goTime and now < s.goTime + 2.5 then
			green = true
		elseif now >= cdStart and now < s.goTime then
			lit = math.clamp(math.floor((now - cdStart) / (RC.CountdownSeconds / 5)) + 1, 1, 5)
		end
		for order, bulb in startLights do
			if green then
				bulb.Color = Color3.fromRGB(40, 255, 120)
			elseif order <= lit then
				bulb.Color = Color3.fromRGB(255, 30, 50)
			else
				bulb.Color = Color3.fromRGB(60, 10, 14)
			end
		end
	end
	local prog = RaceClient.progress
	if RaceClient.participating and prog and not prog.finished then
		highlightGate(prog.nextCheckpoint)
	else
		highlightGate(-1)
	end

	-- rain follows the camera
	if rainEmitter.Enabled then
		rainPart.CFrame = CFrame.new(camPos + Vector3.new(0, 45, 0))
	end
end

function Environment.init()
	atmosphere = ensure("Atmosphere", "RiftAtmosphere", Lighting)
	bloom = ensure("BloomEffect", "RiftBloom", Lighting)
	cc = ensure("ColorCorrectionEffect", "RiftGrade", Lighting)
	sunRays = ensure("SunRaysEffect", "RiftSunRays", Lighting)
	dof = ensure("DepthOfFieldEffect", "RiftDOF", Lighting)
	dof.Enabled = false
	dof.FarIntensity = 0.35
	dof.FocusDistance = 25
	dof.InFocusRadius = 30
	dof.NearIntensity = 0
	local sky = Lighting:FindFirstChildOfClass("Sky") or Instance.new("Sky")
	sky.StarCount = 3000
	sky.Parent = Lighting

	rainPart = Instance.new("Part")
	rainPart.Name = "RiftRain"
	rainPart.Anchored = true
	rainPart.CanCollide = false
	rainPart.CanQuery = false
	rainPart.CanTouch = false
	rainPart.Transparency = 1
	rainPart.Size = Vector3.new(180, 1, 180)
	rainPart.Parent = Workspace.CurrentCamera
	rainEmitter = Instance.new("ParticleEmitter")
	rainEmitter.Name = "Rain"
	rainEmitter.Texture = "rbxasset://textures/particles/smoke_main.dds"
	rainEmitter.Color = ColorSequence.new(Color3.fromRGB(190, 200, 255))
	rainEmitter.LightEmission = 0.4
	rainEmitter.Orientation = Enum.ParticleOrientation.VelocityParallel
	rainEmitter.Size = NumberSequence.new(0.12)
	rainEmitter.Squash = NumberSequence.new(-2.6)
	rainEmitter.Transparency = NumberSequence.new(0.45)
	rainEmitter.Lifetime = NumberRange.new(0.6, 0.8)
	rainEmitter.Speed = NumberRange.new(95, 115)
	rainEmitter.EmissionDirection = Enum.NormalId.Bottom
	rainEmitter.Acceleration = Vector3.new(4, 0, 2)
	rainEmitter.Enabled = false
	rainEmitter.Parent = rainPart

	-- registries
	trackTag("Spin", function(inst)
		if inst:IsA("Model") then
			local pivot = inst:GetAttribute("Pivot")
			table.insert(spinners, {
				model = inst,
				base = inst:GetPivot(),
				pivot = if typeof(pivot) == "Vector3" then pivot else inst:GetPivot().Position,
				speed = (inst:GetAttribute("SpinSpeed") :: number?) or 0.2,
				bob = (inst:GetAttribute("Bob") :: number?) or 0,
			})
		end
	end)
	trackTag("TunnelRing", function(inst)
		if inst:IsA("Model") then
			table.insert(rings, {
				parts = collectParts(inst),
				pos = inst:GetPivot().Position,
				phase = (inst:GetAttribute("Phase") :: number?) or 0,
				underground = inst:GetAttribute("Underground") == true,
			})
		end
	end)
	trackTag("HoloGradient", function(inst)
		if inst:IsA("UIGradient") then
			table.insert(gradients, inst)
		end
	end)
	trackTag("NeonPulse", function(inst)
		if inst:IsA("Model") then
			table.insert(pulses, inst)
		end
	end)
	trackTag("StartLight", function(inst)
		if inst:IsA("BasePart") then
			startLights[(inst:GetAttribute("Order") :: number?) or 1] = inst
		end
	end)
	trackTag("CheckpointGate", function(inst)
		if inst:IsA("Model") then
			gates[(inst:GetAttribute("CheckpointIndex") :: number?) or 0] = inst
		end
	end)
	trackTag("DecorLight", function()
		applyQuality()
	end)

	applyPreset(MapDefinitions.Lobby, true)
	applyQuality()

	RaceClient.StateChanged:Connect(function()
		refreshLocation()
		local s = RaceClient.state
		local def = s and MapDefinitions.Maps[s.mapId]
		rainEmitter.Enabled = RaceClient.participating and def ~= nil and def.lighting.Rain
		local phase = RaceClient.phase()
		dof.Enabled = (phase == "Intro" or phase == "Results") and Settings.quality ~= "Performance"
	end)
	Settings.Changed:Connect(applyQuality)
end

function Environment.start()
	RunService.PreRender:Connect(animate)
end

return Environment
