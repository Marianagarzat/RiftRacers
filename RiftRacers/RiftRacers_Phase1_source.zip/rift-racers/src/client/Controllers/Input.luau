--!strict
-- Unified driving input: keyboard, gamepad (analog) and touch (custom
-- on-screen controls). Produces one normalised state per frame.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")

local Config = require(ReplicatedStorage.Shared.Config)
local Signal = require(ReplicatedStorage.Shared.Util.Signal)

local UI = Config.UI
local player = Players.LocalPlayer

export type DriveInput = {
	throttle: number, -- -1..1 (negative = brake / reverse)
	steer: number, -- -1..1 (positive = right)
	handbrake: boolean,
	boost: boolean,
	analogSteer: boolean,
}

local Input = {}
Input.RecoverPressed = Signal.new()
Input.CameraPressed = Signal.new()
Input.enabled = false

local gp = { steer = 0, gas = 0, brake = 0, boost = false, drift = false }
local touch = { steer = 0, gas = false, brake = false, boost = false, drift = false }
local touchGui: ScreenGui? = nil

local function deadzone(x: number, dz: number): number
	if math.abs(x) < dz then
		return 0
	end
	return math.sign(x) * (math.abs(x) - dz) / (1 - dz)
end

function Input.read(): DriveInput
	local kbThrottle = 0
	local kbSteer = 0
	local typing = UserInputService:GetFocusedTextBox() ~= nil
	if UserInputService:IsKeyDown(Enum.KeyCode.W) or UserInputService:IsKeyDown(Enum.KeyCode.Up) then
		kbThrottle += 1
	end
	if UserInputService:IsKeyDown(Enum.KeyCode.S) or UserInputService:IsKeyDown(Enum.KeyCode.Down) then
		kbThrottle -= 1
	end
	if UserInputService:IsKeyDown(Enum.KeyCode.D) or UserInputService:IsKeyDown(Enum.KeyCode.Right) then
		kbSteer += 1
	end
	if UserInputService:IsKeyDown(Enum.KeyCode.A) or UserInputService:IsKeyDown(Enum.KeyCode.Left) then
		kbSteer -= 1
	end
	local kbDrift = UserInputService:IsKeyDown(Enum.KeyCode.Space)
	local kbBoost = UserInputService:IsKeyDown(Enum.KeyCode.LeftShift) or UserInputService:IsKeyDown(Enum.KeyCode.RightShift)
	if typing then
		kbThrottle, kbSteer, kbDrift, kbBoost = 0, 0, false, false
	end

	local throttle = kbThrottle + (gp.gas - gp.brake) + ((if touch.gas then 1 else 0) - (if touch.brake then 1 else 0))
	local analog = gp.steer ~= 0 or touch.steer ~= 0
	local steer = kbSteer + gp.steer + touch.steer
	return {
		throttle = math.clamp(throttle, -1, 1),
		steer = math.clamp(steer, -1, 1),
		handbrake = kbDrift or gp.drift or touch.drift,
		boost = kbBoost or gp.boost or touch.boost,
		analogSteer = analog,
	}
end

-- ── Touch controls ───────────────────────────────────────────────────────
local function makeButton(parent: Instance, name: string, text: string, pos: UDim2, size: UDim2, color: Color3): TextButton
	local b = Instance.new("TextButton")
	b.Name = name
	b.AnchorPoint = Vector2.new(0.5, 0.5)
	b.Position = pos
	b.Size = size
	b.BackgroundColor3 = UI.Panel
	b.BackgroundTransparency = 0.25
	b.AutoButtonColor = false
	b.Text = text
	b.TextColor3 = color
	b.TextScaled = true
	b.FontFace = Font.fromEnum(Enum.Font.Michroma)
	b.Parent = parent
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(0.5, 0)
	c.Parent = b
	local s = Instance.new("UIStroke")
	s.Color = color
	s.Thickness = 2
	s.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	s.Parent = b
	local pad = Instance.new("UIPadding")
	pad.PaddingTop = UDim.new(0.3, 0)
	pad.PaddingBottom = UDim.new(0.3, 0)
	pad.PaddingLeft = UDim.new(0.15, 0)
	pad.PaddingRight = UDim.new(0.15, 0)
	pad.Parent = b
	local ar = Instance.new("UIAspectRatioConstraint")
	ar.AspectRatio = 1
	ar.Parent = b
	return b
end

local function holdBinding(button: TextButton, key: "gas" | "brake" | "boost" | "drift")
	local active = 0
	local stroke = button:FindFirstChildOfClass("UIStroke") :: UIStroke
	local function set(on: boolean)
		(touch :: any)[key] = on
		button.BackgroundTransparency = if on then 0 else 0.25
		stroke.Thickness = if on then 4 else 2
	end
	button.InputBegan:Connect(function(io: InputObject)
		if io.UserInputType == Enum.UserInputType.Touch or io.UserInputType == Enum.UserInputType.MouseButton1 then
			active += 1
			set(true)
		end
	end)
	button.InputEnded:Connect(function(io: InputObject)
		if io.UserInputType == Enum.UserInputType.Touch or io.UserInputType == Enum.UserInputType.MouseButton1 then
			active = math.max(0, active - 1)
			if active == 0 then
				set(false)
			end
		end
	end)
end

local function buildTouch()
	local gui = Instance.new("ScreenGui")
	gui.Name = "RiftTouchControls"
	gui.ResetOnSpawn = false
	gui.IgnoreGuiInset = true
	gui.ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets
	gui.DisplayOrder = 5
	gui.Enabled = false
	gui.Parent = player:WaitForChild("PlayerGui")

	-- Steering pad: drag horizontally anywhere in the lower-left zone.
	local pad = Instance.new("Frame")
	pad.Name = "SteerPad"
	pad.BackgroundTransparency = 1
	pad.Position = UDim2.fromScale(0, 0.45)
	pad.Size = UDim2.fromScale(0.42, 0.55)
	pad.Active = true
	pad.Parent = gui
	local track = Instance.new("Frame")
	track.AnchorPoint = Vector2.new(0.5, 0.5)
	track.Position = UDim2.fromScale(0.45, 0.72)
	track.Size = UDim2.new(0.8, 0, 0, 10)
	track.BackgroundColor3 = UI.Panel
	track.BackgroundTransparency = 0.3
	track.Parent = pad
	local tc = Instance.new("UICorner")
	tc.CornerRadius = UDim.new(1, 0)
	tc.Parent = track
	local knob = Instance.new("Frame")
	knob.AnchorPoint = Vector2.new(0.5, 0.5)
	knob.Position = UDim2.fromScale(0.5, 0.5)
	knob.Size = UDim2.fromOffset(64, 64)
	knob.BackgroundColor3 = UI.Cyan
	knob.BackgroundTransparency = 0.2
	knob.Parent = track
	local kc = Instance.new("UICorner")
	kc.CornerRadius = UDim.new(1, 0)
	kc.Parent = knob
	local hint = Instance.new("TextLabel")
	hint.BackgroundTransparency = 1
	hint.AnchorPoint = Vector2.new(0.5, 1)
	hint.Position = UDim2.new(0.45, 0, 0.72, -40)
	hint.Size = UDim2.fromOffset(220, 22)
	hint.Text = "◀  DRAG TO STEER  ▶"
	hint.TextColor3 = UI.TextDim
	hint.TextScaled = true
	hint.FontFace = Font.fromEnum(Enum.Font.BuilderSansBold)
	hint.Parent = pad

	local steerInput: InputObject? = nil
	local startX = 0
	pad.InputBegan:Connect(function(io: InputObject)
		if io.UserInputType == Enum.UserInputType.Touch and not steerInput then
			steerInput = io
			startX = io.Position.X
		end
	end)
	UserInputService.TouchMoved:Connect(function(io: InputObject)
		if io == steerInput then
			local range = math.max(60, track.AbsoluteSize.X * 0.3)
			touch.steer = math.clamp((io.Position.X - startX) / range, -1, 1)
			knob.Position = UDim2.new(0.5 + touch.steer * 0.4, 0, 0.5, 0)
		end
	end)
	UserInputService.TouchEnded:Connect(function(io: InputObject)
		if io == steerInput then
			steerInput = nil
			touch.steer = 0
			knob.Position = UDim2.fromScale(0.5, 0.5)
		end
	end)

	local right = Instance.new("Frame")
	right.Name = "Pedals"
	right.BackgroundTransparency = 1
	right.AnchorPoint = Vector2.new(1, 1)
	right.Position = UDim2.new(1, -16, 1, -16)
	right.Size = UDim2.fromScale(0.36, 0.5)
	right.Parent = gui
	holdBinding(makeButton(right, "Gas", "GAS", UDim2.fromScale(0.78, 0.68), UDim2.fromScale(0.4, 0.4), UI.Cyan), "gas")
	holdBinding(makeButton(right, "Brake", "BRK", UDim2.fromScale(0.38, 0.8), UDim2.fromScale(0.28, 0.28), UI.Danger), "brake")
	holdBinding(makeButton(right, "Drift", "DRIFT", UDim2.fromScale(0.42, 0.42), UDim2.fromScale(0.26, 0.26), UI.Pink), "drift")
	holdBinding(makeButton(right, "Boost", "BOOST", UDim2.fromScale(0.82, 0.22), UDim2.fromScale(0.28, 0.28), UI.Gold), "boost")
	local reset = makeButton(right, "Reset", "RESET", UDim2.fromScale(0.12, 0.45), UDim2.fromScale(0.18, 0.18), UI.TextDim)
	reset.Activated:Connect(function()
		Input.RecoverPressed:Fire()
	end)
	local cam = makeButton(right, "Cam", "CAM", UDim2.fromScale(0.12, 0.15), UDim2.fromScale(0.18, 0.18), UI.TextDim)
	cam.Activated:Connect(function()
		Input.CameraPressed:Fire()
	end)
	touchGui = gui
end

function Input.setEnabled(on: boolean)
	Input.enabled = on
	if touchGui then
		touchGui.Enabled = on and UserInputService.TouchEnabled
	end
	if not on then
		touch.steer, touch.gas, touch.brake, touch.boost, touch.drift = 0, false, false, false, false
	end
end

function Input.init()
	UserInputService.InputBegan:Connect(function(io: InputObject, processed: boolean)
		if processed or not Input.enabled then
			return
		end
		local k = io.KeyCode
		if k == Enum.KeyCode.R or k == Enum.KeyCode.ButtonY then
			Input.RecoverPressed:Fire()
		elseif k == Enum.KeyCode.C or k == Enum.KeyCode.DPadUp then
			Input.CameraPressed:Fire()
		elseif k == Enum.KeyCode.ButtonA then
			gp.boost = true
		elseif k == Enum.KeyCode.ButtonX or k == Enum.KeyCode.ButtonB then
			gp.drift = true
		end
	end)
	UserInputService.InputEnded:Connect(function(io: InputObject)
		local k = io.KeyCode
		if k == Enum.KeyCode.ButtonA then
			gp.boost = false
		elseif k == Enum.KeyCode.ButtonX or k == Enum.KeyCode.ButtonB then
			gp.drift = false
		elseif k == Enum.KeyCode.ButtonR2 then
			gp.gas = 0
		elseif k == Enum.KeyCode.ButtonL2 then
			gp.brake = 0
		elseif k == Enum.KeyCode.Thumbstick1 then
			gp.steer = 0
		end
	end)
	UserInputService.InputChanged:Connect(function(io: InputObject)
		local k = io.KeyCode
		if k == Enum.KeyCode.Thumbstick1 then
			gp.steer = deadzone(io.Position.X, 0.15)
		elseif k == Enum.KeyCode.ButtonR2 then
			gp.gas = io.Position.Z
		elseif k == Enum.KeyCode.ButtonL2 then
			gp.brake = io.Position.Z
		end
	end)
	UserInputService.GamepadDisconnected:Connect(function()
		gp.steer, gp.gas, gp.brake, gp.boost, gp.drift = 0, 0, 0, false, false
	end)
	if UserInputService.TouchEnabled then
		buildTouch()
	end
end

return Input
