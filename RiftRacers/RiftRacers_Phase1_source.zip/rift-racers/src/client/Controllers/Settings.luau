--!strict
-- Client-side player settings (graphics preset, reduced motion, camera).
-- Session-only in Phase 1; Phase 2's profile will persist them.

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")
local Config = require(ReplicatedStorage.Shared.Config)
local Signal = require(ReplicatedStorage.Shared.Util.Signal)

export type CameraMode = "Chase" | "Close" | "Hood"

local Settings = {}

local touchOnly = UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled

Settings.quality = (if touchOnly then "Performance" else "Ultra") :: Config.QualityName
Settings.reducedMotion = false
Settings.cameraMode = "Chase" :: CameraMode
Settings.Changed = Signal.new()

function Settings.preset(): Config.QualityPreset
	return (Config.Quality :: any)[Settings.quality]
end

function Settings.setQuality(q: Config.QualityName)
	Settings.quality = q
	Settings.Changed:Fire()
end

function Settings.setReducedMotion(on: boolean)
	Settings.reducedMotion = on
	Settings.Changed:Fire()
end

local CAMERA_ORDER: { CameraMode } = { "Chase", "Close", "Hood" }
function Settings.setCamera(mode: CameraMode)
	Settings.cameraMode = mode
	Settings.Changed:Fire()
end
function Settings.cycleCamera()
	local i = table.find(CAMERA_ORDER, Settings.cameraMode) or 1
	Settings.setCamera(CAMERA_ORDER[(i % #CAMERA_ORDER) + 1])
end

return Settings
