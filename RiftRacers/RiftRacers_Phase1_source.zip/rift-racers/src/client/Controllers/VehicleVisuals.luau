--!strict
-- Purely visual animation for EVERY race car (yours and opponents'):
-- suspension travel, wheel spin, steering, brake lights, drift smoke,
-- skid trails, boost flames, headlight quality. Runs locally on each client,
-- so it costs zero network traffic.

local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage.Shared.Config)
local RaceClient = require(script.Parent.RaceClient)
local Vehicle = require(script.Parent.Vehicle)
local Settings = require(script.Parent.Settings)

local V = Config.Vehicle

type WheelState = { motor: Motor6D, offset: Vector3, spin: number, y: number, front: boolean }
type CarState = {
	model: Model,
	chassis: BasePart,
	wheels: { WheelState },
	tail: BasePart?,
	brakeGlow: PointLight?,
	smoke: { ParticleEmitter },
	trails: { Trail },
	flames: { ParticleEmitter },
	beams: { SpotLight },
	lastFwd: number,
	brakeTimer: number,
}

local VehicleVisuals = {}

local cars: { [Model]: CarState } = {}
local rayParams = RaycastParams.new()
rayParams.FilterType = Enum.RaycastFilterType.Exclude
rayParams.CollisionGroup = "RiftWheelRay"

local function applyQuality(state: CarState)
	local q = Settings.preset()
	for _, b in state.beams do
		b.Enabled = q.CarHeadlightSpots
	end
end

local function register(inst: Instance)
	if not inst:IsA("Model") or cars[inst] then
		return
	end
	local model = inst
	local chassis = model:WaitForChild("Chassis", 5)
	if not chassis or not chassis:IsA("BasePart") or not model.Parent then
		return
	end
	local state: CarState = {
		model = model,
		chassis = chassis,
		wheels = {},
		tail = nil,
		brakeGlow = nil,
		smoke = {},
		trails = {},
		flames = {},
		beams = {},
		lastFwd = 0,
		brakeTimer = 0,
	}
	for name, off in V.WheelOffsets do
		local motor = chassis:WaitForChild(tostring(name) .. "Motor", 5)
		if motor and motor:IsA("Motor6D") then
			table.insert(state.wheels, {
				motor = motor,
				offset = off :: Vector3,
				spin = 0,
				y = -1.1,
				front = string.sub(tostring(name), 1, 1) == "F",
			})
		end
	end
	local lights = model:FindFirstChild("Lights")
	if lights then
		local tail = lights:FindFirstChild("Taillights")
		if tail and tail:IsA("BasePart") then
			state.tail = tail
			state.brakeGlow = tail:FindFirstChild("BrakeGlow") :: PointLight?
		end
		for _, d in lights:GetDescendants() do
			if d:IsA("SpotLight") then
				table.insert(state.beams, d)
			end
		end
	end
	for _, d in chassis:GetDescendants() do
		if d:IsA("ParticleEmitter") then
			if d.Name == "DriftSmoke" then
				table.insert(state.smoke, d)
			elseif d.Name == "BoostFlame" then
				table.insert(state.flames, d)
			end
		elseif d:IsA("Trail") then
			table.insert(state.trails, d)
		end
	end
	applyQuality(state)
	cars[model] = state
end

local function unregister(inst: Instance)
	if inst:IsA("Model") then
		cars[inst] = nil
	end
end

local function update(dt: number)
	local camPos = Workspace.CurrentCamera.CFrame.Position
	local myCar = RaceClient.car
	local tel = Vehicle.telemetry
	local q = Settings.preset()
	local rayLen = V.RestLength + V.WheelRadius
	dt = math.min(dt, 0.1)

	for model, s in cars do
		local chassis = s.chassis
		if not chassis.Parent then
			cars[model] = nil
			continue
		end
		local cf = chassis.CFrame
		if (cf.Position - camPos).Magnitude > 450 then
			continue
		end
		local vel = chassis.AssemblyLinearVelocity
		local fwd = vel:Dot(cf.LookVector)
		local side = vel:Dot(cf.RightVector)
		local mine = model == myCar

		-- steering estimate
		local steerAngle: number
		if mine then
			steerAngle = -tel.steer * math.rad(26)
		else
			local yaw = chassis.AssemblyAngularVelocity:Dot(cf.UpVector)
			steerAngle = math.clamp(math.atan(yaw * 9.3 / math.max(math.abs(fwd), 8)), -0.45, 0.45) * (if fwd >= 0 then 1 else -1)
		end

		rayParams.FilterDescendantsInstances = { model }
		local groundedCount = 0
		for _, w in s.wheels do
			local origin = cf:PointToWorldSpace(w.offset)
			local hit = Workspace:Raycast(origin, -cf.UpVector * rayLen, rayParams)
			local targetY: number
			if hit then
				groundedCount += 1
				targetY = -(hit.Distance - V.WheelRadius)
			else
				targetY = -V.RestLength
			end
			w.y += (targetY - w.y) * math.min(1, 25 * dt)
			w.spin = (w.spin - fwd * dt / V.WheelRadius) % (math.pi * 2)
			local steer = if w.front then steerAngle else 0
			w.motor.Transform = CFrame.new(0, w.y + 1.1, 0) * CFrame.Angles(0, steer, 0) * CFrame.Angles(w.spin, 0, 0)
		end

		-- brake lights
		local braking: boolean
		if mine then
			braking = tel.braking or (tel.throttle < -0.05 and tel.speed > 2)
		else
			local decel = (s.lastFwd - fwd) / math.max(dt, 1e-3)
			if decel > 45 and fwd > 5 then
				s.brakeTimer = 0.25
			end
			s.brakeTimer -= dt
			braking = s.brakeTimer > 0
		end
		s.lastFwd = fwd
		if s.tail then
			s.tail.Transparency = if braking then 0 else 0.35
		end
		if s.brakeGlow then
			s.brakeGlow.Brightness = if braking then 3 else 0.6
			s.brakeGlow.Range = if braking then 16 else 10
		end

		-- drift smoke + skid trails
		local grounded = groundedCount >= 2
		local drifting = if mine then tel.drifting else (grounded and math.abs(side) > 16 and math.abs(fwd) > 25)
		local sliding = grounded and (drifting or math.abs(side) > 22)
		for _, e in s.smoke do
			e.Rate = if sliding then q.DriftSmokeRate else 0
		end
		for _, tr in s.trails do
			tr.Enabled = sliding
		end

		-- boost flames
		local boosting = if mine then tel.boosting else fwd > V.TopSpeed + 3
		for _, f in s.flames do
			f.Rate = if boosting then 90 else 0
		end
	end
end

function VehicleVisuals.init()
	for _, inst in CollectionService:GetTagged("RiftCar") do
		task.spawn(register, inst)
	end
	CollectionService:GetInstanceAddedSignal("RiftCar"):Connect(function(inst)
		task.spawn(register, inst)
	end)
	CollectionService:GetInstanceRemovedSignal("RiftCar"):Connect(unregister)
	Settings.Changed:Connect(function()
		for _, s in cars do
			applyQuality(s)
		end
	end)
end

function VehicleVisuals.start()
	RunService.PreRender:Connect(update)
end

return VehicleVisuals
