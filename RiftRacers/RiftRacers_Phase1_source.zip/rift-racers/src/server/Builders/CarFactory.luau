--!strict
-- Builds the Phase 1 hero car: "RIFT VX-1", an original wedge-profile
-- futuristic coupe assembled from parts.
--
-- PROTOTYPE GEOMETRY: every visual piece is a separately named part on a
-- named slot so that Phase 3 can swap each one for an imported MeshPart
-- (with SurfaceAppearance) without touching gameplay code. Physics only ever
-- uses the invisible "Chassis" box; all visuals are massless and non-colliding.

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Config = require(ReplicatedStorage.Shared.Config)
local Style = require(script.Parent.Style)

local V = Config.Vehicle

export type CarOptions = {
	name: string,
	paint: Color3,
	accent: Color3,
	anchored: boolean?,
}

local CarFactory = {}

local CARBON = Color3.fromRGB(22, 22, 28)
local TIRE = Color3.fromRGB(18, 18, 20)
local CHROME = Color3.fromRGB(200, 205, 215)

local function weldTo(root: BasePart, p: BasePart)
	local w = Instance.new("WeldConstraint")
	w.Part0 = root
	w.Part1 = p
	w.Parent = p
end

local function visual(model: Model, root: BasePart, slot: Instance, spec: Style.PartSpec): BasePart
	spec.collide = false
	spec.query = false
	spec.anchored = false
	spec.cframe = root.CFrame * spec.cframe
	spec.parent = slot
	local p = Style.part(spec)
	p.Massless = true
	weldTo(root, p)
	return p
end

local function slotFolder(model: Model, name: string): Model
	local m = Instance.new("Model")
	m.Name = name
	m.Parent = model
	return m
end

local function emitter(parent: Instance, props: { [string]: any }): ParticleEmitter
	local e = Instance.new("ParticleEmitter")
	for k, v in props do
		(e :: any)[k] = v
	end
	e.Parent = parent
	return e
end

local function buildWheel(model: Model, root: BasePart, name: string, offset: Vector3, accent: Color3, isRight: boolean)
	local slot = model:FindFirstChild("Wheels") or slotFolder(model, "Wheels")
	local restCf = root.CFrame * CFrame.new(offset.X, -1.1, offset.Z)
	local tire = Style.part({
		name = name,
		size = Vector3.new(1.4, V.WheelRadius * 2, V.WheelRadius * 2),
		cframe = restCf,
		shape = Enum.PartType.Cylinder,
		color = TIRE,
		material = Enum.Material.Rubber,
		collide = false,
		query = false,
		anchored = false,
		parent = slot,
	})
	tire.Massless = true
	local side = if isRight then 1 else -1
	local rim = Style.part({
		name = "Rim",
		size = Vector3.new(1.46, 2.25, 2.25),
		cframe = restCf * CFrame.new(side * 0.02, 0, 0),
		shape = Enum.PartType.Cylinder,
		color = CHROME,
		material = Enum.Material.Metal,
		reflectance = 0.15,
		collide = false,
		query = false,
		anchored = false,
		parent = tire,
	})
	rim.Massless = true
	weldTo(tire, rim)
	for i = 0, 2 do
		local spoke = Style.part({
			name = "Spoke",
			size = Vector3.new(1.5, 2.15, 0.28),
			cframe = restCf * CFrame.Angles(i * math.pi / 3, 0, 0),
			color = CARBON,
			material = Enum.Material.Metal,
			collide = false,
			query = false,
			anchored = false,
			parent = tire,
		})
		spoke.Massless = true
		weldTo(tire, spoke)
	end
	local hub = Style.part({
		name = "RimAccent",
		size = Vector3.new(1.55, 0.7, 0.7),
		cframe = restCf,
		shape = Enum.PartType.Cylinder,
		color = accent,
		material = Enum.Material.Neon,
		collide = false,
		query = false,
		anchored = false,
		castShadow = false,
		parent = tire,
	})
	hub.Massless = true
	weldTo(tire, hub)

	local motor = Instance.new("Motor6D")
	motor.Name = name .. "Motor"
	motor.Part0 = root
	motor.Part1 = tire
	motor.C0 = CFrame.new(offset.X, -1.1, offset.Z)
	motor.C1 = CFrame.identity
	motor.Parent = root
end

function CarFactory.build(opts: CarOptions): Model
	local model = Instance.new("Model")
	model.Name = opts.name

	-- Physics root: the only part that collides and has mass.
	local chassis = Instance.new("Part")
	chassis.Name = "Chassis"
	chassis.Size = Vector3.new(7, 1.6, 14)
	chassis.CFrame = CFrame.new()
	chassis.Transparency = 1
	chassis.CanCollide = true
	chassis.CanQuery = false
	chassis.CanTouch = false
	chassis.Anchored = opts.anchored == true
	chassis.RootPriority = 100
	chassis.CustomPhysicalProperties = PhysicalProperties.new(0.55, 0, 0, 100, 100)
	chassis.Parent = model
	model.PrimaryPart = chassis

	local paint = opts.paint
	local accent = opts.accent

	-- ── BODY ─────────────────────────────────────────────────────────────
	local body = slotFolder(model, "Body")
	local function paintPart(spec: Style.PartSpec): BasePart
		spec.color = spec.color or paint
		spec.material = spec.material or Enum.Material.SmoothPlastic
		spec.reflectance = spec.reflectance or 0.18
		return visual(model, chassis, body, spec)
	end
	paintPart({ name = "LowerBody", size = Vector3.new(7.2, 1.5, 13.6), cframe = CFrame.new(0, -0.05, 0.1) })
	paintPart({ name = "Waist", size = Vector3.new(6.9, 0.6, 7.2), cframe = CFrame.new(0, 0.95, 1.2) })
	-- Fender flares (wide-body stance)
	for _, x in { -3.55, 3.55 } do
		for _, z in { -4.6, 4.7 } do
			paintPart({ name = "Fender", size = Vector3.new(0.7, 1.1, 3.9), cframe = CFrame.new(x, 0.35, z) })
		end
	end
	-- Nose: long sloping wedge, slope faces forward (-Z)
	paintPart({ name = "Hood", wedge = true, size = Vector3.new(6.9, 1.0, 5.2), cframe = CFrame.new(0, 1.2, -4.25) })
	-- Rear deck slopes toward the tail
	paintPart({
		name = "RearDeck",
		wedge = true,
		size = Vector3.new(6.9, 0.8, 2.4),
		cframe = CFrame.new(0, 1.65, 5.2) * CFrame.Angles(0, math.pi, 0),
	})

	-- ── WINDOWS ──────────────────────────────────────────────────────────
	local windows = slotFolder(model, "Windows")
	local GLASS = Color3.fromRGB(12, 14, 30)
	local function glass(spec: Style.PartSpec)
		spec.color = GLASS
		spec.material = Enum.Material.Glass
		spec.transparency = 0.15
		spec.reflectance = 0.25
		visual(model, chassis, windows, spec)
	end
	glass({ name = "Cabin", size = Vector3.new(5.6, 1.2, 3.6), cframe = CFrame.new(0, 1.85, 1.2) })
	glass({ name = "Windshield", wedge = true, size = Vector3.new(5.6, 1.2, 3.0), cframe = CFrame.new(0, 1.85, -2.1) })
	glass({
		name = "RearWindow",
		wedge = true,
		size = Vector3.new(5.6, 1.2, 1.6),
		cframe = CFrame.new(0, 1.85, 3.8) * CFrame.Angles(0, math.pi, 0),
	})
	paintPart({ name = "Roof", size = Vector3.new(5.2, 0.22, 3.4), cframe = CFrame.new(0, 2.5, 1.2), reflectance = 0.22 })

	-- ── AERO / CARBON ────────────────────────────────────────────────────
	local aero = slotFolder(model, "Aero")
	local function carbon(spec: Style.PartSpec)
		spec.color = spec.color or CARBON
		spec.material = spec.material or Enum.Material.SmoothPlastic
		visual(model, chassis, aero, spec)
	end
	carbon({ name = "FrontSplitter", size = Vector3.new(7.6, 0.22, 1.4), cframe = CFrame.new(0, -0.8, -7.0) })
	carbon({ name = "Grille", size = Vector3.new(4.2, 0.55, 0.25), cframe = CFrame.new(0, -0.25, -6.95) })
	carbon({ name = "RearDiffuser", size = Vector3.new(6.2, 0.5, 1.1), cframe = CFrame.new(0, -0.6, 7.1) })
	for _, x in { -1.8, -0.6, 0.6, 1.8 } do
		carbon({ name = "DiffuserFin", size = Vector3.new(0.12, 0.6, 1.0), cframe = CFrame.new(x, -0.65, 7.25) })
	end
	for _, x in { -3.75, 3.75 } do
		carbon({ name = "SideSkirt", size = Vector3.new(0.35, 0.45, 8.8), cframe = CFrame.new(x, -0.62, 0.05) })
	end

	-- ── SPOILER ──────────────────────────────────────────────────────────
	local spoiler = slotFolder(model, "Spoiler")
	visual(model, chassis, spoiler, {
		name = "Wing",
		size = Vector3.new(7.2, 0.22, 1.7),
		cframe = CFrame.new(0, 3.05, 6.2) * CFrame.Angles(math.rad(-6), 0, 0),
		color = CARBON,
	})
	visual(model, chassis, spoiler, {
		name = "WingEdge",
		size = Vector3.new(7.2, 0.08, 0.2),
		cframe = CFrame.new(0, 3.15, 5.4),
		color = accent,
		material = Enum.Material.Neon,
		castShadow = false,
	})
	for _, x in { -2.2, 2.2 } do
		visual(model, chassis, spoiler, {
			name = "Stand",
			size = Vector3.new(0.22, 1.3, 0.6),
			cframe = CFrame.new(x, 2.35, 6.3),
			color = CARBON,
		})
	end
	for _, x in { -3.65, 3.65 } do
		visual(model, chassis, spoiler, {
			name = "EndPlate",
			size = Vector3.new(0.18, 0.9, 1.9),
			cframe = CFrame.new(x, 3.0, 6.2),
			color = paint,
			reflectance = 0.18,
		})
	end

	-- ── LIGHTS ───────────────────────────────────────────────────────────
	local lights = slotFolder(model, "Lights")
	for _, x in { -2.45, 2.45 } do
		local hl = visual(model, chassis, lights, {
			name = "Headlight",
			size = Vector3.new(1.9, 0.22, 0.3),
			cframe = CFrame.new(x, 0.55, -6.9) * CFrame.Angles(0, 0, math.rad(if x < 0 then 6 else -6)),
			color = Color3.fromRGB(220, 240, 255),
			material = Enum.Material.Neon,
			castShadow = false,
		})
		local spot = Instance.new("SpotLight")
		spot.Face = Enum.NormalId.Front
		spot.Range = 60
		spot.Angle = 55
		spot.Brightness = 2.2
		spot.Color = Color3.fromRGB(215, 235, 255)
		spot.Shadows = false
		spot.Name = "Beam"
		spot.Parent = hl
		-- DRL "eyebrow" in accent colour
		visual(model, chassis, lights, {
			name = "DRL",
			size = Vector3.new(1.5, 0.1, 0.25),
			cframe = CFrame.new(x * 1.02, 0.85, -6.75),
			color = accent,
			material = Enum.Material.Neon,
			castShadow = false,
		})
	end
	local tail = visual(model, chassis, lights, {
		name = "Taillights",
		size = Vector3.new(6.6, 0.28, 0.2),
		cframe = CFrame.new(0, 0.6, 6.95),
		color = Color3.fromRGB(255, 30, 60),
		material = Enum.Material.Neon,
		castShadow = false,
	})
	tail.Transparency = 0.35
	local tailLight = Instance.new("PointLight")
	tailLight.Name = "BrakeGlow"
	tailLight.Color = Color3.fromRGB(255, 30, 60)
	tailLight.Range = 10
	tailLight.Brightness = 0.6
	tailLight.Shadows = false
	tailLight.Parent = tail

	-- Side accent lines
	for _, x in { -3.62, 3.62 } do
		visual(model, chassis, lights, {
			name = "SideLine",
			size = Vector3.new(0.06, 0.12, 9.5),
			cframe = CFrame.new(x, 0.45, 0.2),
			color = accent,
			material = Enum.Material.Neon,
			castShadow = false,
		})
	end

	-- ── UNDERGLOW ────────────────────────────────────────────────────────
	local under = slotFolder(model, "Underglow")
	local glow = visual(model, chassis, under, {
		name = "Strip",
		size = Vector3.new(5.6, 0.1, 10.5),
		cframe = CFrame.new(0, -0.82, 0),
		color = accent,
		material = Enum.Material.Neon,
		transparency = 0.15,
		castShadow = false,
	})
	local ugLight = Instance.new("PointLight")
	ugLight.Name = "UnderLight"
	ugLight.Color = accent
	ugLight.Range = 13
	ugLight.Brightness = 2.2
	ugLight.Shadows = false
	ugLight.Parent = glow

	-- ── EXHAUST ──────────────────────────────────────────────────────────
	local exhaust = slotFolder(model, "Exhaust")
	for _, x in { -1.35, 1.35 } do
		visual(model, chassis, exhaust, {
			name = "Tip",
			size = Vector3.new(0.9, 0.62, 0.62),
			cframe = CFrame.new(x, -0.45, 7.35) * CFrame.Angles(0, math.pi / 2, 0),
			shape = Enum.PartType.Cylinder,
			color = CHROME,
			material = Enum.Material.Metal,
			reflectance = 0.2,
		})
		local att = Instance.new("Attachment")
		att.Name = if x < 0 then "ExhaustL" else "ExhaustR"
		att.CFrame = CFrame.new(x, -0.45, 7.85) * CFrame.Angles(math.rad(90), 0, 0) -- +Y → +Z (backwards)
		att.Parent = chassis
		emitter(att, {
			Name = "BoostFlame",
			Texture = "rbxasset://textures/particles/fire_main.dds",
			Color = ColorSequence.new(Color3.fromRGB(120, 230, 255), accent),
			LightEmission = 1,
			Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.9), NumberSequenceKeypoint.new(1, 0.1) }),
			Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(1, 1) }),
			Lifetime = NumberRange.new(0.08, 0.18),
			Speed = NumberRange.new(16, 24),
			SpreadAngle = Vector2.new(6, 6),
			Rate = 0,
			LockedToPart = true,
		})
		emitter(att, {
			Name = "IdleSmoke",
			Texture = "rbxasset://textures/particles/smoke_main.dds",
			Color = ColorSequence.new(Color3.fromRGB(120, 110, 140)),
			Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.3), NumberSequenceKeypoint.new(1, 1.4) }),
			Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.75), NumberSequenceKeypoint.new(1, 1) }),
			Lifetime = NumberRange.new(0.6, 1.0),
			Speed = NumberRange.new(2, 4),
			Rate = 5,
		})
	end

	-- ── DRIFT FX (attachments on chassis, near rear contact patches) ────
	for _, wheel in { "RL", "RR" } do
		local off = V.WheelOffsets[wheel] :: Vector3
		local groundY = -(V.RestLength + V.WheelRadius - V.RestCompression) + 0.1
		local smoke = Instance.new("Attachment")
		smoke.Name = "Smoke" .. wheel
		smoke.Position = Vector3.new(off.X, groundY + 0.4, off.Z + 0.6)
		smoke.Parent = chassis
		emitter(smoke, {
			Name = "DriftSmoke",
			Texture = "rbxasset://textures/particles/smoke_main.dds",
			Color = ColorSequence.new(Color3.fromRGB(230, 225, 255), accent:Lerp(Color3.new(1, 1, 1), 0.5)),
			Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1.2), NumberSequenceKeypoint.new(1, 6) }),
			Transparency = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 0.55),
				NumberSequenceKeypoint.new(0.6, 0.8),
				NumberSequenceKeypoint.new(1, 1),
			}),
			Lifetime = NumberRange.new(0.9, 1.6),
			Speed = NumberRange.new(3, 7),
			SpreadAngle = Vector2.new(35, 35),
			RotSpeed = NumberRange.new(-60, 60),
			Rotation = NumberRange.new(0, 360),
			Drag = 2,
			Rate = 0,
		})
		local a0 = Instance.new("Attachment")
		a0.Name = "Skid" .. wheel .. "A"
		a0.Position = Vector3.new(off.X - 0.6, groundY, off.Z)
		a0.Parent = chassis
		local a1 = Instance.new("Attachment")
		a1.Name = "Skid" .. wheel .. "B"
		a1.Position = Vector3.new(off.X + 0.6, groundY, off.Z)
		a1.Parent = chassis
		local trail = Instance.new("Trail")
		trail.Name = "SkidTrail" .. wheel
		trail.Attachment0 = a0
		trail.Attachment1 = a1
		trail.Color = ColorSequence.new(accent)
		trail.LightEmission = 0.7
		trail.Transparency = NumberSequence.new(0.35, 1)
		trail.Lifetime = 1.4
		trail.MinLength = 0.3
		trail.FaceCamera = false
		trail.Enabled = false
		trail.Parent = chassis
	end

	-- ── WHEELS ───────────────────────────────────────────────────────────
	for name, off in V.WheelOffsets do
		buildWheel(model, chassis, name :: string, off :: Vector3, accent, (off :: Vector3).X > 0)
	end

	-- ── DRIVER SEAT (driver is hidden by tinted glass) ──────────────────
	local seat = Instance.new("Seat")
	seat.Name = "DriverSeat"
	seat.Size = Vector3.new(2, 0.4, 2)
	seat.CFrame = chassis.CFrame * CFrame.new(-1.2, 0.2, 1.0)
	seat.Transparency = 1
	seat.CanCollide = false
	seat.CanQuery = false
	seat.CanTouch = false -- only the server seats players, via Seat:Sit()
	seat.Massless = true
	seat.Anchored = false
	seat.Parent = model
	weldTo(chassis, seat)

	model:SetAttribute("Paint", paint)
	model:SetAttribute("Accent", accent)
	return model
end

return CarFactory
