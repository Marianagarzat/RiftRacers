--!strict
-- THE NEXUS — Phase 1 lobby. Procedural prototype geometry with a coherent
-- art direction (dusk violet sky, cyan/pink neon, dark glossy architecture).
-- Garage / Box Shop pavilions are built as closed structures and clearly
-- labelled for their phase: no fake interactive buttons.

local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Config = require(ReplicatedStorage.Shared.Config)
local Style = require(script.Parent.Style)
local CarFactory = require(script.Parent.CarFactory)

local UI = Config.UI

export type LobbyHandles = {
	model: Folder,
	spawn: SpawnLocation,
	portalPrompt: ProximityPrompt,
	winnerRows: { TextLabel },
	statusLabel: TextLabel,
}

local LobbyBuilder = {}

local FLOOR = Color3.fromRGB(16, 15, 26)
local DARK = Color3.fromRGB(22, 20, 36)
local METAL = Color3.fromRGB(46, 44, 64)

local function pavilion(parent: Instance, cf: CFrame, title: string, subtitle: string, color: Color3)
	local m = Instance.new("Model")
	m.Name = title:gsub("%s", "")
	m.Parent = parent
	-- shell
	Style.part({ name = "Base", size = Vector3.new(56, 2, 34), cframe = cf * CFrame.new(0, 1, 0), color = METAL, material = Enum.Material.Metal, parent = m })
	Style.part({ name = "BackWall", size = Vector3.new(56, 28, 2), cframe = cf * CFrame.new(0, 15, 16), color = DARK, parent = m })
	for _, x in { -27, 27 } do
		Style.part({ name = "SideWall", size = Vector3.new(2, 28, 34), cframe = cf * CFrame.new(x, 15, 0), color = DARK, parent = m })
	end
	Style.part({ name = "Roof", size = Vector3.new(60, 2, 40), cframe = cf * CFrame.new(0, 30, 1), color = METAL, material = Enum.Material.Metal, parent = m })
	-- closed shutter (front)
	Style.part({ name = "Shutter", size = Vector3.new(48, 24, 0.6), cframe = cf * CFrame.new(0, 14, -15), color = Color3.fromRGB(34, 34, 48), material = Enum.Material.DiamondPlate, parent = m })
	for i = 0, 5 do
		Style.neon("ShutterLine", Vector3.new(48, 0.15, 0.2), cf * CFrame.new(0, 4 + i * 4, -15.4), color, m, 0.55)
	end
	-- neon frame
	Style.neon("FrameTop", Vector3.new(52, 0.5, 0.5), cf * CFrame.new(0, 27, -16.5), color, m)
	for _, x in { -25.5, 25.5 } do
		Style.neon("FrameSide", Vector3.new(0.5, 26, 0.5), cf * CFrame.new(x, 14, -16.5), color, m)
	end
	local signPart = Style.part({ name = "Sign", size = Vector3.new(40, 6, 0.4), cframe = cf * CFrame.new(0, 34.5, -16), color = Color3.new(0, 0, 0), transparency = 1, collide = false, query = false, parent = m })
	Style.sign(signPart, Enum.NormalId.Front, title, color, 16)
	local subPart = Style.part({ name = "SubSign", size = Vector3.new(30, 2.2, 0.4), cframe = cf * CFrame.new(0, 30.9, -18.4), color = Color3.new(0, 0, 0), transparency = 1, collide = false, query = false, parent = m })
	Style.sign(subPart, Enum.NormalId.Front, subtitle, UI.TextDim, 16, Enum.Font.BuilderSansBold)
	Style.pointLight(Style.neon("Lamp", Vector3.new(4, 0.3, 4), cf * CFrame.new(0, 28.6, -10), color, m, 0.2), color, 30, 1.2, true)
end

local function streetLamp(parent: Instance, pos: Vector3, facing: Vector3, color: Color3)
	local cf = CFrame.lookAt(pos, pos + facing)
	local m = Instance.new("Model")
	m.Name = "Lamp"
	m.Parent = parent
	Style.part({ name = "Pole", size = Vector3.new(0.8, 18, 0.8), cframe = cf * CFrame.new(0, 9, 0), color = METAL, material = Enum.Material.Metal, parent = m })
	Style.part({ name = "Arm", size = Vector3.new(0.6, 0.6, 5), cframe = cf * CFrame.new(0, 17.7, -2.2), color = METAL, material = Enum.Material.Metal, parent = m })
	local head = Style.neon("Head", Vector3.new(1.4, 0.3, 3), cf * CFrame.new(0, 17.3, -4.2), color, m)
	Style.pointLight(head, color, 34, 1.4, true)
end

function LobbyBuilder.build(parent: Instance): LobbyHandles
	local root = Style.folder("NexusLobby", parent)
	local origin = CFrame.new(0, 0, 0)

	-- ── Ground ──────────────────────────────────────────────────────────
	Style.part({
		name = "Plaza",
		size = Vector3.new(2, 360, 360),
		cframe = origin * CFrame.new(0, -1, 0) * CFrame.Angles(0, 0, math.rad(90)),
		shape = Enum.PartType.Cylinder,
		color = FLOOR,
		reflectance = 0.08,
		parent = root,
	})
	Style.part({
		name = "Outskirts",
		size = Vector3.new(1400, 2, 1400),
		cframe = origin * CFrame.new(0, -2.2, 0),
		color = Color3.fromRGB(10, 9, 16),
		parent = root,
	})
	-- Inner ring floor accent
	Style.part({
		name = "InnerFloor",
		size = Vector3.new(0.3, 130, 130),
		cframe = origin * CFrame.new(0, 0.05, 0) * CFrame.Angles(0, 0, math.rad(90)),
		shape = Enum.PartType.Cylinder,
		color = Color3.fromRGB(26, 22, 44),
		reflectance = 0.15,
		parent = root,
	})
	local floorRings = Instance.new("Model")
	floorRings.Name = "FloorRings"
	floorRings.Parent = root
	local r1 = Style.ring("RingInner", origin * CFrame.new(0, 0.25, 0), 65, 48, 0.6, UI.Cyan, floorRings)
	local r2 = Style.ring("RingMid", origin * CFrame.new(0, 0.2, 0), 115, 64, 0.5, UI.Pink, floorRings)
	local r3 = Style.ring("RingOuter", origin * CFrame.new(0, 0.2, 0), 176, 80, 0.8, UI.Violet, floorRings)
	for _, r in { r1, r2, r3 } do
		CollectionService:AddTag(r, "NeonPulse")
	end
	-- radial light lanes
	for i = 0, 7 do
		local a = i * math.pi / 4 + math.pi / 8
		local dir = Vector3.new(math.cos(a), 0, math.sin(a))
		local mid = dir * 120
		Style.neon("Lane", Vector3.new(0.5, 0.12, 100), CFrame.lookAt(mid + Vector3.new(0, 0.18, 0), mid + dir + Vector3.new(0, 0.18, 0)), UI.Cyan, root, 0.4)
	end

	-- ── Central showroom ────────────────────────────────────────────────
	local show = Instance.new("Model")
	show.Name = "CarShowcase"
	show.Parent = root
	Style.part({
		name = "Platform",
		size = Vector3.new(2.4, 46, 46),
		cframe = origin * CFrame.new(0, 1.2, 0) * CFrame.Angles(0, 0, math.rad(90)),
		shape = Enum.PartType.Cylinder,
		color = Color3.fromRGB(30, 28, 46),
		material = Enum.Material.SmoothPlastic,
		reflectance = 0.3,
		parent = show,
	})
	Style.ring("PlatformRim", origin * CFrame.new(0, 2.45, 0), 23.2, 40, 0.5, UI.Cyan, show)
	local turntable = Instance.new("Model")
	turntable.Name = "Turntable"
	turntable.Parent = show
	local displayCar = CarFactory.build({ name = "ShowcaseCar", paint = Color3.fromRGB(235, 40, 130), accent = UI.Cyan, anchored = true })
	displayCar:PivotTo(origin * CFrame.new(0, 2.4 + 2.7, 0) * CFrame.Angles(0, math.rad(35), 0))
	displayCar.Parent = turntable
	turntable:SetAttribute("SpinSpeed", 0.25)
	turntable:SetAttribute("Pivot", origin.Position)
	CollectionService:AddTag(turntable, "Spin")

	-- showroom spotlights on four towers
	for i = 0, 3 do
		local a = i * math.pi / 2 + math.pi / 4
		local pos = Vector3.new(math.cos(a) * 36, 0, math.sin(a) * 36)
		local tower = Style.part({ name = "LightTower", size = Vector3.new(2, 26, 2), cframe = CFrame.new(pos + Vector3.new(0, 13, 0)), color = METAL, material = Enum.Material.Metal, parent = show })
		local headPos = pos + Vector3.new(0, 26, 0)
		local head = Style.part({
			name = "SpotHead",
			size = Vector3.new(3, 3, 3),
			cframe = CFrame.lookAt(headPos, Vector3.new(0, 5, 0)),
			color = DARK,
			parent = tower,
		})
		Style.neon("Lens", Vector3.new(2.4, 2.4, 0.2), head.CFrame * CFrame.new(0, 0, -1.55), Color3.fromRGB(255, 245, 230), tower)
		local spot = Instance.new("SpotLight")
		spot.Face = Enum.NormalId.Front
		spot.Range = 60
		spot.Angle = 32
		spot.Brightness = 4
		spot.Color = if i % 2 == 0 then Color3.fromRGB(255, 236, 220) else Color3.fromRGB(200, 225, 255)
		spot.Shadows = true
		spot.Parent = head
	end

	-- ── Floating holographic logo ───────────────────────────────────────
	local holo = Instance.new("Model")
	holo.Name = "HoloLogo"
	holo.Parent = root
	local logo = Style.part({
		name = "Logo",
		size = Vector3.new(64, 14, 0.2),
		cframe = origin * CFrame.new(0, 46, 0),
		transparency = 1,
		collide = false,
		query = false,
		parent = holo,
	})
	for _, face in { Enum.NormalId.Front, Enum.NormalId.Back } do
		local label = Style.sign(logo, face, "RIFT RACERS", UI.Cyan, 12)
		local grad = Instance.new("UIGradient")
		grad.Color = ColorSequence.new({
			ColorSequenceKeypoint.new(0, UI.Cyan),
			ColorSequenceKeypoint.new(0.5, Color3.new(1, 1, 1)),
			ColorSequenceKeypoint.new(1, UI.Pink),
		})
		grad.Parent = label
		label.TextColor3 = Color3.new(1, 1, 1)
		CollectionService:AddTag(grad, "HoloGradient")
	end
	local sub = Style.part({ name = "Sub", size = Vector3.new(30, 3.4, 0.2), cframe = origin * CFrame.new(0, 37.5, 0), transparency = 1, collide = false, query = false, parent = holo })
	Style.sign(sub, Enum.NormalId.Front, "THE NEXUS", UI.Pink, 14)
	Style.sign(sub, Enum.NormalId.Back, "THE NEXUS", UI.Pink, 14)
	holo:SetAttribute("SpinSpeed", 0.12)
	holo:SetAttribute("Pivot", origin.Position)
	holo:SetAttribute("Bob", 1.2)
	CollectionService:AddTag(holo, "Spin")
	local halos = Instance.new("Model")
	halos.Name = "Halos"
	halos.Parent = root
	Style.ring("Halo1", origin * CFrame.new(0, 32, 0), 30, 36, 0.35, UI.Cyan, halos)
	Style.ring("Halo2", origin * CFrame.new(0, 56, 0) * CFrame.Angles(math.rad(8), 0, 0), 22, 28, 0.3, UI.Pink, halos)
	halos:SetAttribute("SpinSpeed", -0.3)
	halos:SetAttribute("Pivot", origin.Position)
	CollectionService:AddTag(halos, "Spin")

	-- ── RACE PORTAL (north) ─────────────────────────────────────────────
	local portal = Instance.new("Model")
	portal.Name = "RacePortal"
	portal.Parent = root
	local pcf = origin * CFrame.new(0, 0, -128) -- faces +Z (towards plaza centre)
	pcf = CFrame.lookAt(pcf.Position, Vector3.zero)
	for _, x in { -17, 17 } do
		Style.part({ name = "Pillar", size = Vector3.new(6, 40, 6), cframe = pcf * CFrame.new(x, 20, 0), color = DARK, reflectance = 0.1, parent = portal })
		Style.neon("PillarLine", Vector3.new(0.4, 38, 0.4), pcf * CFrame.new(x + (if x < 0 then 3.1 else -3.1), 20, -3.1), UI.Cyan, portal)
	end
	Style.part({ name = "Lintel", size = Vector3.new(42, 6, 6), cframe = pcf * CFrame.new(0, 43, 0), color = DARK, parent = portal })
	local gate = Style.ring("Gate", pcf * CFrame.new(0, 20, 0), 13.5, 40, 0.8, UI.Pink, portal, true)
	CollectionService:AddTag(gate, "NeonPulse")
	local veil = Style.part({
		name = "Veil",
		size = Vector3.new(0.2, 26, 26),
		cframe = pcf * CFrame.new(0, 20, 0) * CFrame.Angles(0, math.rad(90), 0),
		shape = Enum.PartType.Cylinder,
		color = UI.Violet,
		material = Enum.Material.ForceField,
		transparency = 0.2,
		collide = false,
		query = false,
		parent = portal,
	})
	veil.CastShadow = false
	local pad = Style.part({ name = "Pad", size = Vector3.new(30, 0.6, 16), cframe = pcf * CFrame.new(0, 0.3, -9), color = Color3.fromRGB(30, 26, 50), reflectance = 0.2, parent = portal })
	Style.neon("PadEdge", Vector3.new(30.4, 0.2, 16.4), pcf * CFrame.new(0, 0.62, -9), UI.Pink, portal, 0.5)
	local signPart = Style.part({ name = "Sign", size = Vector3.new(36, 4.6, 0.3), cframe = pcf * CFrame.new(0, 43, -3.2), transparency = 1, collide = false, query = false, parent = portal })
	Style.sign(signPart, Enum.NormalId.Front, "RACE PORTAL", UI.Text, 18)
	Style.pointLight(veil, UI.Pink, 40, 2, true)

	local prompt = Instance.new("ProximityPrompt")
	prompt.Name = "EnterRace"
	prompt.ActionText = "Enter Race"
	prompt.ObjectText = "Race Portal · Free For All"
	prompt.KeyboardKeyCode = Enum.KeyCode.E
	prompt.GamepadKeyCode = Enum.KeyCode.ButtonX
	prompt.HoldDuration = 0
	prompt.MaxActivationDistance = 18
	prompt.RequiresLineOfSight = false
	prompt.Parent = pad

	local statusPart = Style.part({ name = "Status", size = Vector3.new(26, 3, 0.3), cframe = pcf * CFrame.new(0, 37, -3.2), transparency = 1, collide = false, query = false, parent = portal })
	local statusLabel = Style.sign(statusPart, Enum.NormalId.Front, "OPEN · STEP ON THE PAD", UI.Cyan, 18, Enum.Font.BuilderSansBold)

	-- ── Pavilions (Phase 2 / 3 — closed, honestly labelled) ─────────────
	pavilion(root, CFrame.lookAt(Vector3.new(-128, 0, 0), Vector3.zero), "GARAGE", "OPENS IN PHASE 3", UI.Cyan)
	pavilion(root, CFrame.lookAt(Vector3.new(128, 0, 0), Vector3.zero), "MYSTERY BOXES", "OPENS IN PHASE 2", UI.Gold)

	-- ── Recent winners board (real data, this server) ───────────────────
	local boardCf = CFrame.lookAt(Vector3.new(92, 0, 92), Vector3.zero)
	local board = Instance.new("Model")
	board.Name = "WinnersBoard"
	board.Parent = root
	for _, x in { -14, 14 } do
		Style.part({ name = "Leg", size = Vector3.new(1.4, 10, 1.4), cframe = boardCf * CFrame.new(x, 5, 0), color = METAL, material = Enum.Material.Metal, parent = board })
	end
	local screen = Style.part({ name = "Screen", size = Vector3.new(34, 20, 1), cframe = boardCf * CFrame.new(0, 19, 0), color = Color3.fromRGB(8, 8, 16), parent = board })
	Style.neon("ScreenFrame", Vector3.new(34.6, 20.6, 0.6), boardCf * CFrame.new(0, 19, 0.3), UI.Violet, board)
	local gui = Instance.new("SurfaceGui")
	gui.Face = Enum.NormalId.Front
	gui.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	gui.PixelsPerStud = 20
	gui.LightInfluence = 0
	gui.Brightness = 1.6
	gui.Parent = screen
	local title = Instance.new("TextLabel")
	title.BackgroundTransparency = 1
	title.Size = UDim2.new(1, 0, 0.2, 0)
	title.Text = "RECENT WINNERS"
	title.TextScaled = true
	title.FontFace = Font.fromEnum(Enum.Font.Michroma)
	title.TextColor3 = UI.Gold
	title.Parent = gui
	local rows: { TextLabel } = {}
	for i = 1, 5 do
		local row = Instance.new("TextLabel")
		row.Name = "Row" .. i
		row.BackgroundColor3 = if i % 2 == 0 then Color3.fromRGB(20, 18, 36) else Color3.fromRGB(14, 12, 26)
		row.BorderSizePixel = 0
		row.Position = UDim2.new(0.04, 0, 0.22 + (i - 1) * 0.15, 0)
		row.Size = UDim2.new(0.92, 0, 0.13, 0)
		row.Text = if i == 1 then "No races yet — be the first!" else ""
		row.TextScaled = true
		row.TextXAlignment = Enum.TextXAlignment.Left
		row.FontFace = Font.fromEnum(Enum.Font.BuilderSansBold)
		row.TextColor3 = UI.Text
		row.Parent = gui
		local pad_ = Instance.new("UIPadding")
		pad_.PaddingLeft = UDim.new(0.03, 0)
		pad_.Parent = row
		table.insert(rows, row)
	end

	-- ── Parked display cars ─────────────────────────────────────────────
	local parked = Instance.new("Folder")
	parked.Name = "ParkedCars"
	parked.Parent = root
	local parkedSpecs = {
		{ pos = Vector3.new(-80, 0, -70), paint = Color3.fromRGB(30, 140, 255), accent = UI.Pink },
		{ pos = Vector3.new(80, 0, -70), paint = Color3.fromRGB(245, 245, 250), accent = UI.Violet },
		{ pos = Vector3.new(-92, 0, 88), paint = Color3.fromRGB(20, 20, 26), accent = UI.Gold },
	}
	for i, s in parkedSpecs do
		local car = CarFactory.build({ name = "ParkedCar" .. i, paint = s.paint, accent = s.accent, anchored = true })
		car:PivotTo(CFrame.lookAt(s.pos + Vector3.new(0, 2.7, 0), Vector3.new(0, 2.7, 0)) * CFrame.Angles(0, math.rad(30), 0))
		car.Parent = parked
		Style.neon("Bay", Vector3.new(11, 0.1, 18), CFrame.new(s.pos + Vector3.new(0, 0.12, 0)) * car:GetPivot().Rotation, s.accent, parked, 0.75)
	end

	-- ── Lamps + skyline ─────────────────────────────────────────────────
	for i = 0, 11 do
		local a = i * math.pi / 6
		local pos = Vector3.new(math.cos(a) * 160, 0, math.sin(a) * 160)
		streetLamp(root, pos, -pos.Unit, if i % 2 == 0 then UI.Cyan else UI.Pink)
	end
	local skyline = Style.folder("Skyline", root)
	local rng = Random.new(7)
	for i = 0, 27 do
		local a = i / 28 * math.pi * 2 + rng:NextNumber(-0.05, 0.05)
		local dist = rng:NextNumber(300, 520)
		local h = rng:NextNumber(90, 340)
		local w = rng:NextNumber(36, 70)
		local pos = Vector3.new(math.cos(a) * dist, h / 2 - 2, math.sin(a) * dist)
		local cf = CFrame.lookAt(pos, Vector3.new(0, pos.Y, 0))
		Style.part({ name = "Tower", size = Vector3.new(w, h, w), cframe = cf, color = Color3.fromRGB(16, 14, 28), reflectance = 0.06, castShadow = false, parent = skyline })
		local accent = if i % 3 == 0 then UI.Pink elseif i % 3 == 1 then UI.Cyan else UI.Violet
		local bands = math.floor(h / 60)
		for b = 1, bands do
			Style.neon("Band", Vector3.new(w + 0.4, 0.6, w + 0.4), cf * CFrame.new(0, -h / 2 + b * 55, 0), accent, skyline, 0.25)
		end
		Style.neon("Crown", Vector3.new(w + 0.6, 1.2, w + 0.6), cf * CFrame.new(0, h / 2, 0), accent, skyline)
	end

	-- ── Spawn ───────────────────────────────────────────────────────────
	local spawn = Instance.new("SpawnLocation")
	spawn.Name = "NexusSpawn"
	spawn.Size = Vector3.new(14, 0.4, 14)
	spawn.CFrame = CFrame.lookAt(Vector3.new(0, 0.2, 100), Vector3.new(0, 0.2, 0))
	spawn.Anchored = true
	spawn.Transparency = 1
	spawn.CanCollide = false
	spawn.Neutral = true
	spawn.Duration = 0
	spawn.Parent = root
	local decal = spawn:FindFirstChildOfClass("Decal")
	if decal then
		decal:Destroy()
	end
	Style.ring("SpawnRing", CFrame.new(0, 0.25, 100), 7, 24, 0.35, UI.Cyan, root)

	return {
		model = root,
		spawn = spawn,
		portalPrompt = prompt,
		winnerRows = rows,
		statusLabel = statusLabel,
	}
end

return LobbyBuilder
