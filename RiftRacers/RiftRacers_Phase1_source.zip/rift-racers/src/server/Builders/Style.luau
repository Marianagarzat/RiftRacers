--!strict
-- Small construction helpers shared by every procedural builder.

local CollectionService = game:GetService("CollectionService")

local Style = {}

export type PartSpec = {
	name: string?,
	size: Vector3,
	cframe: CFrame,
	color: Color3?,
	material: Enum.Material?,
	transparency: number?,
	reflectance: number?,
	shape: Enum.PartType?,
	wedge: boolean?,
	collide: boolean?,
	query: boolean?,
	anchored: boolean?,
	castShadow: boolean?,
	parent: Instance?,
}

function Style.part(spec: PartSpec): BasePart
	local p: BasePart
	if spec.wedge then
		p = Instance.new("WedgePart")
	else
		local part = Instance.new("Part")
		if spec.shape then
			part.Shape = spec.shape
		end
		p = part
	end
	p.Name = spec.name or "Part"
	p.Size = spec.size
	p.CFrame = spec.cframe
	p.Color = spec.color or Color3.fromRGB(30, 30, 40)
	p.Material = spec.material or Enum.Material.SmoothPlastic
	p.Transparency = spec.transparency or 0
	p.Reflectance = spec.reflectance or 0
	p.Anchored = if spec.anchored == nil then true else spec.anchored
	p.CanCollide = if spec.collide == nil then true else spec.collide
	p.CanQuery = if spec.query == nil then true else spec.query
	p.CanTouch = false
	p.CastShadow = if spec.castShadow == nil then true else spec.castShadow
	p.TopSurface = Enum.SurfaceType.Smooth
	p.BottomSurface = Enum.SurfaceType.Smooth
	if spec.parent then
		p.Parent = spec.parent
	end
	return p
end

-- Glowing strip: neon, never collides, never blocks raycasts, no shadow.
function Style.neon(name: string, size: Vector3, cframe: CFrame, color: Color3, parent: Instance, transparency: number?): BasePart
	return Style.part({
		name = name,
		size = size,
		cframe = cframe,
		color = color,
		material = Enum.Material.Neon,
		transparency = transparency,
		collide = false,
		query = false,
		castShadow = false,
		parent = parent,
	})
end

function Style.pointLight(parent: Instance, color: Color3, range: number, brightness: number, decor: boolean?): PointLight
	local l = Instance.new("PointLight")
	l.Color = color
	l.Range = range
	l.Brightness = brightness
	l.Shadows = false
	l.Parent = parent
	if decor then
		CollectionService:AddTag(l, "DecorLight")
	end
	return l
end

function Style.folder(name: string, parent: Instance): Folder
	local f = Instance.new("Folder")
	f.Name = name
	f.Parent = parent
	return f
end

-- SurfaceGui sign with large text. Returns the TextLabel for later updates.
function Style.sign(
	part: BasePart,
	face: Enum.NormalId,
	text: string,
	color: Color3,
	pixelsPerStud: number?,
	font: Enum.Font?
): TextLabel
	local gui = Instance.new("SurfaceGui")
	gui.Face = face
	gui.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	gui.PixelsPerStud = pixelsPerStud or 20
	gui.LightInfluence = 0
	gui.Brightness = 2.2
	gui.AlwaysOnTop = false
	gui.Parent = part
	local label = Instance.new("TextLabel")
	label.Name = "Text"
	label.BackgroundTransparency = 1
	label.Size = UDim2.fromScale(1, 1)
	label.Text = text
	label.TextScaled = true
	label.TextColor3 = color
	label.FontFace = Font.fromEnum(font or Enum.Font.Michroma)
	label.Parent = gui
	local stroke = Instance.new("UIStroke")
	stroke.Color = color:Lerp(Color3.new(0, 0, 0), 0.6)
	stroke.Thickness = 2
	stroke.Transparency = 0.3
	stroke.Parent = label
	return label
end

-- Ring of neon segments in the XZ plane (or vertical if `vertical`).
function Style.ring(
	name: string,
	center: CFrame,
	radius: number,
	segments: number,
	thickness: number,
	color: Color3,
	parent: Instance,
	vertical: boolean?
): Model
	local model = Instance.new("Model")
	model.Name = name
	local segLen = 2 * math.pi * radius / segments + 0.15
	for i = 0, segments - 1 do
		local a = (i / segments) * math.pi * 2
		local local_: CFrame
		if vertical then
			-- ring in the XY plane of `center`
			local_ = CFrame.new(math.cos(a) * radius, math.sin(a) * radius, 0) * CFrame.Angles(0, 0, a)
			Style.neon(
				"Seg",
				Vector3.new(thickness, segLen, thickness),
				center * local_,
				color,
				model
			)
		else
			local_ = CFrame.new(math.cos(a) * radius, 0, math.sin(a) * radius) * CFrame.Angles(0, -a, 0)
			Style.neon(
				"Seg",
				Vector3.new(thickness, thickness, segLen),
				center * local_,
				color,
				model
			)
		end
	end
	model.Parent = parent
	return model
end

return Style
