--!strict
-- Generates a complete racing circuit from a MapDefinition: road, barriers,
-- tunnels, elevated skybridge, checkpoint gates, start grid, finish line,
-- street furniture and a procedural neon city around it.
--
-- Everything is deterministic (seeded) so every server builds the same city.

local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Config = require(ReplicatedStorage.Shared.Config)
local Spline = require(ReplicatedStorage.Shared.Util.Spline)
local MapDefinitions = require(ReplicatedStorage.Shared.MapDefinitions)
local Style = require(script.Parent.Style)

type Sample = Spline.Sample
type MapDefinition = MapDefinitions.MapDefinition

export type Checkpoint = {
	index: number, -- 0 = start/finish
	cframe: CFrame, -- at road centre, LookVector = direction of travel
	halfWidth: number,
	section: string,
	sampleIndex: number,
}

export type TrackData = {
	map: MapDefinition,
	folder: Folder,
	samples: { Sample },
	total: number,
	width: number,
	checkpoints: { Checkpoint }, -- array, checkpoints[1].index == 0
	grid: { CFrame },
	sectionOf: (sampleIndex: number) -> string,
}

local TrackBuilder = {}

local CONCRETE = Color3.fromRGB(30, 28, 42)
local ROAD = Color3.fromRGB(14, 14, 22)
local METAL = Color3.fromRGB(44, 42, 60)

local ADS = {
	"RIFT RACERS",
	"SYNTHWAVE FM",
	"KAIJU NOODLE BAR",
	"NIGHT MARKET",
	"AERO-9 DYNAMICS",
	"NEON//PULSE",
	"DRIVE THE FUTURE",
	"ZERO GRAVITY CLUB",
	"PIXEL TEA",
	"OVERCLOCK",
	"GRID 2099",
	"HYPERLANE",
}

local function sectionFor(map: MapDefinition, segment: number): MapDefinitions.Section
	local n = #map.controlPoints
	for _, s in map.sections do
		local to = s.to
		if segment >= s.from and segment < to then
			return s
		end
		if to > n + 1 and segment < to - n then
			return s
		end
	end
	return map.sections[1]
end

local function flatAngle(a: Vector3, b: Vector3): number
	local d = math.clamp(a:Dot(b), -1, 1)
	return math.acos(d)
end

function TrackBuilder.build(map: MapDefinition, parent: Instance): TrackData
	local folder = Style.folder(map.id, parent)
	local origin = map.origin
	local W = map.roadWidth
	local halfW = W / 2

	local pts: { Vector3 } = {}
	for i, p in map.controlPoints do
		pts[i] = p + origin
	end
	local samples, total = Spline.sampleClosed(pts, map.sampleSpacing)
	local n = #samples
	local rng = Random.new(2099)
	local palette = map.palette

	local function sectionOfSample(i: number): MapDefinitions.Section
		return sectionFor(map, samples[i].segment)
	end

	local roadF = Style.folder("Road", folder)
	local wallF = Style.folder("Barriers", folder)
	local decoF = Style.folder("Decor", folder)
	local cityF = Style.folder("City", folder)
	local cpF = Style.folder("Checkpoints", folder)

	-- ── 1. Group samples into straight-ish runs (fewer, longer parts) ────
	type Run = { a: number, b: number, kind: string }
	local runs: { Run } = {}
	do
		local i = 1
		while i <= n do
			local kind = sectionOfSample(i).kind
			local startDir = (samples[(i % n) + 1].position - samples[i].position).Unit
			local j = i + 1
			while j <= n do
				local nextIdx = (j % n) + 1
				local dir = (samples[nextIdx].position - samples[j].position).Unit
				if flatAngle(startDir, dir) > math.rad(0.6) then
					break
				end
				if sectionOfSample(j).kind ~= kind then
					break
				end
				if (j - i) * map.sampleSpacing > 320 then
					break
				end
				j += 1
			end
			table.insert(runs, { a = i, b = j - 1, kind = kind })
			i = j
		end
	end

	local function pos(i: number): Vector3
		return samples[((i - 1) % n) + 1].position
	end

	-- ── 2. Road, edge lines, barriers per run ───────────────────────────
	for r, run in runs do
		local a = pos(run.a)
		local bIdx = run.b + 1
		local b = pos(bIdx)
		local dir = b - a
		local len = dir.Magnitude
		if len < 0.1 then
			continue
		end
		local nextRun = runs[(r % #runs) + 1]
		local nextDir = (pos(nextRun.b + 1) - pos(nextRun.a)).Unit
		local turn = flatAngle(dir.Unit, nextDir)
		local overlap = halfW * math.tan(math.min(turn, 1.2) / 2) * 2 + 0.6
		local mid = (a + b) / 2
		local cf = CFrame.lookAt(mid, b)
		local L = len + overlap

		Style.part({
			name = "Road",
			size = Vector3.new(W, 2, L),
			cframe = cf * CFrame.new(0, -1, 0),
			color = ROAD,
			reflectance = 0.14,
			parent = roadF,
		})
		local edgeColor = if run.kind == "underground" then Color3.fromRGB(255, 120, 40) else palette[2]
		for _, side in { -1, 1 } do
			Style.neon("EdgeLine", Vector3.new(0.5, 0.06, L), cf * CFrame.new(side * (halfW - 2.2), 0.03, 0), edgeColor, roadF, 0.15)
		end

		local tall = run.kind == "tunnel" or run.kind == "underground"
		local wallH = if tall then 28 else 5.5
		for _, side in { -1, 1 } do
			local wallCf = cf * CFrame.new(side * (halfW + 1), wallH / 2 - 1.5, 0)
			if run.kind == "bridge" then
				Style.part({
					name = "GlassRail",
					size = Vector3.new(0.6, 5.5, L),
					cframe = cf * CFrame.new(side * (halfW + 0.6), 1.25, 0),
					color = Color3.fromRGB(120, 160, 255),
					material = Enum.Material.Glass,
					transparency = 0.6,
					castShadow = false,
					parent = wallF,
				})
				Style.part({ name = "RailBase", size = Vector3.new(1.6, 1.2, L), cframe = cf * CFrame.new(side * (halfW + 0.8), -1.4, 0), color = METAL, material = Enum.Material.Metal, parent = wallF })
				Style.neon("RailTop", Vector3.new(0.5, 0.3, L), cf * CFrame.new(side * (halfW + 0.6), 4.1, 0), palette[1], wallF)
			else
				Style.part({ name = "Wall", size = Vector3.new(2, wallH, L), cframe = wallCf, color = CONCRETE, reflectance = 0.05, parent = wallF })
				if not tall then
					Style.neon("WallTop", Vector3.new(2.1, 0.3, L), cf * CFrame.new(side * (halfW + 1), wallH - 1.35, 0), palette[if side < 0 then 1 else 3], wallF)
				else
					Style.neon("WallStripe", Vector3.new(0.2, 0.4, L), cf * CFrame.new(side * (halfW - 0.05), 2.5, 0), edgeColor, wallF, 0.1)
				end
			end
		end
		if tall then
			Style.part({ name = "Roof", size = Vector3.new(W + 6, 2, L), cframe = cf * CFrame.new(0, wallH - 0.5, 0), color = CONCRETE, parent = wallF })
		end
	end

	-- ── 3. Per-sample details (dashes, tunnel rings, pillars, lamps) ────
	local ringIndex = 0
	for i = 1, n do
		local s = samples[i]
		local sec = sectionOfSample(i)
		local cf = CFrame.lookAt(s.position, s.position + s.tangent)

		if i % 4 == 0 then
			Style.neon("Dash", Vector3.new(0.6, 0.06, 6), cf * CFrame.new(0, 0.035, 0), Color3.fromRGB(220, 220, 255), roadF, 0.35)
		end

		if (sec.kind == "tunnel" or sec.kind == "underground") and i % 3 == 0 then
			ringIndex += 1
			local ring = Instance.new("Model")
			ring.Name = "TunnelRing"
			local col = if sec.kind == "underground" then Color3.fromRGB(255, 110, 40) else palette[(ringIndex % 2) + 1]
			for _, side in { -1, 1 } do
				Style.neon("Post", Vector3.new(0.6, 24, 0.6), cf * CFrame.new(side * (halfW - 0.4), 11, 0), col, ring)
			end
			local top = Style.neon("Top", Vector3.new(W, 0.6, 0.6), cf * CFrame.new(0, 23, 0), col, ring)
			if ringIndex % 2 == 0 then
				Style.pointLight(top, col, 32, 1.6, true)
			end
			ring:SetAttribute("Phase", ringIndex)
			ring:SetAttribute("Underground", sec.kind == "underground")
			CollectionService:AddTag(ring, "TunnelRing")
			ring.Parent = decoF
			if ringIndex % 4 == 1 then
				for _, side in { -1, 1 } do
					local panel = Style.part({
						name = "HoloAd",
						size = Vector3.new(0.2, 12, 26),
						cframe = cf * CFrame.new(side * (halfW - 0.15), 11, 0),
						color = Color3.new(0, 0, 0),
						collide = false,
						query = false,
						parent = decoF,
					})
					local face = if side > 0 then Enum.NormalId.Left else Enum.NormalId.Right
					local label = Style.sign(panel, face, ADS[rng:NextInteger(1, #ADS)], Color3.new(1, 1, 1), 14)
					local g = Instance.new("UIGradient")
					g.Color = ColorSequence.new(palette[1], palette[2])
					g.Parent = label
					CollectionService:AddTag(g, "HoloGradient")
				end
			end
		end

		if sec.kind == "bridge" and i % 6 == 0 and s.position.Y > origin.Y + 6 then
			local h = s.position.Y - origin.Y - 2
			local base = Vector3.new(s.position.X, origin.Y - 0.4 + h / 2, s.position.Z)
			local pcf = CFrame.lookAt(base, base + Vector3.new(s.tangent.X, 0, s.tangent.Z))
			for _, side in { -1, 1 } do
				Style.part({ name = "Pillar", size = Vector3.new(5, h, 5), cframe = pcf * CFrame.new(side * (halfW - 6), 0, 0), color = CONCRETE, parent = wallF })
				Style.neon("PillarLight", Vector3.new(0.3, h - 4, 0.3), pcf * CFrame.new(side * (halfW - 6), 0, -2.6), palette[3], wallF, 0.2)
			end
			Style.part({ name = "Crossbeam", size = Vector3.new(W - 4, 3, 4), cframe = cf * CFrame.new(0, -3.5, 0), color = CONCRETE, parent = wallF })
		end

		if sec.kind == "street" and i % 9 == 0 then
			local side = if (i // 9) % 2 == 0 then 1 else -1
			local lamp = Instance.new("Model")
			lamp.Name = "StreetLamp"
			lamp.Parent = decoF
			local base = cf * CFrame.new(side * (halfW + 4.5), 0, 0)
			Style.part({ name = "Pole", size = Vector3.new(0.9, 22, 0.9), cframe = base * CFrame.new(0, 10, 0), color = METAL, material = Enum.Material.Metal, parent = lamp })
			Style.part({ name = "Arm", size = Vector3.new(9, 0.6, 0.6), cframe = base * CFrame.new(-side * 4.3, 20.7, 0), color = METAL, material = Enum.Material.Metal, parent = lamp })
			local col = palette[((i // 9) % 3) + 1]
			local head = Style.neon("Head", Vector3.new(4, 0.35, 1.4), base * CFrame.new(-side * 8.2, 20.3, 0), col, lamp)
			Style.pointLight(head, col, 46, 1.6, true)
		end

		if sec.kind == "street" and i % 23 == 5 then
			local side = if i % 2 == 0 then 1 else -1
			local vent = Style.part({
				name = "SteamVent",
				size = Vector3.new(4, 0.1, 4),
				cframe = cf * CFrame.new(side * (halfW - 6), 0.02, 0),
				color = Color3.fromRGB(40, 40, 50),
				material = Enum.Material.DiamondPlate,
				collide = false,
				query = false,
				parent = decoF,
			})
			local e = Instance.new("ParticleEmitter")
			e.Texture = "rbxasset://textures/particles/smoke_main.dds"
			e.Color = ColorSequence.new(Color3.fromRGB(200, 180, 255))
			e.LightEmission = 0.15
			e.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 2), NumberSequenceKeypoint.new(1, 9) })
			e.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.7), NumberSequenceKeypoint.new(1, 1) })
			e.Lifetime = NumberRange.new(2, 3.5)
			e.Speed = NumberRange.new(6, 10)
			e.Rate = 6
			e.Rotation = NumberRange.new(0, 360)
			e.RotSpeed = NumberRange.new(-20, 20)
			e.Parent = vent
			CollectionService:AddTag(e, "DecorFX")
		end
	end

	-- ── 4. Checkpoints, finish line, start lights ───────────────────────
	local checkpoints: { Checkpoint } = {}
	local count = map.checkpointCount
	for k = 0, count - 1 do
		local si = math.floor(k * n / count) + 1
		local s = samples[si]
		local cf = CFrame.lookAt(s.position, s.position + s.tangent)
		local sec = sectionOfSample(si)
		table.insert(checkpoints, {
			index = k,
			cframe = cf,
			halfWidth = halfW,
			section = sec.name,
			sampleIndex = si,
		})

		local gate = Instance.new("Model")
		gate.Name = "Gate" .. k
		gate:SetAttribute("CheckpointIndex", k)
		gate:SetAttribute("Section", sec.name)
		gate:SetAttribute("GateCFrame", cf)
		local isFinish = k == 0
		local tall = sec.kind == "tunnel" or sec.kind == "underground"
		local height = if isFinish then 30 elseif tall then 21 else 20
		local postW = if isFinish then 3 else 1.2
		local col = if isFinish then Color3.new(1, 1, 1) else palette[2]
		for _, side in { -1, 1 } do
			local post = Style.neon("Post", Vector3.new(postW, height, postW), cf * CFrame.new(side * (halfW - 1), height / 2, 0), col, gate, 0.15)
			post.Name = "Post"
		end
		local beam = Style.neon("Beam", Vector3.new(W, if isFinish then 5 else 0.9, if isFinish then 3 else 0.9), cf * CFrame.new(0, height, 0), col, gate, 0.15)
		beam.Name = "Beam"
		if isFinish then
			beam.Material = Enum.Material.SmoothPlastic
			beam.Color = Color3.fromRGB(16, 16, 26)
			beam.Transparency = 0
			Style.sign(beam, Enum.NormalId.Back, "FINISH", Color3.new(1, 1, 1), 20)
			Style.sign(beam, Enum.NormalId.Front, "CYBERPULSE CITY", palette[1], 20)
			-- five start lights on the back face (visible from the grid)
			for L = 1, 5 do
				local bulb = Style.neon("StartLight", Vector3.new(2.2, 2.2, 0.4), cf * CFrame.new((L - 3) * 4, height - 4.5, 1.7), Color3.fromRGB(60, 10, 14), gate)
				bulb:SetAttribute("Order", L)
				CollectionService:AddTag(bulb, "StartLight")
			end
			-- checkered strip
			local cells = 16
			local cw = W / cells
			for row = 0, 1 do
				for c = 0, cells - 1 do
					local white = (row + c) % 2 == 0
					Style.part({
						name = "Checker",
						size = Vector3.new(cw, 0.06, 3),
						cframe = cf * CFrame.new(-halfW + cw * (c + 0.5), 0.04, (row - 0.5) * 3),
						color = if white then Color3.fromRGB(235, 235, 240) else Color3.fromRGB(12, 12, 16),
						collide = false,
						query = false,
						castShadow = false,
						parent = gate,
					})
				end
			end
		end
		CollectionService:AddTag(gate, "CheckpointGate")
		gate.Parent = cpF
	end

	-- ── 5. Start grid ───────────────────────────────────────────────────
	local grid: { CFrame } = {}
	for k = 0, Config.Race.MaxPlayers - 1 do
		local row = k // 2
		local col = k % 2
		local d = total - (22 + row * 17)
		local p, t = Spline.atDistance(samples, total, d)
		local base = CFrame.lookAt(p, p + t)
		local lateral = if col == 0 then -9 else 9
		local slot = base * CFrame.new(lateral, 0, if col == 1 then 4 else 0)
		table.insert(grid, slot * CFrame.new(0, 3.2, 0))
		Style.neon("GridBox", Vector3.new(8, 0.05, 0.4), slot * CFrame.new(0, 0.04, -7.5), Color3.new(1, 1, 1), roadF, 0.3)
		for _, sx in { -4, 4 } do
			Style.neon("GridBox", Vector3.new(0.4, 0.05, 6), slot * CFrame.new(sx, 0.04, -4.5), Color3.new(1, 1, 1), roadF, 0.3)
		end
	end

	-- ── 6. City ─────────────────────────────────────────────────────────
	local minX, maxX, minZ, maxZ = math.huge, -math.huge, math.huge, -math.huge
	for _, s in samples do
		minX = math.min(minX, s.position.X)
		maxX = math.max(maxX, s.position.X)
		minZ = math.min(minZ, s.position.Z)
		maxZ = math.max(maxZ, s.position.Z)
	end
	local pad = 520
	local cx, cz = (minX + maxX) / 2, (minZ + maxZ) / 2
	local sizeX, sizeZ = maxX - minX + pad * 2, maxZ - minZ + pad * 2
	Style.part({
		name = "CityFloor",
		size = Vector3.new(sizeX, 2, sizeZ),
		cframe = CFrame.new(cx, origin.Y - 1.4, cz),
		color = Color3.fromRGB(12, 11, 20),
		reflectance = 0.06,
		parent = cityF,
	})
	for gx = minX - pad + 100, maxX + pad - 100, 200 do
		Style.neon("FloorGrid", Vector3.new(0.4, 0.05, sizeZ), CFrame.new(gx, origin.Y - 0.37, cz), palette[3], cityF, 0.7)
	end
	for gz = minZ - pad + 100, maxZ + pad - 100, 200 do
		Style.neon("FloorGrid", Vector3.new(sizeX, 0.05, 0.4), CFrame.new(cx, origin.Y - 0.37, gz), palette[3], cityF, 0.7)
	end

	local function nearestSample(p: Vector3): (number, number)
		local best, bestI = math.huge, 1
		for i = 1, n, 2 do
			local q = samples[i].position
			local dx, dz = q.X - p.X, q.Z - p.Z
			local d = dx * dx + dz * dz
			if d < best then
				best, bestI = d, i
			end
		end
		return math.sqrt(best), bestI
	end

	local STEP = 120
	for gx = minX - pad + 60, maxX + pad - 60, STEP do
		for gz = minZ - pad + 60, maxZ + pad - 60, STEP do
			local w = rng:NextNumber(38, 78)
			local d = rng:NextNumber(38, 78)
			local p = Vector3.new(gx + rng:NextNumber(-14, 14), origin.Y, gz + rng:NextNumber(-14, 14))
			local dist, si = nearestSample(p)
			local clearance = halfW + math.sqrt(w * w + d * d) / 2 + 26
			if dist < clearance then
				continue
			end
			local nearTrack = dist < clearance + 120
			local h = if nearTrack then rng:NextNumber(70, 260) else rng:NextNumber(110, 430)
			local bcf = CFrame.new(p + Vector3.new(0, h / 2 - 1, 0)) * CFrame.Angles(0, math.rad(rng:NextInteger(0, 3) * 90 + rng:NextNumber(-8, 8)), 0)
			local b = Instance.new("Model")
			b.Name = "Tower"
			Style.part({
				name = "Body",
				size = Vector3.new(w, h, d),
				cframe = bcf,
				color = Color3.fromRGB(rng:NextInteger(14, 24), rng:NextInteger(12, 20), rng:NextInteger(26, 40)),
				reflectance = 0.08,
				castShadow = nearTrack,
				parent = b,
			})
			local accent = palette[rng:NextInteger(1, #palette)]
			local bands = rng:NextInteger(2, 5)
			for k = 1, bands do
				Style.neon("Band", Vector3.new(w + 0.5, 0.7, d + 0.5), bcf * CFrame.new(0, -h / 2 + h * k / (bands + 1), 0), accent, b, 0.2)
			end
			Style.neon("Crown", Vector3.new(w + 0.8, 1.4, d + 0.8), bcf * CFrame.new(0, h / 2, 0), accent, b)
			if rng:NextNumber() < 0.5 then
				for _, sx in { -1, 1 } do
					Style.neon("Edge", Vector3.new(0.5, h, 0.5), bcf * CFrame.new(sx * (w / 2 + 0.1), 0, -d / 2 - 0.1), accent, b, 0.3)
				end
			end
			if rng:NextNumber() < 0.35 then
				Style.part({ name = "Antenna", size = Vector3.new(0.6, 30, 0.6), cframe = bcf * CFrame.new(0, h / 2 + 15, 0), color = METAL, material = Enum.Material.Metal, castShadow = false, parent = b })
				Style.neon("Beacon", Vector3.new(1.4, 1.4, 1.4), bcf * CFrame.new(0, h / 2 + 30.5, 0), Color3.fromRGB(255, 40, 70), b)
			end
			if nearTrack and rng:NextNumber() < 0.4 then
				local target = samples[si].position
				local toTrack = Vector3.new(target.X - p.X, 0, target.Z - p.Z).Unit
				local bw = rng:NextNumber(26, 40)
				local bh = bw * 0.55
				local y = math.clamp(rng:NextNumber(20, h - bh), 18, math.max(18, h - bh / 2 - 4))
				local facePos = p + toTrack * (math.max(w, d) / 2 + 1.5) + Vector3.new(0, y, 0)
				local board = Style.part({
					name = "HoloBoard",
					size = Vector3.new(bw, bh, 0.4),
					cframe = CFrame.lookAt(facePos, facePos + toTrack),
					color = Color3.new(0, 0, 0),
					transparency = 0.2,
					collide = false,
					query = false,
					castShadow = false,
					parent = b,
				})
				local label = Style.sign(board, Enum.NormalId.Front, ADS[rng:NextInteger(1, #ADS)], Color3.new(1, 1, 1), 10)
				local g = Instance.new("UIGradient")
				g.Color = ColorSequence.new({
					ColorSequenceKeypoint.new(0, palette[1]),
					ColorSequenceKeypoint.new(0.5, palette[2]),
					ColorSequenceKeypoint.new(1, palette[3]),
				})
				g.Parent = label
				CollectionService:AddTag(g, "HoloGradient")
				Style.neon("BoardFrame", Vector3.new(bw + 1, bh + 1, 0.2), board.CFrame * CFrame.new(0, 0, 0.35), accent, b)
			end
			b.Parent = cityF
		end
	end

	-- distant megatowers for the skyline silhouette
	for i = 0, 35 do
		local a = i / 36 * math.pi * 2
		local r = math.max(sizeX, sizeZ) / 2 + rng:NextNumber(250, 600)
		local h = rng:NextNumber(400, 900)
		local w = rng:NextNumber(90, 180)
		local p = Vector3.new(cx + math.cos(a) * r, origin.Y + h / 2 - 2, cz + math.sin(a) * r)
		local cf = CFrame.new(p)
		Style.part({ name = "MegaTower", size = Vector3.new(w, h, w), cframe = cf, color = Color3.fromRGB(14, 12, 26), castShadow = false, parent = cityF })
		Style.neon("MegaCrown", Vector3.new(w + 1, 3, w + 1), cf * CFrame.new(0, h / 2 - 20, 0), palette[(i % #palette) + 1], cityF, 0.1)
	end

	return {
		map = map,
		folder = folder,
		samples = samples,
		total = total,
		width = W,
		checkpoints = checkpoints,
		grid = grid,
		sectionOf = function(i: number): string
			return sectionOfSample(i).name
		end,
	}
end

return TrackBuilder
