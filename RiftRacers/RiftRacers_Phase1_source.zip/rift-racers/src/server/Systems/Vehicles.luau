--!strict
-- Spawns race cars, seats drivers, hands physics ownership to the driver at
-- GO, and cleans everything up. The driver's client simulates its own car
-- (standard for responsive Roblox vehicles); the server stays authoritative
-- over race progress in Race.luau.

local CollectionService = game:GetService("CollectionService")
local PhysicsService = game:GetService("PhysicsService")
local Workspace = game:GetService("Workspace")

local CarFactory = require(script.Parent.Parent.Builders.CarFactory)

local Vehicles = {}

Vehicles.CAR_GROUP = "RiftCars"
Vehicles.DRIVER_GROUP = "RiftDrivers"
Vehicles.RAY_GROUP = "RiftWheelRay"

local carsFolder: Folder

-- Distinct paint per grid slot until Phase 3 garage customisation exists.
local LIVERIES: { { paint: Color3, accent: Color3 } } = {
	{ paint = Color3.fromRGB(235, 40, 130), accent = Color3.fromRGB(64, 224, 255) },
	{ paint = Color3.fromRGB(30, 140, 255), accent = Color3.fromRGB(255, 56, 170) },
	{ paint = Color3.fromRGB(245, 245, 250), accent = Color3.fromRGB(140, 82, 255) },
	{ paint = Color3.fromRGB(20, 20, 26), accent = Color3.fromRGB(255, 196, 64) },
	{ paint = Color3.fromRGB(120, 60, 255), accent = Color3.fromRGB(80, 255, 200) },
	{ paint = Color3.fromRGB(255, 120, 30), accent = Color3.fromRGB(64, 224, 255) },
	{ paint = Color3.fromRGB(40, 210, 160), accent = Color3.fromRGB(255, 56, 170) },
	{ paint = Color3.fromRGB(200, 20, 40), accent = Color3.fromRGB(255, 255, 255) },
}

function Vehicles.init()
	PhysicsService:RegisterCollisionGroup(Vehicles.CAR_GROUP)
	PhysicsService:RegisterCollisionGroup(Vehicles.DRIVER_GROUP)
	PhysicsService:RegisterCollisionGroup(Vehicles.RAY_GROUP)
	-- Drivers collide with nothing (they ride inside the car).
	for _, g in { "Default", Vehicles.CAR_GROUP, Vehicles.DRIVER_GROUP, Vehicles.RAY_GROUP } do
		PhysicsService:CollisionGroupSetCollidable(Vehicles.DRIVER_GROUP, g, false)
	end
	-- Suspension rays only see the world.
	PhysicsService:CollisionGroupSetCollidable(Vehicles.RAY_GROUP, Vehicles.CAR_GROUP, false)
	-- Cars bump each other (set false for "ghost" races).
	PhysicsService:CollisionGroupSetCollidable(Vehicles.CAR_GROUP, Vehicles.CAR_GROUP, true)

	local active = Workspace:FindFirstChild("ActiveRace") or Instance.new("Folder")
	active.Name = "ActiveRace"
	active.Parent = Workspace
	carsFolder = Instance.new("Folder")
	carsFolder.Name = "Cars"
	carsFolder.Parent = active
end

function Vehicles.getCarsFolder(): Folder
	return carsFolder
end

function Vehicles.spawn(player: Player, slot: number, cf: CFrame): Model
	local livery = LIVERIES[((slot - 1) % #LIVERIES) + 1]
	local car = CarFactory.build({
		name = "Car_" .. player.UserId,
		paint = livery.paint,
		accent = livery.accent,
		anchored = true,
	})
	car:SetAttribute("OwnerUserId", player.UserId)
	car:SetAttribute("OwnerName", player.DisplayName)
	car:PivotTo(cf)
	local chassis = car.PrimaryPart :: BasePart
	chassis.CollisionGroup = Vehicles.CAR_GROUP
	CollectionService:AddTag(car, "RiftCar")
	car.Parent = carsFolder
	return car
end

local function hideAndGhost(character: Model)
	for _, d in character:GetDescendants() do
		if d:IsA("BasePart") then
			d.CollisionGroup = Vehicles.DRIVER_GROUP
			d.Massless = true
			d.Transparency = 1
		elseif d:IsA("Decal") then
			d.Transparency = 1
		end
	end
end

-- Seats the player's character in the car. Yields briefly if the character
-- is still loading. Returns true on success.
function Vehicles.seat(player: Player, car: Model): boolean
	local character = player.Character
	if not character or not character.Parent then
		pcall(function()
			player:LoadCharacterAsync()
		end)
		character = player.Character or player.CharacterAdded:Wait()
	end
	assert(character)
	local humanoid = character:FindFirstChildOfClass("Humanoid") or character:WaitForChild("Humanoid", 5)
	local seat = car:FindFirstChild("DriverSeat")
	if not humanoid or not humanoid:IsA("Humanoid") or not seat or not seat:IsA("Seat") then
		return false
	end
	if humanoid.Health <= 0 then
		return false
	end
	humanoid.Sit = false
	character:PivotTo(seat.CFrame * CFrame.new(0, 3, 0))
	hideAndGhost(character)
	seat:Sit(humanoid)
	return true
end

-- GO: unanchor and give the driver network ownership of the car assembly.
function Vehicles.release(car: Model, player: Player)
	local chassis = car.PrimaryPart
	if not chassis then
		return
	end
	chassis.Anchored = false
	if chassis:CanSetNetworkOwnership() then
		chassis:SetNetworkOwner(player)
	end
end

function Vehicles.destroy(car: Model?)
	if car then
		car:Destroy()
	end
end

function Vehicles.clearAll()
	carsFolder:ClearAllChildren()
end

return Vehicles
