--!strict
-- Builds the lobby and every map's circuit at server start.

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local MapDefinitions = require(ReplicatedStorage.Shared.MapDefinitions)
local LobbyBuilder = require(script.Parent.Parent.Builders.LobbyBuilder)
local TrackBuilder = require(script.Parent.Parent.Builders.TrackBuilder)

local World = {}

World.lobby = (nil :: any) :: LobbyBuilder.LobbyHandles
local tracks: { [string]: TrackBuilder.TrackData } = {}

function World.init()
	local t0 = os.clock()
	World.lobby = LobbyBuilder.build(Workspace)
	local tracksFolder = Instance.new("Folder")
	tracksFolder.Name = "Tracks"
	tracksFolder.Parent = Workspace
	for id, def in MapDefinitions.Maps do
		tracks[id] = TrackBuilder.build(def, tracksFolder)
	end
	local parts = 0
	for _, d in Workspace:GetDescendants() do
		if d:IsA("BasePart") then
			parts += 1
		end
	end
	print(string.format("[RiftRacers] World built in %.2fs · %d parts", os.clock() - t0, parts))
end

function World.getTrack(mapId: string): TrackBuilder.TrackData
	local t = tracks[mapId]
	assert(t, "Unknown map " .. mapId)
	return t
end

return World
