--!strict
-- RIFT RACERS · the single server entry point.
-- Two-phase boot: every system init()s (sync wiring), then every system
-- start()s (loops). Order is explicit because World must exist before Race.

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Net = require(ReplicatedStorage.Shared.Net)
local Config = require(ReplicatedStorage.Shared.Config)

Net.serverInit()

local Systems = script:WaitForChild("Systems")
local ORDER = { "Vehicles", "World", "Race" }

local loaded: { [string]: any } = {}
for _, name in ORDER do
	loaded[name] = require(Systems:WaitForChild(name) :: ModuleScript) :: any
end
for _, name in ORDER do
	local sys = loaded[name]
	if typeof(sys.init) == "function" then
		sys.init()
	end
end
for _, name in ORDER do
	local sys = loaded[name]
	if typeof(sys.start) == "function" then
		task.spawn(sys.start)
	end
end

print("[RiftRacers] Server ready · " .. Config.Version)
