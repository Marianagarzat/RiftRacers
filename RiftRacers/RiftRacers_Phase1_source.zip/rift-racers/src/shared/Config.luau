--!strict
-- RIFT RACERS · central tunables (Phase 1)
-- Everything a designer may want to balance lives here. The client can read
-- this module; the server still re-validates anything that matters.

local Config = {}

Config.Version = "0.1.0-phase1"

-- ── Race rules ────────────────────────────────────────────────────────────
Config.Race = {
	DefaultMap = "CyberpulseCity",
	Laps = 3,
	MinPlayers = 1, -- 1 = solo practice allowed (Phase 1 testing). Raise later.
	MaxPlayers = 8,
	QueueSeconds = 10, -- after the first player joins the queue
	QueueFullStartSeconds = 3, -- when the queue is full
	IntroSeconds = 4, -- camera flyover before countdown
	CountdownSeconds = 3, -- 3, 2, 1, GO
	FinishGraceSeconds = 25, -- after the winner finishes, others get this long
	MaxRaceSeconds = 420,
	ResultsSeconds = 14,
	StandingsHz = 4,
	RecoverCooldown = 1.5,
	-- Anti-cheat (lenient on purpose — latency must not cause false positives)
	MinLapSeconds = 14,
	MaxPlausibleSpeed = 380, -- studs/s, averaged over a 0.5 s window
	SpeedStrikesBeforeReset = 2,
	KillY = -60,
}

-- ── Vehicle handling (identical for every car — no pay-to-win) ────────────
Config.Vehicle = {
	WheelRadius = 1.6,
	RestLength = 2.0, -- suspension travel from chassis centre to wheel top
	RestCompression = 0.9, -- studs of compression at rest
	SpringDamping = 0.55, -- damping ratio
	WheelOffsets = { -- local X/Z of the four suspension points (front = -Z)
		FL = Vector3.new(-3.1, 0, -4.6),
		FR = Vector3.new(3.1, 0, -4.6),
		RL = Vector3.new(-3.1, 0, 4.7),
		RR = Vector3.new(3.1, 0, 4.7),
	},
	TopSpeed = 165, -- studs/s
	BoostTopSpeed = 215,
	ReverseTopSpeed = 45,
	Acceleration = 70, -- studs/s²
	BoostAcceleration = 95,
	BrakeDeceleration = 140,
	CoastDeceleration = 14,
	Grip = 11, -- lateral velocity removed per second (fraction)
	DriftGrip = 1.6,
	MaxYawRateLow = 2.5, -- rad/s at low speed
	MaxYawRateHigh = 1.35, -- rad/s at top speed
	DriftYawMultiplier = 1.4,
	SteerResponse = 9,
	Downforce = 0.35, -- extra g per (speed / TopSpeed)
	AirStabilize = 3.0,
	BoostDrainPerSecond = 0.38,
	BoostPassiveRecharge = 0.03,
	BoostDriftRecharge = 0.22,
	DriftMinSpeed = 35,
	FlipRecoverSeconds = 2.0,
	-- Display: 1 stud ≈ 0.28 m → studs/s × 1.008 ≈ km/h
	SpeedDisplayMultiplier = 1.008,
	SpeedUnit = "KM/H",
}

-- ── Camera ────────────────────────────────────────────────────────────────
Config.Camera = {
	BaseFov = 70,
	SpeedFov = 20,
	BoostFov = 8,
	ChaseDistance = 17,
	ChaseHeight = 6,
	CloseDistance = 12,
	CloseHeight = 4.2,
	FollowSharpness = 7,
	DriftLeanDegrees = 3.5,
	ShakeAmplitude = 0.07,
}

-- ── Graphics presets (client) ─────────────────────────────────────────────
export type QualityName = "Ultra" | "Balanced" | "Performance"
export type QualityPreset = {
	RainRate: number,
	DecorLightFraction: number, -- 0..1 of tagged decorative lights left on
	DecorFx: boolean, -- steam vents etc.
	CarHeadlightSpots: boolean,
	BloomScale: number,
	DriftSmokeRate: number,
	SpeedLines: boolean,
	AmbientAnimationRange: number,
}
Config.Quality = {
	Ultra = {
		RainRate = 900,
		DecorLightFraction = 1,
		DecorFx = true,
		CarHeadlightSpots = true,
		BloomScale = 1,
		DriftSmokeRate = 60,
		SpeedLines = true,
		AmbientAnimationRange = 900,
	} :: QualityPreset,
	Balanced = {
		RainRate = 420,
		DecorLightFraction = 0.5,
		DecorFx = true,
		CarHeadlightSpots = true,
		BloomScale = 0.8,
		DriftSmokeRate = 32,
		SpeedLines = true,
		AmbientAnimationRange = 600,
	} :: QualityPreset,
	Performance = {
		RainRate = 140,
		DecorLightFraction = 0,
		DecorFx = false,
		CarHeadlightSpots = false,
		BloomScale = 0.55,
		DriftSmokeRate = 14,
		SpeedLines = false,
		AmbientAnimationRange = 350,
	} :: QualityPreset,
}

-- ── Audio ─────────────────────────────────────────────────────────────────
-- Intentionally EMPTY. Paste asset IDs ("rbxassetid://123…") of audio you own
-- or have licensed. Empty entries are simply skipped at runtime.
Config.Audio = {
	EngineLoop = "",
	TireScreech = "",
	BoostStart = "",
	CountdownBeep = "",
	CountdownGo = "",
	Checkpoint = "",
	LapComplete = "",
	RaceFinish = "",
	UiClick = "",
	MusicLobby = "",
	MusicCyberpulse = "",
	AmbienceCity = "",
}

-- ── Palette / UI ──────────────────────────────────────────────────────────
Config.UI = {
	Cyan = Color3.fromRGB(64, 224, 255),
	Pink = Color3.fromRGB(255, 56, 170),
	Violet = Color3.fromRGB(140, 82, 255),
	Gold = Color3.fromRGB(255, 196, 64),
	Danger = Color3.fromRGB(255, 72, 96),
	Panel = Color3.fromRGB(10, 10, 22),
	PanelLight = Color3.fromRGB(24, 22, 44),
	Text = Color3.fromRGB(240, 242, 255),
	TextDim = Color3.fromRGB(150, 156, 190),
}

return Config
