--!strict
-- Data-driven map definitions. Phase 1 ships Cyberpulse City only; Phase 5
-- adds the other four worlds by appending entries here + a builder theme.

export type SectionKind = "street" | "tunnel" | "underground" | "bridge"
export type Section = {
	name: string,
	from: number, -- control-point index where the section starts (inclusive)
	to: number, -- control-point index where it ends (exclusive, wraps)
	kind: SectionKind,
}
export type LightingPreset = {
	ClockTime: number,
	Brightness: number,
	Ambient: Color3,
	OutdoorAmbient: Color3,
	ExposureCompensation: number,
	AtmosphereDensity: number,
	AtmosphereOffset: number,
	AtmosphereColor: Color3,
	AtmosphereDecay: Color3,
	AtmosphereGlare: number,
	AtmosphereHaze: number,
	BloomIntensity: number,
	BloomSize: number,
	BloomThreshold: number,
	CCBrightness: number,
	CCContrast: number,
	CCSaturation: number,
	CCTint: Color3,
	SunRays: number,
	Rain: boolean,
}
export type MapDefinition = {
	id: string,
	displayName: string,
	tagline: string,
	origin: Vector3,
	roadWidth: number,
	sampleSpacing: number,
	checkpointCount: number,
	controlPoints: { Vector3 },
	sections: { Section },
	palette: { Color3 },
	lighting: LightingPreset,
}

local MapDefinitions = {}

MapDefinitions.Lobby = {
	ClockTime = 19.35,
	Brightness = 2.2,
	Ambient = Color3.fromRGB(38, 30, 62),
	OutdoorAmbient = Color3.fromRGB(78, 64, 120),
	ExposureCompensation = 0.1,
	AtmosphereDensity = 0.3,
	AtmosphereOffset = 0.15,
	AtmosphereColor = Color3.fromRGB(150, 110, 210),
	AtmosphereDecay = Color3.fromRGB(70, 40, 120),
	AtmosphereGlare = 0.35,
	AtmosphereHaze = 1.6,
	BloomIntensity = 0.55,
	BloomSize = 26,
	BloomThreshold = 1.6,
	CCBrightness = 0.02,
	CCContrast = 0.12,
	CCSaturation = 0.14,
	CCTint = Color3.fromRGB(238, 232, 255),
	SunRays = 0.05,
	Rain = false,
} :: LightingPreset

MapDefinitions.Maps = {
	CyberpulseCity = {
		id = "CyberpulseCity",
		displayName = "CYBERPULSE CITY",
		tagline = "Neon. Rain. Velocity.",
		origin = Vector3.new(4000, 0, 0),
		roadWidth = 46,
		sampleSpacing = 10,
		checkpointCount = 12,
		-- Closed loop, driven in list order. Y = road surface height.
		controlPoints = {
			Vector3.new(0, 0, 0), -- 1  start / finish
			Vector3.new(420, 0, -10), -- 2  Neon Avenue
			Vector3.new(820, 0, 10), -- 3
			Vector3.new(1080, 0, 120), -- 4
			Vector3.new(1180, 0, 360), -- 5  sweeping right-hander
			Vector3.new(1110, 8, 610), -- 6  climb begins
			Vector3.new(900, 34, 760), -- 7
			Vector3.new(600, 58, 820), -- 8  Skybridge Expressway
			Vector3.new(300, 58, 840), -- 9
			Vector3.new(20, 38, 860), -- 10 descent
			Vector3.new(-240, 10, 800), -- 11
			Vector3.new(-450, 0, 660), -- 12 Hologram Tunnel
			Vector3.new(-560, 0, 450), -- 13
			Vector3.new(-500, 0, 250), -- 14 Underground Circuit
			Vector3.new(-380, 0, 140), -- 15
			Vector3.new(-210, 0, 30), -- 16 back onto the boulevard
		},
		sections = {
			{ name = "CYBER FINISH BOULEVARD", from = 1, to = 2, kind = "street" },
			{ name = "NEON AVENUE", from = 2, to = 6, kind = "street" },
			{ name = "SKYBRIDGE EXPRESSWAY", from = 6, to = 11, kind = "bridge" },
			{ name = "HOLOGRAM TUNNEL", from = 11, to = 13, kind = "tunnel" },
			{ name = "UNDERGROUND CIRCUIT", from = 13, to = 15, kind = "underground" },
			{ name = "CYBER FINISH BOULEVARD", from = 15, to = 17, kind = "street" },
		},
		palette = {
			Color3.fromRGB(255, 56, 170), -- neon pink
			Color3.fromRGB(64, 200, 255), -- electric blue
			Color3.fromRGB(150, 80, 255), -- violet
			Color3.fromRGB(255, 120, 220),
			Color3.fromRGB(90, 120, 255),
		},
		lighting = {
			ClockTime = 0.2,
			Brightness = 1.1,
			Ambient = Color3.fromRGB(30, 20, 54),
			OutdoorAmbient = Color3.fromRGB(66, 44, 110),
			ExposureCompensation = 0.35,
			AtmosphereDensity = 0.38,
			AtmosphereOffset = 0.05,
			AtmosphereColor = Color3.fromRGB(120, 60, 170),
			AtmosphereDecay = Color3.fromRGB(36, 18, 80),
			AtmosphereGlare = 0,
			AtmosphereHaze = 2.3,
			BloomIntensity = 0.75,
			BloomSize = 30,
			BloomThreshold = 1.35,
			CCBrightness = 0.03,
			CCContrast = 0.18,
			CCSaturation = 0.25,
			CCTint = Color3.fromRGB(242, 226, 255),
			SunRays = 0,
			Rain = true,
		} :: LightingPreset,
	} :: MapDefinition,
} :: { [string]: MapDefinition }

return MapDefinitions
