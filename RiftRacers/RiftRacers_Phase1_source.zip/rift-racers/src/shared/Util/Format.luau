--!strict
local Format = {}

-- 83.456 → "1:23.456"
function Format.raceTime(seconds: number?): string
	if seconds == nil or seconds ~= seconds or seconds < 0 then
		return "--:--.---"
	end
	local s = seconds :: number
	local m = math.floor(s / 60)
	local rest = s - m * 60
	return string.format("%d:%06.3f", m, rest)
end

function Format.ordinal(n: number): string
	local suffix = "TH"
	local lastTwo = n % 100
	if lastTwo < 11 or lastTwo > 13 then
		local last = n % 10
		if last == 1 then
			suffix = "ST"
		elseif last == 2 then
			suffix = "ND"
		elseif last == 3 then
			suffix = "RD"
		end
	end
	return tostring(n) .. suffix
end

return Format
