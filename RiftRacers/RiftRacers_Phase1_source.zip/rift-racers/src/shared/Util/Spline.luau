--!strict
-- Closed centripetal Catmull-Rom spline, resampled at (near) constant spacing.
-- Pure math: used by the server track builder and testable outside Roblox.

export type Sample = {
	position: Vector3,
	tangent: Vector3, -- unit, direction of travel
	segment: number, -- control-point index this sample belongs to (1-based)
	distance: number, -- arc length from sample 1
}

local Spline = {}

local function tj(ti: number, a: Vector3, b: Vector3): number
	local d = (b - a).Magnitude
	return ti + math.max(d, 1e-4) ^ 0.5 -- alpha = 0.5 (centripetal)
end

local function catmull(p0: Vector3, p1: Vector3, p2: Vector3, p3: Vector3, u: number): Vector3
	local t0 = 0
	local t1 = tj(t0, p0, p1)
	local t2 = tj(t1, p1, p2)
	local t3 = tj(t2, p2, p3)
	local t = t1 + (t2 - t1) * u
	local a1 = p0 * ((t1 - t) / (t1 - t0)) + p1 * ((t - t0) / (t1 - t0))
	local a2 = p1 * ((t2 - t) / (t2 - t1)) + p2 * ((t - t1) / (t2 - t1))
	local a3 = p2 * ((t3 - t) / (t3 - t2)) + p3 * ((t - t2) / (t3 - t2))
	local b1 = a1 * ((t2 - t) / (t2 - t0)) + a2 * ((t - t0) / (t2 - t0))
	local b2 = a2 * ((t3 - t) / (t3 - t1)) + a3 * ((t - t1) / (t3 - t1))
	return b1 * ((t2 - t) / (t2 - t1)) + b2 * ((t - t1) / (t2 - t1))
end

-- Returns evenly spaced samples around the closed loop plus total length.
function Spline.sampleClosed(points: { Vector3 }, spacing: number): ({ Sample }, number)
	local n = #points
	assert(n >= 4, "need at least 4 control points")

	-- 1) dense polyline
	local dense: { Vector3 } = {}
	local denseSeg: { number } = {}
	local STEPS = 48
	for i = 1, n do
		local p0 = points[((i - 2) % n) + 1]
		local p1 = points[i]
		local p2 = points[(i % n) + 1]
		local p3 = points[((i + 1) % n) + 1]
		for s = 0, STEPS - 1 do
			table.insert(dense, catmull(p0, p1, p2, p3, s / STEPS))
			table.insert(denseSeg, i)
		end
	end
	table.insert(dense, dense[1])
	table.insert(denseSeg, 1)

	-- 2) cumulative length
	local cum = { 0 }
	for i = 2, #dense do
		cum[i] = cum[i - 1] + (dense[i] - dense[i - 1]).Magnitude
	end
	local total = cum[#cum]

	-- 3) resample
	local count = math.max(8, math.floor(total / spacing + 0.5))
	local step = total / count
	local samples: { Sample } = {}
	local j = 1
	for k = 0, count - 1 do
		local d = k * step
		while j < #dense - 1 and cum[j + 1] < d do
			j += 1
		end
		local segLen = cum[j + 1] - cum[j]
		local f = if segLen > 0 then (d - cum[j]) / segLen else 0
		local pos = dense[j]:Lerp(dense[j + 1], f)
		table.insert(samples, {
			position = pos,
			tangent = Vector3.zAxis, -- filled below
			segment = denseSeg[j],
			distance = d,
		})
	end
	for k = 1, count do
		local prev = samples[((k - 2) % count) + 1].position
		local nxt = samples[(k % count) + 1].position
		samples[k].tangent = (nxt - prev).Unit
	end
	return samples, total
end

-- Sample at an arbitrary distance along the loop (wraps).
function Spline.atDistance(samples: { Sample }, total: number, d: number): (Vector3, Vector3)
	d = d % total
	local count = #samples
	local step = total / count
	local idx = math.floor(d / step)
	local f = (d - idx * step) / step
	local a = samples[(idx % count) + 1]
	local b = samples[((idx + 1) % count) + 1]
	return a.position:Lerp(b.position, f), a.tangent:Lerp(b.tangent, f).Unit
end

return Spline
