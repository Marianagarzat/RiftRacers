--!strict
-- All 2D interface for Phase 1: lobby bar (PLAY / queue / settings),
-- race HUD (position, laps, timers, standings, speedometer, boost, drift,
-- countdown, banners, wrong-way, next-gate marker, speed lines),
-- results screen and settings panel. Built in code so it's version-
-- controlled and scales on every device. Every button does something.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local SoundService = game:GetService("SoundService")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage.Shared.Config)
local Net = require(ReplicatedStorage.Shared.Net)
local Format = require(ReplicatedStorage.Shared.Util.Format)
local Types = require(ReplicatedStorage.Shared.Types)
local MapDefinitions = require(ReplicatedStorage.Shared.MapDefinitions)
local RaceClient = require(script.Parent.RaceClient)
local Vehicle = require(script.Parent.Vehicle)
local Settings = require(script.Parent.Settings)

local UI = Config.UI
local RC = Config.Race
local player = Players.LocalPlayer

local HUD = {}

local DISPLAY = Font.fromEnum(Enum.Font.Michroma)
local BODY = Font.fromEnum(Enum.Font.BuilderSansBold)
local BODY_X = Font.fromEnum(Enum.Font.BuilderSansExtraBold)

-- ── tiny UI kit ───────────────────────────────────────────────────────────
local function new(className: string, props: { [string]: any }, children: { Instance }?): any
	local inst = Instance.new(className :: any)
	for k, v in props do
		if k ~= "Parent" then
			(inst :: any)[k] = v
		end
	end
	if children then
		for _, c in children do
			c.Parent = inst
		end
	end
	if props.Parent then
		inst.Parent = props.Parent
	end
	return inst
end

local function corner(r: number): UICorner
	return new("UICorner", { CornerRadius = UDim.new(0, r) })
end

local function stroke(color: Color3, thickness: number, transparency: number?): UIStroke
	return new("UIStroke", {
		Color = color,
		Thickness = thickness,
		Transparency = transparency or 0,
		ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
	})
end

local function gradient(a: Color3, b: Color3, rotation: number?): UIGradient
	return new("UIGradient", { Color = ColorSequence.new(a, b), Rotation = rotation or 0 })
end

local function text(props: { [string]: any }): TextLabel
	props.BackgroundTransparency = props.BackgroundTransparency or 1
	props.FontFace = props.FontFace or BODY
	props.TextColor3 = props.TextColor3 or UI.Text
	props.TextScaled = if props.TextScaled == nil then true else props.TextScaled
	return new("TextLabel", props)
end

local function panel(props: { [string]: any }, children: { Instance }?): Frame
	props.BackgroundColor3 = props.BackgroundColor3 or UI.Panel
	props.BackgroundTransparency = props.BackgroundTransparency or 0.18
	props.BorderSizePixel = 0
	local f = new("Frame", props, children)
	corner(10).Parent = f
	stroke(UI.Violet, 1, 0.55).Parent = f
	return f
end

local sounds: { [string]: Sound } = {}
local function play(key: string)
	local id = (Config.Audio :: any)[key]
	if type(id) ~= "string" or id == "" then
		return
	end
	local s = sounds[key]
	if not s then
		local snd = Instance.new("Sound")
		snd.SoundId = id
		snd.Parent = SoundService
		sounds[key] = snd
		s = snd
	end
	SoundService:PlayLocalSound(s :: Sound)
end

local function button(props: { [string]: any }, accent: Color3, onClick: () -> ()): TextButton
	props.BackgroundColor3 = props.BackgroundColor3 or UI.PanelLight
	props.AutoButtonColor = false
	props.FontFace = props.FontFace or DISPLAY
	props.TextColor3 = props.TextColor3 or UI.Text
	props.TextScaled = true
	props.BorderSizePixel = 0
	local b: TextButton = new("TextButton", props)
	corner(8).Parent = b
	local st = stroke(accent, 1.5, 0.2)
	st.Parent = b
	new("UIPadding", {
		PaddingTop = UDim.new(0.22, 0),
		PaddingBottom = UDim.new(0.22, 0),
		PaddingLeft = UDim.new(0, 10),
		PaddingRight = UDim.new(0, 10),
		Parent = b,
	})
	local scale = new("UIScale", { Parent = b })
	local quick = TweenInfo.new(0.12, Enum.EasingStyle.Quad)
	b.MouseEnter:Connect(function()
		TweenService:Create(scale, quick, { Scale = 1.04 }):Play()
		TweenService:Create(st, quick, { Thickness = 2.5, Transparency = 0 }):Play()
	end)
	b.MouseLeave:Connect(function()
		TweenService:Create(scale, quick, { Scale = 1 }):Play()
		TweenService:Create(st, quick, { Thickness = 1.5, Transparency = 0.2 }):Play()
	end)
	b.Activated:Connect(function()
		play("UiClick")
		scale.Scale = 0.95
		TweenService:Create(scale, TweenInfo.new(0.2, Enum.EasingStyle.Back), { Scale = 1 }):Play()
		onClick()
	end)
	return b
end

-- ── state ────────────────────────────────────────────────────────────────
local gui: ScreenGui
local lobbyLayer: Frame
local raceLayer: Frame
local resultsLayer: Frame
local settingsPanel: Frame
local playButton: TextButton
local queueCard: Frame
local queueTitle: TextLabel
local queueDetail: TextLabel
local posLabel: TextLabel
local posTotal: TextLabel
local lapLabel: TextLabel
local timeValue: TextLabel
local bestValue: TextLabel
local lastValue: TextLabel
local modeValue: TextLabel
local standingsRows: { Frame } = {}
local speedValue: TextLabel
local ticks: { Frame } = {}
local boostFill: Frame
local boostLabel: TextLabel
local driftTag: TextLabel
local countdownLabel: TextLabel
local countdownScale: UIScale
local banner: TextLabel
local bannerSub: TextLabel
local wrongWay: TextLabel
local speedLines: Frame
local lineFrames: { Frame } = {}
local resultsList: Frame
local resultsFooter: TextLabel
local leaveRaceButton: TextButton
local nextMarker: BillboardGui
local nextMarkerText: TextLabel
local qualityButtons: { [string]: TextButton } = {}
local cameraButtons: { [string]: TextButton } = {}
local motionButton: TextButton

local lastCountdown = -1
local resultsUntil = 0
local wrongWayTimer = 0
local lastGateDist: number? = nil
local lastSection: string? = nil
local bannerToken = 0

local function showBanner(main: string, sub: string?, color: Color3?, duration: number?)
	bannerToken += 1
	local token = bannerToken
	banner.Text = main
	banner.TextColor3 = color or UI.Text
	bannerSub.Text = sub or ""
	banner.Visible = true
	bannerSub.Visible = sub ~= nil
	banner.TextTransparency = 1
	bannerSub.TextTransparency = 1
	local info = TweenInfo.new(0.25, Enum.EasingStyle.Quad)
	TweenService:Create(banner, info, { TextTransparency = 0 }):Play()
	TweenService:Create(bannerSub, info, { TextTransparency = 0.15 }):Play()
	task.delay(duration or 2.2, function()
		if token ~= bannerToken then
			return
		end
		TweenService:Create(banner, info, { TextTransparency = 1 }):Play()
		TweenService:Create(bannerSub, info, { TextTransparency = 1 }):Play()
	end)
end

-- ── builders ─────────────────────────────────────────────────────────────
local function buildLobby()
	lobbyLayer = new("Frame", { Name = "Lobby", BackgroundTransparency = 1, Size = UDim2.fromScale(1, 1), Parent = gui })

	local brand = new("Frame", { BackgroundTransparency = 1, Position = UDim2.fromOffset(24, 18), Size = UDim2.fromOffset(320, 64), Parent = lobbyLayer })
	local title = text({ Text = "RIFT RACERS", FontFace = DISPLAY, Size = UDim2.new(1, 0, 0.62, 0), TextXAlignment = Enum.TextXAlignment.Left, Parent = brand })
	gradient(UI.Cyan, UI.Pink).Parent = title
	text({ Text = "THE NEXUS  ·  " .. Config.Version, TextColor3 = UI.TextDim, Position = UDim2.fromScale(0, 0.66), Size = UDim2.new(1, 0, 0.3, 0), TextXAlignment = Enum.TextXAlignment.Left, Parent = brand })

	playButton = button({
		Name = "Play",
		Text = "PLAY",
		AnchorPoint = Vector2.new(0.5, 1),
		Position = UDim2.new(0.5, 0, 1, -28),
		Size = UDim2.fromOffset(300, 64),
		BackgroundColor3 = UI.Pink,
		Parent = lobbyLayer,
	}, UI.Pink, function()
		Net.fireServer("RequestJoinQueue")
	end)
	-- gradient lives on a background child so it never tints the label text
	local playFill = new("Frame", { Name = "Fill", BackgroundColor3 = Color3.new(1, 1, 1), BorderSizePixel = 0, Size = UDim2.fromScale(1, 1), ZIndex = 0, Parent = playButton })
	corner(8).Parent = playFill
	gradient(UI.Pink, UI.Violet, 0).Parent = playFill
	playButton.BackgroundTransparency = 1
	-- children draw above their parent, so the label must be a child above Fill
	playButton.Text = ""
	text({ Name = "Label", Text = "PLAY", FontFace = DISPLAY, Size = UDim2.fromScale(1, 1), ZIndex = 2, Parent = playButton })
	text({
		Text = "FREE FOR ALL  ·  CYBERPULSE CITY",
		TextColor3 = UI.TextDim,
		AnchorPoint = Vector2.new(0.5, 1),
		Position = UDim2.new(0.5, 0, 1, -98),
		Size = UDim2.fromOffset(300, 18),
		Parent = lobbyLayer,
	})

	queueCard = panel({
		Name = "Queue",
		AnchorPoint = Vector2.new(0.5, 1),
		Position = UDim2.new(0.5, 0, 1, -24),
		Size = UDim2.fromOffset(380, 112),
		Visible = false,
		Parent = lobbyLayer,
	})
	queueTitle = text({ Text = "SEARCHING FOR RACERS", FontFace = DISPLAY, Position = UDim2.fromOffset(18, 12), Size = UDim2.new(1, -36, 0, 24), TextXAlignment = Enum.TextXAlignment.Left, Parent = queueCard })
	gradient(UI.Cyan, UI.Pink).Parent = queueTitle
	queueDetail = text({ Text = "", TextColor3 = UI.TextDim, Position = UDim2.fromOffset(18, 42), Size = UDim2.new(1, -36, 0, 20), TextXAlignment = Enum.TextXAlignment.Left, Parent = queueCard })
	button({ Text = "LEAVE QUEUE", AnchorPoint = Vector2.new(1, 1), Position = UDim2.new(1, -14, 1, -12), Size = UDim2.fromOffset(150, 34), Parent = queueCard }, UI.Danger, function()
		Net.fireServer("RequestLeaveQueue")
	end)
	text({ Text = "Tip: step onto the Race Portal pad too.", TextColor3 = UI.TextDim, Position = UDim2.new(0, 18, 1, -40), Size = UDim2.new(0.5, 0, 0, 16), TextXAlignment = Enum.TextXAlignment.Left, Parent = queueCard })
end

local function buildRace()
	raceLayer = new("Frame", { Name = "Race", BackgroundTransparency = 1, Size = UDim2.fromScale(1, 1), Visible = false, Parent = gui })

	-- speed lines (behind everything else)
	speedLines = new("Frame", { Name = "SpeedLines", BackgroundTransparency = 1, Size = UDim2.fromScale(1, 1), ClipsDescendants = true, Parent = raceLayer })
	local rng = Random.new(3)
	for i = 1, 26 do
		local angle = rng:NextNumber(0, math.pi * 2)
		local f = new("Frame", {
			BackgroundColor3 = Color3.new(1, 1, 1),
			BorderSizePixel = 0,
			AnchorPoint = Vector2.new(0.5, 0.5),
			Size = UDim2.new(0, 2, 0.12 + rng:NextNumber() * 0.12, 0),
			Rotation = math.deg(angle) - 90,
			BackgroundTransparency = 1,
			Parent = speedLines,
		})
		f:SetAttribute("Angle", angle)
		f:SetAttribute("Seed", rng:NextNumber())
		table.insert(lineFrames, f)
	end

	-- top centre: position + lap
	local top = new("Frame", { BackgroundTransparency = 1, AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.new(0.5, 0, 0, 10), Size = UDim2.fromOffset(300, 96), Parent = raceLayer })
	posLabel = text({ Text = "1ST", FontFace = DISPLAY, AnchorPoint = Vector2.new(1, 0), Position = UDim2.fromScale(0.6, 0), Size = UDim2.fromScale(0.6, 0.62), TextXAlignment = Enum.TextXAlignment.Right, Parent = top })
	gradient(Color3.new(1, 1, 1), UI.Cyan, 90).Parent = posLabel
	posTotal = text({ Text = "/ 1", TextColor3 = UI.TextDim, Position = UDim2.fromScale(0.63, 0.18), Size = UDim2.fromScale(0.35, 0.36), TextXAlignment = Enum.TextXAlignment.Left, FontFace = BODY_X, Parent = top })
	lapLabel = text({ Text = "LAP 1 / 3", FontFace = DISPLAY, TextColor3 = UI.Pink, AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.fromScale(0.5, 0.68), Size = UDim2.fromScale(0.7, 0.28), Parent = top })

	-- top right: timers
	local timers = panel({ AnchorPoint = Vector2.new(1, 0), Position = UDim2.new(1, -16, 0, 56), Size = UDim2.fromOffset(230, 132), Parent = raceLayer })
	local function row(y: number, label: string, big: boolean): TextLabel
		text({ Text = label, TextColor3 = UI.TextDim, Position = UDim2.fromOffset(14, y), Size = UDim2.fromOffset(70, if big then 18 else 16), TextXAlignment = Enum.TextXAlignment.Left, Parent = timers })
		return text({ Text = "--:--.---", FontFace = DISPLAY, Position = UDim2.new(0, 84, 0, y - (if big then 4 else 0)), Size = UDim2.new(1, -98, 0, if big then 26 else 16), TextXAlignment = Enum.TextXAlignment.Right, Parent = timers })
	end
	timeValue = row(14, "TIME", true)
	bestValue = row(50, "BEST LAP", false)
	lastValue = row(74, "LAST LAP", false)
	modeValue = row(100, "MODE", false)
	modeValue.Text = "FREE FOR ALL"
	modeValue.TextColor3 = UI.Cyan

	-- left: standings
	local standings = new("Frame", { BackgroundTransparency = 1, Position = UDim2.new(0, 16, 0.22, 0), Size = UDim2.fromOffset(220, 8 * 30), Parent = raceLayer })
	new("UIListLayout", { Padding = UDim.new(0, 4), SortOrder = Enum.SortOrder.LayoutOrder, Parent = standings })
	for i = 1, RC.MaxPlayers do
		local r = new("Frame", { BackgroundColor3 = UI.Panel, BackgroundTransparency = 0.3, Size = UDim2.new(1, 0, 0, 26), LayoutOrder = i, Visible = false, Parent = standings })
		corner(6).Parent = r
		text({ Name = "Pos", Text = tostring(i), FontFace = DISPLAY, Size = UDim2.new(0, 34, 1, -8), Position = UDim2.fromOffset(6, 4), Parent = r })
		text({ Name = "Name", Text = "", Size = UDim2.new(1, -90, 1, -8), Position = UDim2.fromOffset(44, 4), TextXAlignment = Enum.TextXAlignment.Left, Parent = r })
		text({ Name = "Lap", Text = "", TextColor3 = UI.TextDim, AnchorPoint = Vector2.new(1, 0), Size = UDim2.new(0, 40, 1, -10), Position = UDim2.new(1, -8, 0, 5), TextXAlignment = Enum.TextXAlignment.Right, Parent = r })
		new("Frame", { Name = "Accent", BackgroundColor3 = UI.Cyan, BorderSizePixel = 0, Size = UDim2.new(0, 3, 1, 0), Parent = r })
		table.insert(standingsRows, r)
	end

	-- bottom right: speedometer
	local speedo = new("Frame", { Name = "Speedometer", BackgroundTransparency = 1, AnchorPoint = Vector2.new(1, 1), Position = UDim2.new(1, -24, 1, -20), Size = UDim2.fromOffset(250, 230), Parent = raceLayer })
	local dial = new("Frame", { BackgroundColor3 = UI.Panel, BackgroundTransparency = 0.25, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromOffset(125, 118), Size = UDim2.fromOffset(196, 196), Parent = speedo })
	corner(98).Parent = dial
	stroke(UI.Violet, 1.5, 0.4).Parent = dial
	local N = 34
	for i = 0, N - 1 do
		local a = math.rad(135 + 270 * i / (N - 1))
		local r = 108
		local major = i % 5 == 0
		local tick = new("Frame", {
			BorderSizePixel = 0,
			AnchorPoint = Vector2.new(0.5, 0.5),
			Position = UDim2.fromOffset(125 + math.cos(a) * r, 118 + math.sin(a) * r),
			Size = UDim2.fromOffset(if major then 5 else 4, if major then 18 else 12),
			Rotation = math.deg(a) - 90,
			BackgroundColor3 = UI.PanelLight,
			Parent = speedo,
		})
		corner(2).Parent = tick
		table.insert(ticks, tick)
	end
	speedValue = text({ Text = "0", FontFace = DISPLAY, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromOffset(125, 104), Size = UDim2.fromOffset(150, 54), Parent = speedo })
	text({ Text = Config.Vehicle.SpeedUnit, TextColor3 = UI.TextDim, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromOffset(125, 140), Size = UDim2.fromOffset(80, 16), Parent = speedo })
	local boostBack = new("Frame", { BackgroundColor3 = UI.PanelLight, BorderSizePixel = 0, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromOffset(125, 172), Size = UDim2.fromOffset(120, 8), Parent = speedo })
	corner(4).Parent = boostBack
	boostFill = new("Frame", { BackgroundColor3 = Color3.new(1, 1, 1), BorderSizePixel = 0, Size = UDim2.fromScale(0.5, 1), Parent = boostBack })
	corner(4).Parent = boostFill
	gradient(UI.Cyan, UI.Gold).Parent = boostFill
	boostLabel = text({ Text = "BOOST", TextColor3 = UI.TextDim, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromOffset(125, 188), Size = UDim2.fromOffset(100, 14), FontFace = DISPLAY, Parent = speedo })
	driftTag = text({ Text = "DRIFT", FontFace = DISPLAY, TextColor3 = UI.Pink, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromOffset(125, 70), Size = UDim2.fromOffset(90, 18), Visible = false, Parent = speedo })

	-- centre: countdown, banners, wrong way
	countdownLabel = text({ Text = "", FontFace = DISPLAY, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.38), Size = UDim2.fromOffset(420, 150), Visible = false, Parent = raceLayer })
	countdownScale = new("UIScale", { Parent = countdownLabel })
	stroke(Color3.new(0, 0, 0), 3, 0.4).Parent = countdownLabel
	banner = text({ Text = "", FontFace = DISPLAY, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.24), Size = UDim2.fromOffset(640, 46), Visible = false, Parent = raceLayer })
	bannerSub = text({ Text = "", AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.new(0.5, 0, 0.24, 36), Size = UDim2.fromOffset(500, 22), TextColor3 = UI.TextDim, Visible = false, Parent = raceLayer })
	wrongWay = text({ Text = "⚠  WRONG WAY  ⚠", FontFace = DISPLAY, TextColor3 = UI.Danger, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.32), Size = UDim2.fromOffset(460, 44), Visible = false, Parent = raceLayer })

	text({
		Text = "W/S  drive   ·   A/D  steer   ·   SPACE  drift   ·   SHIFT  boost   ·   R  reset   ·   C  camera",
		TextColor3 = UI.TextDim,
		AnchorPoint = Vector2.new(0, 1),
		Position = UDim2.new(0, 16, 1, -14),
		Size = UDim2.fromOffset(620, 16),
		TextXAlignment = Enum.TextXAlignment.Left,
		Visible = UserInputService.KeyboardEnabled,
		Parent = raceLayer,
	})
end

local function buildResults()
	resultsLayer = new("Frame", { Name = "Results", BackgroundColor3 = Color3.new(0, 0, 0), BackgroundTransparency = 0.45, Size = UDim2.fromScale(1, 1), Visible = false, Parent = gui })
	local card = panel({ AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5), Size = UDim2.new(0.6, 0, 0.72, 0), BackgroundTransparency = 0.08, Parent = resultsLayer })
	new("UISizeConstraint", { MaxSize = Vector2.new(760, 560), MinSize = Vector2.new(320, 300), Parent = card })
	local title = text({ Text = "RACE RESULTS", FontFace = DISPLAY, Position = UDim2.new(0, 24, 0, 18), Size = UDim2.new(1, -48, 0, 34), TextXAlignment = Enum.TextXAlignment.Left, Parent = card })
	gradient(UI.Gold, UI.Pink).Parent = title
	local header = new("Frame", { BackgroundTransparency = 1, Position = UDim2.new(0, 24, 0, 64), Size = UDim2.new(1, -48, 0, 18), Parent = card })
	local cols: { { label: string, x: number, w: number } } = {
		{ label = "POS", x = 0, w = 0.12 },
		{ label = "DRIVER", x = 0.12, w = 0.44 },
		{ label = "TOTAL", x = 0.56, w = 0.22 },
		{ label = "BEST LAP", x = 0.78, w = 0.22 },
	}
	for _, h in cols do
		text({ Text = h.label, TextColor3 = UI.TextDim, Position = UDim2.fromScale(h.x, 0), Size = UDim2.fromScale(h.w, 1), TextXAlignment = Enum.TextXAlignment.Left, Parent = header })
	end
	resultsList = new("ScrollingFrame", {
		BackgroundTransparency = 1,
		BorderSizePixel = 0,
		Position = UDim2.new(0, 24, 0, 88),
		Size = UDim2.new(1, -48, 1, -170),
		ScrollBarThickness = 4,
		AutomaticCanvasSize = Enum.AutomaticSize.Y,
		CanvasSize = UDim2.new(),
		Parent = card,
	})
	new("UIListLayout", { Padding = UDim.new(0, 6), SortOrder = Enum.SortOrder.LayoutOrder, Parent = resultsList })
	resultsFooter = text({ Text = "", TextColor3 = UI.TextDim, AnchorPoint = Vector2.new(0, 1), Position = UDim2.new(0, 24, 1, -24), Size = UDim2.new(0.5, 0, 0, 18), TextXAlignment = Enum.TextXAlignment.Left, Parent = card })
	button({ Text = "BACK TO NEXUS", AnchorPoint = Vector2.new(1, 1), Position = UDim2.new(1, -24, 1, -18), Size = UDim2.fromOffset(210, 44), Parent = card }, UI.Cyan, function()
		Net.fireServer("RequestReturnToLobby")
		resultsLayer.Visible = false
	end)
end

local function refreshSettingsButtons()
	for name, b in qualityButtons do
		local on = Settings.quality == name
		b.BackgroundColor3 = if on then UI.Violet else UI.PanelLight
	end
	for name, b in cameraButtons do
		b.BackgroundColor3 = if Settings.cameraMode == name then UI.Violet else UI.PanelLight
	end
	motionButton.Text = if Settings.reducedMotion then "ON" else "OFF"
	motionButton.BackgroundColor3 = if Settings.reducedMotion then UI.Violet else UI.PanelLight
	leaveRaceButton.Visible = RaceClient.participating
end

local function buildSettings()
	button({ Name = "SettingsButton", Text = "⚙ SETTINGS", AnchorPoint = Vector2.new(1, 0), Position = UDim2.new(1, -16, 0, 10), Size = UDim2.fromOffset(150, 36), Parent = gui }, UI.Violet, function()
		settingsPanel.Visible = not settingsPanel.Visible
		refreshSettingsButtons()
	end)
	settingsPanel = panel({ Name = "Settings", AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5), Size = UDim2.fromOffset(460, 330), BackgroundTransparency = 0.05, Visible = false, ZIndex = 10, Parent = gui })
	text({ Text = "SETTINGS", FontFace = DISPLAY, Position = UDim2.fromOffset(22, 16), Size = UDim2.new(1, -44, 0, 28), TextXAlignment = Enum.TextXAlignment.Left, Parent = settingsPanel })
	local function section(y: number, label: string)
		text({ Text = label, TextColor3 = UI.TextDim, Position = UDim2.fromOffset(22, y), Size = UDim2.new(1, -44, 0, 16), TextXAlignment = Enum.TextXAlignment.Left, Parent = settingsPanel })
	end
	section(62, "GRAPHICS QUALITY")
	for i, q in { "Ultra", "Balanced", "Performance" } do
		qualityButtons[q] = button({ Text = string.upper(q), Position = UDim2.fromOffset(22 + (i - 1) * 142, 84), Size = UDim2.fromOffset(134, 36), Parent = settingsPanel }, UI.Cyan, function()
			Settings.setQuality(q :: any)
			refreshSettingsButtons()
		end)
	end
	section(134, "CAMERA  (C / D-PAD UP IN RACE)")
	for i, c in { "Chase", "Close", "Hood" } do
		cameraButtons[c] = button({ Text = string.upper(c), Position = UDim2.fromOffset(22 + (i - 1) * 142, 156), Size = UDim2.fromOffset(134, 36), Parent = settingsPanel }, UI.Cyan, function()
			Settings.setCamera(c :: any)
			refreshSettingsButtons()
		end)
	end
	section(208, "REDUCED MOTION  (no shake / lean, calmer FOV & animations)")
	motionButton = button({ Text = "OFF", Position = UDim2.fromOffset(22, 230), Size = UDim2.fromOffset(134, 36), Parent = settingsPanel }, UI.Cyan, function()
		Settings.setReducedMotion(not Settings.reducedMotion)
		refreshSettingsButtons()
	end)
	leaveRaceButton = button({ Text = "LEAVE RACE", Position = UDim2.fromOffset(22, 280), Size = UDim2.fromOffset(176, 36), Parent = settingsPanel }, UI.Danger, function()
		Net.fireServer("RequestReturnToLobby")
		settingsPanel.Visible = false
	end)
	button({ Text = "CLOSE", AnchorPoint = Vector2.new(1, 0), Position = UDim2.new(1, -22, 0, 280), Size = UDim2.fromOffset(134, 36), Parent = settingsPanel }, UI.Violet, function()
		settingsPanel.Visible = false
	end)
end

local function buildNextMarker()
	nextMarker = new("BillboardGui", {
		Name = "RiftNextGate",
		AlwaysOnTop = true,
		Size = UDim2.fromOffset(140, 56),
		StudsOffsetWorldSpace = Vector3.new(0, 6, 0),
		MaxDistance = 2500,
		LightInfluence = 0,
		Enabled = false,
		Parent = player:WaitForChild("PlayerGui"),
	})
	text({ Text = "▼", FontFace = DISPLAY, TextColor3 = UI.Pink, Position = UDim2.fromScale(0, 0.45), Size = UDim2.fromScale(1, 0.55), Parent = nextMarker })
	nextMarkerText = text({ Text = "NEXT", FontFace = DISPLAY, TextColor3 = Color3.new(1, 1, 1), Size = UDim2.fromScale(1, 0.42), Parent = nextMarker })
end

-- ── data → UI ────────────────────────────────────────────────────────────
local function gateModel(index: number): Model?
	local s = RaceClient.state
	if not s then
		return nil
	end
	local tracks = Workspace:FindFirstChild("Tracks")
	local map = tracks and tracks:FindFirstChild(s.mapId)
	local cps = map and map:FindFirstChild("Checkpoints")
	local g = cps and cps:FindFirstChild("Gate" .. index)
	return if g and g:IsA("Model") then g else nil
end

local function onStateChanged(s: Types.RaceStatePayload)
	local phase = RaceClient.phase()
	local racing = phase ~= "Idle"
	lobbyLayer.Visible = not racing
	raceLayer.Visible = racing and phase ~= "Results"
	if not racing then
		resultsLayer.Visible = false
		nextMarker.Enabled = false
		countdownLabel.Visible = false
	end
	if phase == "Intro" then
		lastCountdown = -1
		lastSection = nil
		lapLabel.Text = string.format("LAP 1 / %d", s.laps)
		bestValue.Text = "--:--.---"
		lastValue.Text = "--:--.---"
		modeValue.Text = s.modeName
		local def = MapDefinitions.Maps[s.mapId]
		showBanner(s.mapName, if def then def.tagline else nil, UI.Cyan, 3.2)
	end
	refreshSettingsButtons()
end

local function onProgress(p: Types.ProgressPayload)
	local s = RaceClient.state
	if not s then
		return
	end
	lapLabel.Text = if p.finished then "FINISHED" else string.format("LAP %d / %d", p.lap, s.laps)
	bestValue.Text = Format.raceTime(p.bestLapTime)
	lastValue.Text = Format.raceTime(p.lastLapTime)
	lastGateDist = nil
	if p.event == "lap" then
		play("LapComplete")
		if p.lap == s.laps then
			showBanner("FINAL LAP", "Last lap  " .. Format.raceTime(p.lastLapTime), UI.Gold, 2.6)
		else
			showBanner(string.format("LAP %d", p.lap), "Last lap  " .. Format.raceTime(p.lastLapTime), UI.Cyan, 2.2)
		end
	elseif p.event == "finish" then
		play("RaceFinish")
		local pos = RaceClient.myPosition()
		showBanner("FINISH!", (if pos then Format.ordinal(pos) .. "  ·  " else "") .. Format.raceTime(p.finishTime), UI.Gold, 4)
	elseif p.event == "invalid" then
		showBanner("LAP INVALIDATED", "Drive through every checkpoint", UI.Danger, 2.5)
	elseif p.event == "checkpoint" then
		play("Checkpoint")
	end
	if p.section and p.section ~= lastSection and p.event ~= "finish" then
		if lastSection ~= nil and p.event == "checkpoint" then
			showBanner(p.section, nil, UI.Pink, 1.8)
		end
		lastSection = p.section
	end
	-- next-gate marker
	local g = if p.finished then nil else gateModel(p.nextCheckpoint)
	local beam = g and g:FindFirstChild("Beam")
	if beam and beam:IsA("BasePart") then
		nextMarker.Adornee = beam
		nextMarker.Enabled = true
	else
		nextMarker.Enabled = false
	end
end

local function onStandings(rows: { Types.StandingRow })
	for i, frame in standingsRows do
		local r = rows[i]
		frame.Visible = r ~= nil
		if r then
			local me = r.u == player.UserId
			;(frame:FindFirstChild("Pos") :: TextLabel).Text = tostring(r.p)
			;(frame:FindFirstChild("Name") :: TextLabel).Text = RaceClient.nameOf(r.u)
			;(frame:FindFirstChild("Lap") :: TextLabel).Text = if r.f then "🏁" else ("L" .. r.l)
			frame.BackgroundColor3 = if me then UI.Violet else UI.Panel
			frame.BackgroundTransparency = if me then 0.1 else 0.3
			;(frame:FindFirstChild("Accent") :: Frame).BackgroundColor3 = if r.p == 1 then UI.Gold elseif me then UI.Pink else UI.Cyan
		end
	end
	local pos, total = RaceClient.myPosition()
	if pos then
		posLabel.Text = Format.ordinal(pos)
		posTotal.Text = "/ " .. total
	end
end

local function onResults(rows: { Types.ResultRow })
	for _, c in resultsList:GetChildren() do
		if c:IsA("Frame") then
			c:Destroy()
		end
	end
	for i, r in rows do
		local me = r.userId == player.UserId
		local f = new("Frame", { BackgroundColor3 = if me then UI.Violet else UI.PanelLight, BackgroundTransparency = if me then 0.15 else 0.35, Size = UDim2.new(1, -6, 0, 38), LayoutOrder = i, Parent = resultsList })
		corner(6).Parent = f
		local col = if r.position == 1 then UI.Gold elseif r.position == 2 then Color3.fromRGB(210, 220, 235) elseif r.position == 3 then Color3.fromRGB(230, 150, 90) else UI.Text
		text({ Text = if r.finished then Format.ordinal(r.position) else "DNF", FontFace = DISPLAY, TextColor3 = if r.finished then col else UI.Danger, Position = UDim2.new(0, 10, 0, 8), Size = UDim2.new(0.12, -10, 1, -16), TextXAlignment = Enum.TextXAlignment.Left, Parent = f })
		text({ Text = r.name, Position = UDim2.new(0.12, 0, 0, 8), Size = UDim2.new(0.44, 0, 1, -16), TextXAlignment = Enum.TextXAlignment.Left, Parent = f })
		text({ Text = if r.finished then Format.raceTime(r.totalTime) else "—", FontFace = DISPLAY, Position = UDim2.new(0.56, 0, 0, 10), Size = UDim2.new(0.22, 0, 1, -20), TextXAlignment = Enum.TextXAlignment.Left, Parent = f })
		text({ Text = Format.raceTime(r.bestLap), FontFace = DISPLAY, TextColor3 = UI.TextDim, Position = UDim2.new(0.78, 0, 0, 10), Size = UDim2.new(0.22, -10, 1, -20), TextXAlignment = Enum.TextXAlignment.Left, Parent = f })
	end
	resultsUntil = os.clock() + RC.ResultsSeconds
	resultsLayer.Visible = true
	raceLayer.Visible = false
	nextMarker.Enabled = false
end

local function onQueue(q: Types.QueuePayload)
	playButton.Visible = not q.inQueue
	queueCard.Visible = q.inQueue
	if q.inQueue then
		if q.raceRunning then
			queueTitle.Text = "YOU'RE NEXT"
			queueDetail.Text = string.format("A race is running · %d queued · it starts right after", q.count)
		else
			queueTitle.Text = "SEARCHING FOR RACERS"
			local secs = if q.startsAt then math.max(0, math.ceil((q.startsAt :: number) - RaceClient.now())) else 0
			queueDetail.Text = string.format("%d / %d racers  ·  starting in %ds", q.count, q.max, secs)
		end
	end
end

-- ── per-frame ────────────────────────────────────────────────────────────
local function update(dt: number)
	local phase = RaceClient.phase()
	if phase == "Idle" then
		return
	end
	local s = RaceClient.state :: Types.RaceStatePayload
	local now = RaceClient.now()
	local tel = Vehicle.telemetry
	local prog = RaceClient.progress
	local q = Settings.preset()

	-- countdown
	local remaining = s.goTime - now
	if remaining <= RC.CountdownSeconds and remaining > -1 then
		countdownLabel.Visible = true
		local n = if remaining > 0 then math.ceil(remaining) else 0
		if n ~= lastCountdown then
			lastCountdown = n
			countdownLabel.Text = if n > 0 then tostring(n) else "GO!"
			countdownLabel.TextColor3 = if n == 0 then Color3.fromRGB(60, 255, 140) elseif n == 1 then UI.Gold else UI.Text
			countdownScale.Scale = 1.8
			TweenService:Create(countdownScale, TweenInfo.new(0.45, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Scale = 1 }):Play()
			play(if n > 0 then "CountdownBeep" else "CountdownGo")
		end
		countdownLabel.TextTransparency = if remaining < 0 then -remaining else 0
	else
		countdownLabel.Visible = false
	end

	-- timer
	local elapsed = math.max(0, now - s.goTime)
	if prog and prog.finished and prog.finishTime then
		elapsed = prog.finishTime :: number
	end
	timeValue.Text = if now < s.goTime then "0:00.000" else Format.raceTime(elapsed)

	-- speedometer
	local display = math.floor(tel.speedAbs * Config.Vehicle.SpeedDisplayMultiplier + 0.5)
	speedValue.Text = tostring(display)
	local ratio = math.clamp(tel.speedAbs / Config.Vehicle.BoostTopSpeed, 0, 1)
	local lit = math.floor(ratio * #ticks + 0.5)
	for i, tick in ticks do
		if i <= lit then
			local f = i / #ticks
			tick.BackgroundColor3 = if tel.boosting then UI.Gold elseif f > 0.78 then UI.Pink else UI.Cyan:Lerp(UI.Violet, f)
		else
			tick.BackgroundColor3 = UI.PanelLight
		end
	end
	boostFill.Size = UDim2.fromScale(math.clamp(tel.boost, 0, 1), 1)
	boostLabel.TextColor3 = if tel.boosting then UI.Gold elseif tel.boost > 0.98 then UI.Cyan else UI.TextDim
	boostLabel.Text = if tel.boosting then "BOOSTING" elseif tel.boost > 0.98 then "BOOST READY" else "BOOST"
	driftTag.Visible = tel.drifting

	-- speed lines
	local intensity = if q.SpeedLines and not Settings.reducedMotion then math.clamp((ratio - 0.62) / 0.3, 0, 1) else 0
	if tel.boosting and q.SpeedLines and not Settings.reducedMotion then
		intensity = math.max(intensity, 0.8)
	end
	speedLines.Visible = intensity > 0
	if intensity > 0 then
		local t = os.clock()
		for _, f in lineFrames do
			local angle = f:GetAttribute("Angle") :: number
			local seed = f:GetAttribute("Seed") :: number
			local travel = (t * 1.8 + seed) % 1
			local r = 0.32 + travel * 0.45
			f.Position = UDim2.fromScale(0.5 + math.cos(angle) * r * 0.75, 0.5 + math.sin(angle) * r)
			f.BackgroundTransparency = 1 - intensity * 0.35 * (1 - travel)
		end
	end

	-- wrong-way detection: moving away from the next gate for a while
	if prog and not prog.finished and phase == "Racing" and tel.active then
		local g = gateModel(prog.nextCheckpoint)
		local cf = g and g:GetAttribute("GateCFrame")
		local car = RaceClient.car
		if typeof(cf) == "CFrame" and car and car.PrimaryPart then
			local d = (car.PrimaryPart.Position - cf.Position).Magnitude
			if lastGateDist and d > (lastGateDist :: number) + 0.05 and tel.speedAbs > 25 then
				wrongWayTimer += dt
			else
				wrongWayTimer = math.max(0, wrongWayTimer - dt * 2)
			end
			lastGateDist = d
			nextMarkerText.Text = string.format("NEXT · %dm", math.floor(d * 0.28))
		end
	else
		wrongWayTimer = 0
	end
	wrongWay.Visible = wrongWayTimer > 1.6

	if resultsLayer.Visible then
		resultsFooter.Text = string.format("Returning to the Nexus in %ds", math.max(0, math.ceil(resultsUntil - os.clock())))
	end
end

function HUD.init()
	gui = new("ScreenGui", {
		Name = "RiftHUD",
		ResetOnSpawn = false,
		IgnoreGuiInset = false,
		ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
		DisplayOrder = 10,
		Parent = player:WaitForChild("PlayerGui"),
	})
	buildLobby()
	buildRace()
	buildResults()
	buildSettings()
	buildNextMarker()
	refreshSettingsButtons()

	RaceClient.StateChanged:Connect(onStateChanged)
	RaceClient.ProgressChanged:Connect(onProgress)
	RaceClient.StandingsChanged:Connect(onStandings)
	RaceClient.Results:Connect(onResults)
	RaceClient.QueueChanged:Connect(onQueue)
	RaceClient.Notice:Connect(function(msg: string, kind: string)
		showBanner(msg, nil, if kind == "warn" then UI.Danger else UI.Cyan, 2.4)
	end)
	RaceClient.Recovered:Connect(function()
		lastGateDist = nil
		wrongWayTimer = 0
	end)
	Settings.Changed:Connect(refreshSettingsButtons)
end

function HUD.start()
	RunService.RenderStepped:Connect(update)
	-- queue countdown text ticks once a second even without new payloads
	task.spawn(function()
		while true do
			task.wait(0.5)
			local q = RaceClient.queue
			if q then
				onQueue(q)
			end
		end
	end)
end

return HUD
