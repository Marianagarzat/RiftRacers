--!strict
-- Lighting presets per location, post-processing, rain, graphics-quality
-- scaling and ALL ambient world animation: spinning signs, bobbing
-- balloons/islands/hearts, twinkling stars & string lights, marquee bulb
-- chases, cheering crowds, waving flags, blinking beacons, tunnel light
-- chase, pulsing boost pads, start lights and checkpoint highlight.
-- Registries drop instances when maps are unloaded (no leaks).

local CollectionService = game:GetService("CollectionService")
local Lighting = game:GetService("Lighting")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage.Shared.Config)
local MapDefinitions = require(ReplicatedStorage.Shared.MapDefinitions)
local RaceClient = require(script.Parent.RaceClient)
local Settings = require(script.Parent.Settings)

local RC = Config.Race

local Environment = {}

local atmosphere: Atmosphere
local bloom: BloomEffect
local cc: ColorCorrectionEffect
local sunRays: SunRaysEffect
local dof: DepthOfFieldEffect
local rainPart: Part
local rainEmitter: ParticleEmitter
local currentPreset: MapDefinitions.LightingPreset? = nil

local function ensure<T>(className: string, name: string, parent: Instance): T
	local existing = parent:FindFirstChild(name)
	if existing and existing.ClassName == className then
		return existing :: any
	end
	local inst = Instance.new(className :: any)
	inst.Name = name
	inst.Parent = parent
	return inst :: any
end

local function applyPreset(p: MapDefinitions.LightingPreset, instant: boolean)
	currentPreset = p
	local info = TweenInfo.new(if instant then 0 else 1.4, Enum.EasingStyle.Sine)
	local scale = Settings.preset().BloomScale
	Lighting.ClockTime = p.ClockTime
	TweenService:Create(Lighting, info, { Brightness = p.Brightness, Ambient = p.Ambient, OutdoorAmbient = p.OutdoorAmbient, ExposureCompensation = p.ExposureCompensation }):Play()
	TweenService:Create(atmosphere, info, { Density = p.AtmosphereDensity, Offset = p.AtmosphereOffset, Color = p.AtmosphereColor, Decay = p.AtmosphereDecay, Glare = p.AtmosphereGlare, Haze = p.AtmosphereHaze }):Play()
	TweenService:Create(bloom, info, { Intensity = p.BloomIntensity * scale, Size = p.BloomSize, Threshold = p.BloomThreshold }):Play()
	TweenService:Create(cc, info, { Brightness = p.CCBrightness, Contrast = p.CCContrast, Saturation = p.CCSaturation, TintColor = p.CCTint }):Play()
	sunRays.Intensity = p.SunRays
	sunRays.Enabled = p.SunRays > 0
end

local function refreshLocation()
	local s = RaceClient.state
	if RaceClient.participating and s then
		local def = MapDefinitions.Maps[s.mapId]
		if def then
			applyPreset(def.lighting, false)
			return
		end
	end
	applyPreset(MapDefinitions.Lobby, false)
end

local function applyQuality()
	local q = Settings.preset()
	local i = 0
	for _, l in CollectionService:GetTagged("DecorLight") do
		if l:IsA("Light") then
			i += 1
			local keep = q.DecorLightFraction >= 1 or (q.DecorLightFraction > 0 and (i % math.max(1, math.floor(1 / q.DecorLightFraction + 0.5))) == 0)
			l.Enabled = keep
		end
	end
	for _, e in CollectionService:GetTagged("DecorFX") do
		if e:IsA("ParticleEmitter") then
			e.Enabled = q.DecorFx
		end
	end
	rainEmitter.Rate = q.RainRate
	if currentPreset then
		bloom.Intensity = (currentPreset :: MapDefinitions.LightingPreset).BloomIntensity * q.BloomScale
	end
end

-- ── Registries (keyed by instance so removal is O(1)) ────────────────────
type Spinner = { model: Model, base: CFrame, pivot: Vector3, speed: number, bob: number }
type Bobber = { model: Model, base: CFrame, phase: number }
type Ring = { parts: { BasePart }, pos: Vector3, phase: number, underground: boolean }
type Crowd = { model: Model, base: CFrame, phase: number }
local spinners: { [Instance]: Spinner } = {}
local bobbers: { [Instance]: Bobber } = {}
local rings: { [Instance]: Ring } = {}
local crowds: { [Instance]: Crowd } = {}
local gradients: { [Instance]: number } = {}
local pulses: { [Instance]: boolean } = {}
local twinkles: { [Instance]: number } = {}
local marquee: { [Instance]: number } = {}
local blinks: { [Instance]: number } = {}
local boostPads: { [Instance]: boolean } = {}
local startLights: { [number]: BasePart } = {}
local gates: { [number]: Model } = {}

local function collectParts(m: Instance): { BasePart }
	local list = {}
	for _, d in m:GetDescendants() do
		if d:IsA("BasePart") then
			table.insert(list, d)
		end
	end
	return list
end

local function register(tag: string, add: (Instance) -> (), remove: (Instance) -> ())
	for _, inst in CollectionService:GetTagged(tag) do
		task.spawn(add, inst)
	end
	CollectionService:GetInstanceAddedSignal(tag):Connect(add)
	CollectionService:GetInstanceRemovedSignal(tag):Connect(remove)
end

local RING_DIM_A = Color3.fromRGB(70, 20, 60)
local RING_DIM_U = Color3.fromRGB(70, 30, 10)

local lastNext = -1
local crowdFrame = 0
local function highlightGate(nextIndex: number)
	if nextIndex == lastNext then
		return
	end
	lastNext = nextIndex
	for idx, gate in gates do
		if idx ~= 0 and gate.Parent then
			local base = gate:GetAttribute("BaseColor")
			for _, d in gate:GetChildren() do
				if d:IsA("BasePart") and d.Name == "Post" then
					if typeof(base) ~= "Color3" then
						gate:SetAttribute("BaseColor", d.Color)
						base = d.Color
					end
					d.Color = if idx == nextIndex then Color3.fromRGB(255, 255, 255) else base :: Color3
					d.Transparency = if idx == nextIndex then 0 else 0.25
				end
			end
		end
	end
end

local function near(p: Vector3, camPos: Vector3, range: number): boolean
	return (p - camPos).Magnitude < range
end

local function animate(dt: number)
	local t = os.clock()
	local camPos = Workspace.CurrentCamera.CFrame.Position
	local q = Settings.preset()
	local range = q.AmbientAnimationRange
	local motion = if Settings.reducedMotion then 0.35 else 1

	for m, s in spinners do
		if not m.Parent then
			spinners[m] = nil
		elseif near(s.pivot, camPos, range) then
			local angle = t * s.speed * motion
			local bob = math.sin(t * 1.3) * s.bob * motion
			local rot = CFrame.new(s.pivot) * CFrame.Angles(0, angle, 0) * CFrame.new(-s.pivot)
			s.model:PivotTo((rot * s.base) + Vector3.new(0, bob, 0))
		end
	end
	for m, b in bobbers do
		if not m.Parent then
			bobbers[m] = nil
		elseif near(b.base.Position, camPos, range) then
			b.model:PivotTo(b.base * CFrame.new(0, math.sin(t * 1.1 + b.phase) * 1.6 * motion, 0) * CFrame.Angles(0, math.sin(t * 0.5 + b.phase) * 0.15 * motion, 0))
		end
	end
	crowdFrame += 1
	for m, c in crowds do
		if not m.Parent then
			crowds[m] = nil
		elseif crowdFrame % 3 == 0 and near(c.base.Position, camPos, math.min(range, 350)) then
			local racing = RaceClient.phase() == "Racing"
			local amp = if racing then 0.9 else 0.35
			local hop = math.max(0, math.sin(t * (if racing then 9 else 4) + c.phase)) * amp * motion
			c.model:PivotTo(c.base + Vector3.new(0, hop, 0))
		end
	end
	for g, i in gradients do
		if not g.Parent then
			gradients[g] = nil
		else
			(g :: UIGradient).Offset = Vector2.new(math.sin(t * 0.7 + i) * 0.6 * motion, 0)
		end
	end
	for part, phase in twinkles do
		if not part.Parent then
			twinkles[part] = nil
		elseif part:IsA("BasePart") then
			part.Transparency = 0.15 + (math.sin(t * 3 + phase) + 1) * 0.3
		elseif part:IsA("Model") then
			for _, c in part:GetChildren() do
				if c:IsA("BasePart") then
					c.Transparency = (math.sin(t * 3 + phase) + 1) * 0.3
				end
			end
		end
	end
	for b, order in marquee do
		if not b.Parent then
			marquee[b] = nil
		else
			local on = (math.floor(t * 8 * motion) + order) % 3 == 0
			;(b :: BasePart).Color = if on then Color3.fromRGB(255, 255, 230) else Color3.fromRGB(255, 170, 60)
		end
	end
	for b, phase in blinks do
		if not b.Parent then
			blinks[b] = nil
		else
			(b :: BasePart).Transparency = if (t + phase) % 2 < 0.25 then 0 else 0.85
		end
	end
	local padPulse = (math.sin(t * 6) + 1) / 2
	for pad in boostPads do
		if not pad.Parent then
			boostPads[pad] = nil
		else
			(pad :: BasePart).Color = Color3.fromRGB(255, 160, 30):Lerp(Color3.fromRGB(255, 240, 120), padPulse)
		end
	end
	for r in rings do
		local ring = rings[r]
		if not r.Parent then
			rings[r] = nil
		elseif near(ring.pos, camPos, range) then
			local wave = (math.sin(t * 7 * motion - ring.phase * 0.7) + 1) / 2
			local bright = if ring.underground then Color3.fromRGB(255, 130, 40) else (if ring.phase % 2 == 0 then Config.UI.Pink else Config.UI.Cyan)
			local col = (if ring.underground then RING_DIM_U else RING_DIM_A):Lerp(bright, wave ^ 2)
			for _, p in ring.parts do
				p.Color = col
			end
		end
	end
	local pulse = (math.sin(t * 1.6) + 1) / 2
	for m in pulses do
		if not m.Parent then
			pulses[m] = nil
		else
			for _, p in m:GetChildren() do
				if p:IsA("BasePart") then
					p.Transparency = 0.1 + pulse * 0.35 * motion
				end
			end
		end
	end

	-- start lights + checkpoint highlight
	local s = RaceClient.state
	if s and s.phase ~= "Idle" then
		local now = RaceClient.now()
		local cdStart = s.goTime - RC.CountdownSeconds
		local lit = 0
		local green = false
		if now >= s.goTime and now < s.goTime + 2.5 then
			green = true
		elseif now >= cdStart and now < s.goTime then
			lit = math.clamp(math.floor((now - cdStart) / (RC.CountdownSeconds / 5)) + 1, 1, 5)
		end
		for order, bulb in startLights do
			if not bulb.Parent then
				startLights[order] = nil
			elseif green then
				bulb.Color = Color3.fromRGB(40, 255, 120)
			elseif order <= lit then
				bulb.Color = Color3.fromRGB(255, 30, 50)
			else
				bulb.Color = Color3.fromRGB(60, 10, 14)
			end
		end
	end
	local prog = RaceClient.progress
	if RaceClient.participating and prog and not prog.finished then
		highlightGate(prog.nextCheckpoint)
	else
		highlightGate(-1)
	end

	if rainEmitter.Enabled then
		rainPart.CFrame = CFrame.new(camPos + Vector3.new(0, 45, 0))
	end
	local _ = dt
end

function Environment.init()
	atmosphere = ensure("Atmosphere", "RiftAtmosphere", Lighting)
	bloom = ensure("BloomEffect", "RiftBloom", Lighting)
	cc = ensure("ColorCorrectionEffect", "RiftGrade", Lighting)
	sunRays = ensure("SunRaysEffect", "RiftSunRays", Lighting)
	dof = ensure("DepthOfFieldEffect", "RiftDOF", Lighting)
	dof.Enabled = false
	dof.FarIntensity = 0.3
	dof.FocusDistance = 25
	dof.InFocusRadius = 30
	dof.NearIntensity = 0
	local sky = Lighting:FindFirstChildOfClass("Sky") or Instance.new("Sky")
	sky.StarCount = 3000
	sky.Parent = Lighting

	rainPart = Instance.new("Part")
	rainPart.Name = "RiftRain"
	rainPart.Anchored = true
	rainPart.CanCollide = false
	rainPart.CanQuery = false
	rainPart.CanTouch = false
	rainPart.Transparency = 1
	rainPart.Size = Vector3.new(180, 1, 180)
	rainPart.Parent = Workspace.CurrentCamera
	rainEmitter = Instance.new("ParticleEmitter")
	rainEmitter.Name = "Rain"
	rainEmitter.Texture = "rbxasset://textures/particles/smoke_main.dds"
	rainEmitter.Color = ColorSequence.new(Color3.fromRGB(190, 200, 255))
	rainEmitter.LightEmission = 0.4
	rainEmitter.Orientation = Enum.ParticleOrientation.VelocityParallel
	rainEmitter.Size = NumberSequence.new(0.12)
	rainEmitter.Squash = NumberSequence.new(-2.6)
	rainEmitter.Transparency = NumberSequence.new(0.45)
	rainEmitter.Lifetime = NumberRange.new(0.6, 0.8)
	rainEmitter.Speed = NumberRange.new(95, 115)
	rainEmitter.EmissionDirection = Enum.NormalId.Bottom
	rainEmitter.Acceleration = Vector3.new(4, 0, 2)
	rainEmitter.Enabled = false
	rainEmitter.Parent = rainPart

	local function drop(map: { [Instance]: any })
		return function(inst: Instance)
			map[inst] = nil
		end
	end
	register("Spin", function(inst)
		if inst:IsA("Model") then
			local pivot = inst:GetAttribute("Pivot")
			spinners[inst] = {
				model = inst,
				base = inst:GetPivot(),
				pivot = if typeof(pivot) == "Vector3" then pivot else inst:GetPivot().Position,
				speed = (inst:GetAttribute("SpinSpeed") :: number?) or 0.2,
				bob = (inst:GetAttribute("Bob") :: number?) or 0,
			}
		end
	end, drop(spinners))
	register("SpinSlow", function(inst)
		if inst:IsA("Model") then
			local pivot = inst:GetAttribute("Pivot")
			spinners[inst] = { model = inst, base = inst:GetPivot(), pivot = if typeof(pivot) == "Vector3" then pivot else inst:GetPivot().Position, speed = 0.6, bob = 0 }
		end
	end, drop(spinners))
	register("Bob", function(inst)
		if inst:IsA("Model") then
			bobbers[inst] = { model = inst, base = inst:GetPivot(), phase = math.random() * 6 }
		end
	end, drop(bobbers))
	register("CrowdRow", function(inst)
		if inst:IsA("Model") then
			crowds[inst] = { model = inst, base = inst:GetPivot(), phase = (inst:GetAttribute("Phase") :: number?) or 0 }
		end
	end, drop(crowds))
	register("TunnelRing", function(inst)
		if inst:IsA("Model") then
			rings[inst] = { parts = collectParts(inst), pos = inst:GetPivot().Position, phase = (inst:GetAttribute("Phase") :: number?) or 0, underground = inst:GetAttribute("Underground") == true }
		end
	end, drop(rings))
	local gi = 0
	register("HoloGradient", function(inst)
		gi += 1
		gradients[inst] = gi
	end, drop(gradients))
	register("NeonPulse", function(inst)
		pulses[inst] = true
	end, drop(pulses))
	register("Twinkle", function(inst)
		twinkles[inst] = math.random() * 6
	end, drop(twinkles))
	register("TwinkleLights", function(inst)
		for _, c in inst:GetChildren() do
			if c:IsA("BasePart") and c.Name == "Bulb" then
				twinkles[c] = math.random() * 6
			end
		end
	end, function(inst)
		for _, c in inst:GetChildren() do
			twinkles[c] = nil
		end
	end)
	register("MarqueeBulb", function(inst)
		marquee[inst] = (inst:GetAttribute("Order") :: number?) or 0
	end, drop(marquee))
	register("Blink", function(inst)
		blinks[inst] = math.random() * 2
	end, drop(blinks))
	register("BoostPad", function(inst)
		boostPads[inst] = true
	end, drop(boostPads))
	register("StartLight", function(inst)
		if inst:IsA("BasePart") then
			startLights[(inst:GetAttribute("Order") :: number?) or 1] = inst
		end
	end, function() end)
	register("CheckpointGate", function(inst)
		if inst:IsA("Model") then
			gates[(inst:GetAttribute("CheckpointIndex") :: number?) or 0] = inst
			lastNext = -2
		end
	end, function(inst)
		for k, g in gates do
			if g == inst then
				gates[k] = nil
			end
		end
	end)
	local qualityQueued = false
	register("DecorLight", function()
		if not qualityQueued then
			qualityQueued = true
			task.delay(0.5, function()
				qualityQueued = false
				applyQuality()
			end)
		end
	end, function() end)

	applyPreset(MapDefinitions.Lobby, true)
	applyQuality()

	RaceClient.StateChanged:Connect(function()
		refreshLocation()
		local s = RaceClient.state
		local def = s and MapDefinitions.Maps[s.mapId]
		rainEmitter.Enabled = RaceClient.participating and def ~= nil and def.lighting.Rain
		local phase = RaceClient.phase()
		dof.Enabled = (phase == "Intro" or phase == "Results") and Settings.quality ~= "Performance"
	end)
	Settings.Changed:Connect(applyQuality)
end

function Environment.start()
	RunService.PreRender:Connect(animate)
end

return Environment
