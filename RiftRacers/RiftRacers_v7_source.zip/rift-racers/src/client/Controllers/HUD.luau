--!strict
-- All 2D interface, in a chunky, colourful "arcade festival" style:
-- 3D-ish buttons with drop shadows, ink outlines, bouncy tweens, sticker
-- banners and illustrated map posters.
--
-- Screens: lobby bar (player card, PLAY, WORLDS, SETTINGS), queue card,
-- MAP VOTE (posters, live vote counts, voter avatars, winner reveal),
-- worlds gallery, race HUD (position, lap, timers, standings, speedometer,
-- boost, drift/boost-pad stickers, countdown, banners, wrong-way, next-gate
-- marker, speed lines), results, settings. Every button does something.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local SoundService = game:GetService("SoundService")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage.Shared.Config)
local Net = require(ReplicatedStorage.Shared.Net)
local Format = require(ReplicatedStorage.Shared.Util.Format)
local PosterArt = require(ReplicatedStorage.Shared.Util.PosterArt)
local Types = require(ReplicatedStorage.Shared.Types)
local MapDefinitions = require(ReplicatedStorage.Shared.MapDefinitions)
local RaceClient = require(script.Parent.RaceClient)
local Vehicle = require(script.Parent.Vehicle)
local Settings = require(script.Parent.Settings)

local RC = Config.Race
local player = Players.LocalPlayer

local HUD = {}

-- ── palette & fonts ───────────────────────────────────────────────────────
local INK = Color3.fromRGB(30, 26, 48)
local WHITE = Color3.fromRGB(255, 255, 255)
local CREAM = Color3.fromRGB(255, 250, 240)
local PINK = Color3.fromRGB(255, 80, 130)
local ORANGE = Color3.fromRGB(255, 150, 40)
local YELLOW = Color3.fromRGB(255, 215, 50)
local GREEN = Color3.fromRGB(70, 210, 110)
local BLUE = Color3.fromRGB(50, 170, 255)
local PURPLE = Color3.fromRGB(150, 100, 255)
local RED = Color3.fromRGB(255, 70, 80)
local GOLD = Color3.fromRGB(255, 200, 40)
local SILVER = Color3.fromRGB(200, 210, 225)
local BRONZE = Color3.fromRGB(225, 140, 80)

local DISPLAY = Font.fromEnum(Enum.Font.LuckiestGuy)
local BODY = Font.fromEnum(Enum.Font.FredokaOne)

-- ── tiny UI kit ───────────────────────────────────────────────────────────
local function new(className: string, props: { [string]: any }, children: { Instance }?): any
	local inst = Instance.new(className :: any)
	for k, v in props do
		if k ~= "Parent" then
			(inst :: any)[k] = v
		end
	end
	if children then
		for _, c in children do
			c.Parent = inst
		end
	end
	if props.Parent then
		inst.Parent = props.Parent
	end
	return inst
end

local function corner(parent: Instance, px: number)
	new("UICorner", { CornerRadius = UDim.new(0, px), Parent = parent })
end

local function outline(parent: Instance, thickness: number, color: Color3?)
	new("UIStroke", { Color = color or INK, Thickness = thickness, ApplyStrokeMode = Enum.ApplyStrokeMode.Border, Parent = parent })
end

-- Text with a chunky ink outline
local function text(props: { [string]: any }): TextLabel
	props.BackgroundTransparency = props.BackgroundTransparency or 1
	props.FontFace = props.FontFace or BODY
	props.TextColor3 = props.TextColor3 or WHITE
	props.TextScaled = if props.TextScaled == nil then true else props.TextScaled
	local strokeW = props.Stroke
	props.Stroke = nil
	local l: TextLabel = new("TextLabel", props)
	if strokeW ~= 0 then
		new("UIStroke", { Color = INK, Thickness = strokeW or 2, ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual, Parent = l })
	end
	return l
end

local function darker(c: Color3, f: number): Color3
	return c:Lerp(Color3.new(0, 0, 0), f)
end

local sounds: { [string]: Sound } = {}
local function play(key: string)
	local id = (Config.Audio :: any)[key]
	if type(id) ~= "string" or id == "" then
		return
	end
	local s = sounds[key]
	if not s then
		local snd = Instance.new("Sound")
		snd.SoundId = id
		snd.Parent = SoundService
		sounds[key] = snd
		s = snd
	end
	SoundService:PlayLocalSound(s :: Sound)
end

-- Chunky 3D button: a dark "base" with the face sitting 6px above it.
type Chunky = { root: Frame, face: TextButton, label: TextLabel, setColor: (Color3) -> () }
local function chunky(props: { text: string, color: Color3, size: UDim2, position: UDim2, anchor: Vector2?, parent: Instance, textColor: Color3?, depth: number? }, onClick: () -> ()): Chunky
	local depth = props.depth or 6
	local root: Frame = new("Frame", {
		BackgroundColor3 = darker(props.color, 0.4),
		Size = props.size,
		Position = props.position,
		AnchorPoint = props.anchor or Vector2.zero,
		Parent = props.parent,
	})
	corner(root, 14)
	outline(root, 3)
	local scale = new("UIScale", { Parent = root })
	local face: TextButton = new("TextButton", {
		Text = "",
		AutoButtonColor = false,
		BackgroundColor3 = props.color,
		Size = UDim2.new(1, 0, 1, -depth),
		Position = UDim2.new(0, 0, 0, 0),
		Parent = root,
	})
	corner(face, 14)
	outline(face, 3)
	new("UIGradient", { Color = ColorSequence.new(WHITE, Color3.fromRGB(215, 215, 215)), Rotation = 90, Parent = face })
	local shine = new("Frame", { BackgroundColor3 = WHITE, BackgroundTransparency = 0.65, Position = UDim2.new(0.04, 0, 0.1, 0), Size = UDim2.new(0.92, 0, 0.22, 0), Parent = face })
	corner(shine, 8)
	local label = text({ Text = props.text, FontFace = DISPLAY, TextColor3 = props.textColor or WHITE, Size = UDim2.new(0.9, 0, 0.62, 0), Position = UDim2.fromScale(0.5, 0.52), AnchorPoint = Vector2.new(0.5, 0.5), Stroke = 2.5, ZIndex = 3, Parent = face })
	local quick = TweenInfo.new(0.12, Enum.EasingStyle.Quad)
	face.MouseEnter:Connect(function()
		TweenService:Create(scale, quick, { Scale = 1.06 }):Play()
		TweenService:Create(root, quick, { Rotation = -1.5 }):Play()
	end)
	face.MouseLeave:Connect(function()
		TweenService:Create(scale, quick, { Scale = 1 }):Play()
		TweenService:Create(root, quick, { Rotation = 0 }):Play()
	end)
	face.MouseButton1Down:Connect(function()
		face.Position = UDim2.new(0, 0, 0, depth - 1)
	end)
	face.MouseButton1Up:Connect(function()
		face.Position = UDim2.new(0, 0, 0, 0)
	end)
	face.Activated:Connect(function()
		play("UiClick")
		face.Position = UDim2.new(0, 0, 0, 0)
		scale.Scale = 0.92
		TweenService:Create(scale, TweenInfo.new(0.35, Enum.EasingStyle.Back), { Scale = 1 }):Play()
		onClick()
	end)
	return {
		root = root,
		face = face,
		label = label,
		setColor = function(c: Color3)
			face.BackgroundColor3 = c
			root.BackgroundColor3 = darker(c, 0.4)
		end,
	}
end

-- White card with ink outline and a coloured header strip.
local function card(parent: Instance, props: { [string]: any }, header: string?, headerColor: Color3?): Frame
	props.BackgroundColor3 = props.BackgroundColor3 or CREAM
	props.BorderSizePixel = 0
	props.Parent = parent
	local f: Frame = new("Frame", props)
	corner(f, 18)
	outline(f, 4)
	if header then
		local h = new("Frame", { BackgroundColor3 = headerColor or PINK, Size = UDim2.new(1, 0, 0, 48), Parent = f })
		corner(h, 18)
		new("Frame", { BackgroundColor3 = headerColor or PINK, BorderSizePixel = 0, Position = UDim2.new(0, 0, 1, -18), Size = UDim2.new(1, 0, 0, 18), Parent = h })
		text({ Text = header, FontFace = DISPLAY, Size = UDim2.new(1, -30, 0, 34), Position = UDim2.fromOffset(15, 7), TextXAlignment = Enum.TextXAlignment.Left, Stroke = 2.5, Parent = h })
	end
	return f
end

local function pop(obj: GuiObject, from: number?)
	local s = obj:FindFirstChildOfClass("UIScale") or new("UIScale", { Parent = obj })
	s.Scale = from or 0.6
	TweenService:Create(s, TweenInfo.new(0.4, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Scale = 1 }):Play()
end

local headshots: { [number]: string } = {}
local function headshot(userId: number): string
	local cached = headshots[userId]
	if cached then
		return cached
	end
	local ok, url = pcall(function()
		return Players:GetUserThumbnailAsync(userId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size100x100)
	end)
	local result = if ok and type(url) == "string" then url else ""
	headshots[userId] = result
	return result
end

-- ── state ────────────────────────────────────────────────────────────────
local gui: ScreenGui
local lobbyLayer: Frame
local raceLayer: Frame
local resultsLayer: Frame
local voteLayer: Frame
local galleryLayer: Frame
local settingsPanel: Frame
local playBtn: Chunky
local queueCard: Frame
local queueTitle: TextLabel
local queueCount: TextLabel
local queueTimer: TextLabel
local posLabel: TextLabel
local posTotal: TextLabel
local lapLabel: TextLabel
local timeValue: TextLabel
local bestValue: TextLabel
local lastValue: TextLabel
local mapValue: TextLabel
local standingsRows: { Frame } = {}
local speedValue: TextLabel
local ticks: { Frame } = {}
local boostSegs: { Frame } = {}
local boostLabel: TextLabel
local driftSticker: TextLabel
local padSticker: TextLabel
local countdownLabel: TextLabel
local countdownScale: UIScale
local bannerFrame: Frame
local bannerText: TextLabel
local bannerSub: TextLabel
local wrongWay: Frame
local speedLines: Frame
local lineFrames: { Frame } = {}
local resultsList: Frame
local resultsFooter: TextLabel
local resultsTitle: TextLabel
local leaveRace: Chunky
local nextMarker: BillboardGui
local nextMarkerText: TextLabel
local qualityBtns: { [string]: Chunky } = {}
local cameraBtns: { [string]: Chunky } = {}
local motionBtn: Chunky
local voteCards: { [string]: { root: Frame, count: TextLabel, avatars: Frame, check: TextLabel, ribbon: TextLabel, button: TextButton } } = {}
local voteTimer: TextLabel
local voteBar: Frame
local voteTitle: TextLabel
local voteSub: TextLabel
local voteOptionsKey = ""
local myVote: string? = nil
local revealShown = false

local lastCountdown = -1
local resultsUntil = 0
local wrongWayTimer = 0
local lastGateDist: number? = nil
local lastSection: string? = nil
local bannerToken = 0

local function showBanner(main: string, sub: string?, color: Color3?, duration: number?)
	bannerToken += 1
	local token = bannerToken
	bannerText.Text = main
	bannerFrame.BackgroundColor3 = color or PINK
	bannerSub.Text = sub or ""
	bannerSub.Visible = sub ~= nil
	bannerFrame.Visible = true
	bannerFrame.Rotation = math.random(-4, 4)
	pop(bannerFrame, 0.3)
	task.delay(duration or 2.2, function()
		if token == bannerToken then
			bannerFrame.Visible = false
		end
	end)
end

-- ── LOBBY ────────────────────────────────────────────────────────────────
local function buildLobby()
	lobbyLayer = new("Frame", { Name = "Lobby", BackgroundTransparency = 1, Size = UDim2.fromScale(1, 1), Parent = gui })

	-- player card
	local pc = card(lobbyLayer, { Position = UDim2.fromOffset(16, 14), Size = UDim2.fromOffset(270, 76) })
	local avatar = new("ImageLabel", { BackgroundColor3 = YELLOW, Position = UDim2.fromOffset(10, 8), Size = UDim2.fromOffset(60, 60), Image = "", Parent = pc })
	corner(avatar, 30)
	outline(avatar, 3)
	task.spawn(function()
		avatar.Image = headshot(player.UserId)
	end)
	text({ Text = player.DisplayName, FontFace = DISPLAY, TextColor3 = INK, Stroke = 0, Position = UDim2.fromOffset(80, 10), Size = UDim2.new(1, -90, 0, 30), TextXAlignment = Enum.TextXAlignment.Left, Parent = pc })
	local tag = new("Frame", { BackgroundColor3 = PURPLE, Position = UDim2.fromOffset(80, 44), Size = UDim2.fromOffset(140, 22), Parent = pc })
	corner(tag, 11)
	text({ Text = "RIFT RACER", FontFace = DISPLAY, Size = UDim2.new(1, -10, 1, -4), Position = UDim2.fromOffset(5, 2), Stroke = 1.5, Parent = tag })

	-- big title (top centre)
	local title = text({ Text = "RIFT RACERS", FontFace = DISPLAY, TextColor3 = WHITE, AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.new(0.5, 0, 0, 10), Size = UDim2.fromOffset(420, 64), Stroke = 4, Parent = lobbyLayer })
	new("UIGradient", { Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, YELLOW), ColorSequenceKeypoint.new(0.5, ORANGE), ColorSequenceKeypoint.new(1, PINK) }), Rotation = 90, Parent = title })
	title.Rotation = -2

	-- PLAY
	playBtn = chunky({ text = "PLAY!", color = GREEN, size = UDim2.fromOffset(300, 92), position = UDim2.new(0.5, 0, 1, -30), anchor = Vector2.new(0.5, 1), parent = lobbyLayer }, function()
		Net.fireServer("RequestJoinQueue")
	end)
	local sub = text({ Text = "FREE FOR ALL · VOTE THE TRACK", FontFace = DISPLAY, AnchorPoint = Vector2.new(0.5, 1), Position = UDim2.new(0.5, 0, 1, -128), Size = UDim2.fromOffset(330, 24), Stroke = 2.5, Parent = lobbyLayer })
	local _ = sub
	-- WORLDS
	chunky({ text = "WORLDS", color = BLUE, size = UDim2.fromOffset(170, 66), position = UDim2.new(0.5, 175, 1, -30), anchor = Vector2.new(0, 1), parent = lobbyLayer }, function()
		galleryLayer.Visible = not galleryLayer.Visible
		if galleryLayer.Visible then
			pop(galleryLayer:FindFirstChildOfClass("Frame") :: Frame, 0.7)
		end
	end)

	-- queue card
	queueCard = card(lobbyLayer, { AnchorPoint = Vector2.new(0.5, 1), Position = UDim2.new(0.5, 0, 1, -24), Size = UDim2.fromOffset(440, 170), Visible = false }, "FINDING RACERS", PURPLE)
	queueTitle = (queueCard:FindFirstChildOfClass("Frame") :: Frame):FindFirstChildOfClass("TextLabel") :: TextLabel
	queueCount = text({ Text = "1 / 8", FontFace = DISPLAY, TextColor3 = INK, Stroke = 0, Position = UDim2.fromOffset(20, 60), Size = UDim2.fromOffset(160, 40), TextXAlignment = Enum.TextXAlignment.Left, Parent = queueCard })
	text({ Text = "racers ready", TextColor3 = darker(INK, -0.8), Stroke = 0, Position = UDim2.fromOffset(20, 100), Size = UDim2.fromOffset(160, 20), TextXAlignment = Enum.TextXAlignment.Left, Parent = queueCard })
	local timerBubble = new("Frame", { BackgroundColor3 = YELLOW, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromOffset(230, 96), Size = UDim2.fromOffset(74, 74), Parent = queueCard })
	corner(timerBubble, 37)
	outline(timerBubble, 3)
	queueTimer = text({ Text = "10", FontFace = DISPLAY, Size = UDim2.new(1, -14, 1, -14), Position = UDim2.fromOffset(7, 7), Stroke = 2.5, Parent = timerBubble })
	chunky({ text = "LEAVE", color = RED, size = UDim2.fromOffset(130, 58), position = UDim2.new(1, -16, 1, -14), anchor = Vector2.new(1, 1), parent = queueCard }, function()
		Net.fireServer("RequestLeaveQueue")
	end)
end

-- ── WORLDS GALLERY ───────────────────────────────────────────────────────
local function buildGallery()
	galleryLayer = new("Frame", { Name = "Gallery", BackgroundColor3 = INK, BackgroundTransparency = 0.35, Size = UDim2.fromScale(1, 1), Visible = false, ZIndex = 20, Parent = gui })
	local c = card(galleryLayer, { AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5), Size = UDim2.new(0.86, 0, 0.78, 0) }, "THE WORLDS", BLUE)
	new("UISizeConstraint", { MaxSize = Vector2.new(1100, 620), Parent = c })
	local row = new("Frame", { BackgroundTransparency = 1, Position = UDim2.new(0, 20, 0, 64), Size = UDim2.new(1, -40, 1, -150), Parent = c })
	new("UIListLayout", { FillDirection = Enum.FillDirection.Horizontal, Padding = UDim.new(0, 18), HorizontalAlignment = Enum.HorizontalAlignment.Center, Parent = row })
	for i, id in MapDefinitions.Order do
		local def = MapDefinitions.Maps[id]
		local col = new("Frame", { BackgroundColor3 = WHITE, Size = UDim2.new(0.31, 0, 1, 0), LayoutOrder = i, Parent = row })
		corner(col, 14)
		outline(col, 3)
		local art = new("Frame", { BackgroundTransparency = 1, Size = UDim2.new(1, 0, 0.62, 0), ClipsDescendants = true, Parent = col })
		corner(art, 14)
		local poster = PosterArt.draw(art, id)
		corner(poster, 14)
		text({ Text = def.displayName, FontFace = DISPLAY, TextColor3 = INK, Stroke = 0, Position = UDim2.new(0, 10, 0.64, 0), Size = UDim2.new(1, -20, 0.1, 0), Parent = col })
		text({ Text = def.description, TextColor3 = Color3.fromRGB(80, 76, 100), Stroke = 0, TextWrapped = true, TextScaled = true, Position = UDim2.new(0, 12, 0.76, 0), Size = UDim2.new(1, -24, 0.22, 0), Parent = col })
	end
	chunky({ text = "CLOSE", color = PURPLE, size = UDim2.fromOffset(160, 60), position = UDim2.new(0.5, 0, 1, -16), anchor = Vector2.new(0.5, 1), parent = c }, function()
		galleryLayer.Visible = false
	end)
end

-- ── MAP VOTE ─────────────────────────────────────────────────────────────
local function buildVote()
	voteLayer = new("Frame", { Name = "Vote", BackgroundColor3 = INK, BackgroundTransparency = 0.25, Size = UDim2.fromScale(1, 1), Visible = false, ZIndex = 15, Parent = gui })
	new("UIGradient", { Color = ColorSequence.new(Color3.fromRGB(90, 60, 200), Color3.fromRGB(255, 90, 150)), Rotation = 60, Transparency = NumberSequence.new(0.1), Parent = voteLayer })
	voteTitle = text({ Text = "VOTE FOR THE TRACK!", FontFace = DISPLAY, AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.new(0.5, 0, 0, 24), Size = UDim2.fromOffset(640, 64), Stroke = 4, Parent = voteLayer })
	new("UIGradient", { Color = ColorSequence.new(YELLOW, ORANGE), Rotation = 90, Parent = voteTitle })
	voteSub = text({ Text = "Click a world — most votes wins", AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.new(0.5, 0, 0, 90), Size = UDim2.fromOffset(520, 26), Stroke = 2, Parent = voteLayer })
	local barBack = new("Frame", { BackgroundColor3 = INK, AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.new(0.5, 0, 0, 126), Size = UDim2.fromOffset(460, 22), Parent = voteLayer })
	corner(barBack, 11)
	outline(barBack, 3, WHITE)
	voteBar = new("Frame", { BackgroundColor3 = YELLOW, Size = UDim2.fromScale(1, 1), Parent = barBack })
	corner(voteBar, 11)
	local timerBubble = new("Frame", { BackgroundColor3 = PINK, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.new(1, 34, 0.5, 0), Size = UDim2.fromOffset(58, 58), Parent = barBack })
	corner(timerBubble, 29)
	outline(timerBubble, 3)
	voteTimer = text({ Text = "12", FontFace = DISPLAY, Size = UDim2.new(1, -12, 1, -12), Position = UDim2.fromOffset(6, 6), Stroke = 2.5, Parent = timerBubble })
	local row = new("Frame", { Name = "Cards", BackgroundTransparency = 1, AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.new(0.5, 0, 0, 176), Size = UDim2.new(0.92, 0, 1, -200), Parent = voteLayer })
	new("UISizeConstraint", { MaxSize = Vector2.new(1180, 520), Parent = row })
	new("UIListLayout", { FillDirection = Enum.FillDirection.Horizontal, Padding = UDim.new(0.025, 0), HorizontalAlignment = Enum.HorizontalAlignment.Center, Parent = row })
end

local function buildVoteCards(options: { string })
	local row = voteLayer:FindFirstChild("Cards") :: Frame
	for _, c in row:GetChildren() do
		if c:IsA("Frame") then
			c:Destroy()
		end
	end
	voteCards = {}
	local accents = { PINK, BLUE, GREEN, ORANGE, PURPLE }
	for i, id in options do
		local def = MapDefinitions.Maps[id]
		if not def then
			continue
		end
		local accent = accents[((i - 1) % #accents) + 1]
		local root = new("Frame", { Name = id, BackgroundColor3 = darker(accent, 0.4), Size = UDim2.new(0.31, 0, 1, 0), LayoutOrder = i, Parent = row })
		corner(root, 18)
		outline(root, 4)
		new("UIScale", { Parent = root })
		local face = new("TextButton", { Text = "", AutoButtonColor = false, BackgroundColor3 = WHITE, Size = UDim2.new(1, 0, 1, -8), Parent = root })
		corner(face, 18)
		outline(face, 4)
		local art = new("Frame", { BackgroundTransparency = 1, Position = UDim2.fromOffset(8, 8), Size = UDim2.new(1, -16, 0.6, -8), ClipsDescendants = true, Parent = face })
		corner(art, 12)
		local poster = PosterArt.draw(art, id)
		corner(poster, 12)
		local nameBar = new("Frame", { BackgroundColor3 = accent, Position = UDim2.new(0, 8, 0.6, 4), Size = UDim2.new(1, -16, 0.13, 0), Parent = face })
		corner(nameBar, 10)
		outline(nameBar, 3)
		text({ Text = def.displayName, FontFace = DISPLAY, Size = UDim2.new(1, -16, 0.8, 0), Position = UDim2.fromScale(0.5, 0.5), AnchorPoint = Vector2.new(0.5, 0.5), Stroke = 2.5, Parent = nameBar })
		text({ Text = def.tagline, TextColor3 = Color3.fromRGB(90, 86, 110), Stroke = 0, Position = UDim2.new(0, 12, 0.75, 0), Size = UDim2.new(1, -24, 0.07, 0), Parent = face })
		local avatars = new("Frame", { BackgroundTransparency = 1, Position = UDim2.new(0, 12, 0.84, 0), Size = UDim2.new(1, -90, 0.13, 0), Parent = face })
		new("UIListLayout", { FillDirection = Enum.FillDirection.Horizontal, Padding = UDim.new(0, -10), VerticalAlignment = Enum.VerticalAlignment.Center, Parent = avatars })
		local countBubble = new("Frame", { BackgroundColor3 = YELLOW, AnchorPoint = Vector2.new(1, 1), Position = UDim2.new(1, -10, 1, -10), Size = UDim2.fromOffset(62, 62), Parent = face })
		corner(countBubble, 31)
		outline(countBubble, 3)
		local count = text({ Text = "0", FontFace = DISPLAY, Size = UDim2.new(1, -14, 1, -14), Position = UDim2.fromOffset(7, 7), Stroke = 2.5, Parent = countBubble })
		local check = text({ Text = "✔ YOUR VOTE", FontFace = DISPLAY, BackgroundTransparency = 0, BackgroundColor3 = GREEN, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.new(0.5, 0, 0, 10), Size = UDim2.fromOffset(170, 36), Rotation = -4, Visible = false, ZIndex = 5, Stroke = 2.5, Parent = root })
		corner(check, 10)
		outline(check, 3)
		local ribbon = text({ Text = "WINNER!", FontFace = DISPLAY, BackgroundTransparency = 0, BackgroundColor3 = GOLD, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.4), Size = UDim2.new(0.8, 0, 0, 64), Rotation = -8, Visible = false, ZIndex = 6, Stroke = 3, Parent = root })
		corner(ribbon, 12)
		outline(ribbon, 4)
		local scale = root:FindFirstChildOfClass("UIScale") :: UIScale
		face.MouseEnter:Connect(function()
			TweenService:Create(scale, TweenInfo.new(0.15), { Scale = 1.04 }):Play()
		end)
		face.MouseLeave:Connect(function()
			TweenService:Create(scale, TweenInfo.new(0.15), { Scale = 1 }):Play()
		end)
		face.Activated:Connect(function()
			local v = RaceClient.vote
			if v and v.active and not v.winner then
				myVote = id
				play("UiClick")
				Net.fireServer("RequestVote", id)
				scale.Scale = 0.9
				TweenService:Create(scale, TweenInfo.new(0.4, Enum.EasingStyle.Back), { Scale = 1.04 }):Play()
			end
		end)
		voteCards[id] = { root = root, count = count, avatars = avatars, check = check, ribbon = ribbon, button = face }
		pop(root, 0.4)
	end
end

local function refreshVote(v: Types.VotePayload)
	local amEntrant = false
	for _, e in v.entrants do
		if e.userId == player.UserId then
			amEntrant = true
		end
	end
	if not amEntrant then
		voteLayer.Visible = false
		return
	end
	local key = table.concat(v.options, ",")
	if key ~= voteOptionsKey or not voteLayer.Visible then
		voteOptionsKey = key
		myVote = nil
		revealShown = false
		buildVoteCards(v.options)
		voteTitle.Text = "VOTE FOR THE TRACK!"
		voteSub.Text = "Click a world — most votes wins"
	end
	voteLayer.Visible = amEntrant
	for id, c in voteCards do
		local voters: { number } = v.votes[id] or {}
		local n = #voters
		if c.count.Text ~= tostring(n) then
			c.count.Text = tostring(n)
			pop(c.count.Parent :: Frame, 0.6)
		end
		c.check.Visible = myVote == id
		for _, a in c.avatars:GetChildren() do
			if a:IsA("ImageLabel") then
				a:Destroy()
			end
		end
		for k, uid in voters do
			if k > 6 then
				break
			end
			local img = new("ImageLabel", { BackgroundColor3 = WHITE, Size = UDim2.fromOffset(40, 40), LayoutOrder = k, Parent = c.avatars })
			corner(img, 20)
			outline(img, 3)
			task.spawn(function()
				img.Image = headshot(uid)
			end)
		end
	end
	if v.winner and not revealShown then
		revealShown = true
		voteTitle.Text = MapDefinitions.Maps[v.winner].displayName .. "!"
		voteSub.Text = if v.tieBroken then "It was a tie — picked by random draw!" else "Get ready to race!"
		for id, c in voteCards do
			if id == v.winner then
				c.ribbon.Visible = true
				pop(c.ribbon, 0.2)
				TweenService:Create(c.root:FindFirstChildOfClass("UIScale") :: UIScale, TweenInfo.new(0.5, Enum.EasingStyle.Back), { Scale = 1.12 }):Play()
			else
				TweenService:Create(c.root:FindFirstChildOfClass("UIScale") :: UIScale, TweenInfo.new(0.4), { Scale = 0.85 }):Play()
				c.root.BackgroundTransparency = 0.6
				c.button.BackgroundColor3 = Color3.fromRGB(150, 150, 160)
			end
		end
		play("RaceFinish")
		task.delay(RC.VoteRevealSeconds + 0.5, function()
			if revealShown then
				voteLayer.Visible = false
				voteOptionsKey = ""
			end
		end)
	end
end

-- ── RACE HUD ─────────────────────────────────────────────────────────────
local function buildRace()
	raceLayer = new("Frame", { Name = "Race", BackgroundTransparency = 1, Size = UDim2.fromScale(1, 1), Visible = false, Parent = gui })

	speedLines = new("Frame", { Name = "SpeedLines", BackgroundTransparency = 1, Size = UDim2.fromScale(1, 1), ClipsDescendants = true, Parent = raceLayer })
	local rng = Random.new(3)
	for _ = 1, 28 do
		local angle = rng:NextNumber(0, math.pi * 2)
		local f = new("Frame", { BackgroundColor3 = WHITE, BorderSizePixel = 0, AnchorPoint = Vector2.new(0.5, 0.5), Size = UDim2.new(0, 3, 0.1 + rng:NextNumber() * 0.12, 0), Rotation = math.deg(angle) - 90, BackgroundTransparency = 1, Parent = speedLines })
		f:SetAttribute("Angle", angle)
		f:SetAttribute("Seed", rng:NextNumber())
		table.insert(lineFrames, f)
	end

	-- position + lap
	local top = new("Frame", { BackgroundTransparency = 1, AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.new(0.5, 0, 0, 6), Size = UDim2.fromOffset(320, 120), Parent = raceLayer })
	posLabel = text({ Text = "1ST", FontFace = DISPLAY, AnchorPoint = Vector2.new(1, 0), Position = UDim2.fromScale(0.62, 0), Size = UDim2.fromScale(0.62, 0.66), TextXAlignment = Enum.TextXAlignment.Right, Stroke = 4, Parent = top })
	new("UIGradient", { Color = ColorSequence.new(YELLOW, ORANGE), Rotation = 90, Parent = posLabel })
	posTotal = text({ Text = "/1", FontFace = DISPLAY, Position = UDim2.fromScale(0.64, 0.22), Size = UDim2.fromScale(0.3, 0.38), TextXAlignment = Enum.TextXAlignment.Left, Stroke = 3, Parent = top })
	local lapPill = new("Frame", { BackgroundColor3 = PINK, AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.fromScale(0.5, 0.7), Size = UDim2.fromOffset(170, 34), Parent = top })
	corner(lapPill, 17)
	outline(lapPill, 3)
	lapLabel = text({ Text = "LAP 1/3", FontFace = DISPLAY, Size = UDim2.new(1, -16, 1, -6), Position = UDim2.fromOffset(8, 3), Stroke = 2.5, Parent = lapPill })

	-- timers
	local timers = new("Frame", { BackgroundColor3 = INK, BackgroundTransparency = 0.1, AnchorPoint = Vector2.new(1, 0), Position = UDim2.new(1, -16, 0, 60), Size = UDim2.fromOffset(250, 146), Parent = raceLayer })
	corner(timers, 16)
	outline(timers, 3, WHITE)
	local function row(y: number, label: string, color: Color3, big: boolean): TextLabel
		local pill = new("Frame", { BackgroundColor3 = color, Position = UDim2.fromOffset(12, y), Size = UDim2.fromOffset(78, if big then 30 else 24), Parent = timers })
		corner(pill, 12)
		text({ Text = label, FontFace = DISPLAY, Size = UDim2.new(1, -10, 1, -6), Position = UDim2.fromOffset(5, 3), Stroke = 1.5, Parent = pill })
		return text({ Text = "--:--.---", FontFace = DISPLAY, Position = UDim2.new(0, 98, 0, y), Size = UDim2.new(1, -110, 0, if big then 30 else 24), TextXAlignment = Enum.TextXAlignment.Right, Stroke = 2, Parent = timers })
	end
	timeValue = row(12, "TIME", PINK, true)
	bestValue = row(52, "BEST", GOLD, false)
	lastValue = row(82, "LAST", BLUE, false)
	mapValue = row(112, "MAP", PURPLE, false)
	mapValue.TextScaled = true

	-- standings
	local standings = new("Frame", { BackgroundTransparency = 1, Position = UDim2.new(0, 14, 0.2, 0), Size = UDim2.fromOffset(230, 8 * 36), Parent = raceLayer })
	new("UIListLayout", { Padding = UDim.new(0, 5), SortOrder = Enum.SortOrder.LayoutOrder, Parent = standings })
	for i = 1, RC.MaxPlayers do
		local r = new("Frame", { BackgroundColor3 = INK, BackgroundTransparency = 0.15, Size = UDim2.new(1, 0, 0, 31), LayoutOrder = i, Visible = false, Parent = standings })
		corner(r, 15)
		outline(r, 2, WHITE)
		local badge = new("Frame", { Name = "Badge", BackgroundColor3 = BLUE, Size = UDim2.fromOffset(31, 31), Parent = r })
		corner(badge, 15)
		outline(badge, 2)
		text({ Name = "Pos", Text = tostring(i), FontFace = DISPLAY, Size = UDim2.new(1, -8, 1, -8), Position = UDim2.fromOffset(4, 4), Stroke = 2, Parent = badge })
		text({ Name = "Name", Text = "", Size = UDim2.new(1, -90, 1, -10), Position = UDim2.fromOffset(40, 5), TextXAlignment = Enum.TextXAlignment.Left, Stroke = 1.5, Parent = r })
		text({ Name = "Lap", Text = "", FontFace = DISPLAY, AnchorPoint = Vector2.new(1, 0), Size = UDim2.new(0, 44, 1, -10), Position = UDim2.new(1, -8, 0, 5), TextXAlignment = Enum.TextXAlignment.Right, Stroke = 1.5, Parent = r })
		table.insert(standingsRows, r)
	end

	-- speedometer
	local speedo = new("Frame", { Name = "Speedometer", BackgroundTransparency = 1, AnchorPoint = Vector2.new(1, 1), Position = UDim2.new(1, -18, 1, -16), Size = UDim2.fromOffset(260, 250), Parent = raceLayer })
	local dial = new("Frame", { BackgroundColor3 = INK, BackgroundTransparency = 0.05, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromOffset(130, 122), Size = UDim2.fromOffset(212, 212), Parent = speedo })
	corner(dial, 106)
	outline(dial, 4, WHITE)
	local N = 30
	for i = 0, N - 1 do
		local a = math.rad(135 + 270 * i / (N - 1))
		local r = 88
		local tick = new("Frame", { BorderSizePixel = 0, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromOffset(130 + math.cos(a) * r, 122 + math.sin(a) * r), Size = UDim2.fromOffset(9, 20), Rotation = math.deg(a) - 90, BackgroundColor3 = Color3.fromRGB(70, 66, 96), Parent = speedo })
		corner(tick, 4)
		table.insert(ticks, tick)
	end
	speedValue = text({ Text = "0", FontFace = DISPLAY, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromOffset(130, 110), Size = UDim2.fromOffset(150, 64), Stroke = 3, Parent = speedo })
	text({ Text = Config.Vehicle.SpeedUnit, FontFace = DISPLAY, TextColor3 = YELLOW, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromOffset(130, 150), Size = UDim2.fromOffset(80, 20), Stroke = 2, Parent = speedo })
	local boostRow = new("Frame", { BackgroundTransparency = 1, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromOffset(130, 182), Size = UDim2.fromOffset(130, 16), Parent = speedo })
	new("UIListLayout", { FillDirection = Enum.FillDirection.Horizontal, Padding = UDim.new(0, 3), Parent = boostRow })
	for i = 1, 8 do
		local seg = new("Frame", { BackgroundColor3 = Color3.fromRGB(70, 66, 96), Size = UDim2.new(0, 13.5, 1, 0), LayoutOrder = i, Parent = boostRow })
		corner(seg, 4)
		table.insert(boostSegs, seg)
	end
	boostLabel = text({ Text = "BOOST", FontFace = DISPLAY, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromOffset(130, 204), Size = UDim2.fromOffset(120, 18), Stroke = 2, Parent = speedo })
	driftSticker = text({ Text = "DRIFT!", FontFace = DISPLAY, BackgroundTransparency = 0, BackgroundColor3 = PINK, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromOffset(40, 10), Size = UDim2.fromOffset(110, 40), Rotation = -10, Visible = false, Stroke = 2.5, Parent = speedo })
	corner(driftSticker, 12)
	outline(driftSticker, 3)
	padSticker = text({ Text = "BOOST PAD!", FontFace = DISPLAY, BackgroundTransparency = 0, BackgroundColor3 = ORANGE, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.62), Size = UDim2.fromOffset(260, 56), Rotation = 4, Visible = false, Stroke = 3, Parent = raceLayer })
	corner(padSticker, 14)
	outline(padSticker, 4)

	-- countdown + banners + wrong way
	countdownLabel = text({ Text = "", FontFace = DISPLAY, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.38), Size = UDim2.fromOffset(460, 190), Visible = false, Stroke = 6, Parent = raceLayer })
	countdownScale = new("UIScale", { Parent = countdownLabel })
	bannerFrame = new("Frame", { BackgroundColor3 = PINK, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.25), Size = UDim2.fromOffset(520, 76), Visible = false, Parent = raceLayer })
	corner(bannerFrame, 18)
	outline(bannerFrame, 4)
	bannerText = text({ Text = "", FontFace = DISPLAY, Position = UDim2.new(0, 14, 0, 6), Size = UDim2.new(1, -28, 0, 42), Stroke = 3, Parent = bannerFrame })
	bannerSub = text({ Text = "", Position = UDim2.new(0, 14, 0, 48), Size = UDim2.new(1, -28, 0, 22), Stroke = 2, Parent = bannerFrame })
	wrongWay = new("Frame", { BackgroundColor3 = RED, AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.36), Size = UDim2.fromOffset(420, 64), Visible = false, Parent = raceLayer })
	corner(wrongWay, 16)
	outline(wrongWay, 4)
	text({ Text = "⚠ WRONG WAY! ⚠", FontFace = DISPLAY, Size = UDim2.new(1, -20, 1, -14), Position = UDim2.fromOffset(10, 7), Stroke = 3, Parent = wrongWay })

	local hintBar = new("Frame", { BackgroundColor3 = INK, BackgroundTransparency = 0.2, AnchorPoint = Vector2.new(0, 1), Position = UDim2.new(0, 14, 1, -12), Size = UDim2.fromOffset(600, 28), Visible = UserInputService.KeyboardEnabled, Parent = raceLayer })
	corner(hintBar, 14)
	text({ Text = "W/S drive · A/D steer · SPACE drift · SHIFT boost · R reset · C camera", Size = UDim2.new(1, -20, 1, -8), Position = UDim2.fromOffset(10, 4), Stroke = 0, Parent = hintBar })
end

-- ── RESULTS ──────────────────────────────────────────────────────────────
local function buildResults()
	resultsLayer = new("Frame", { Name = "Results", BackgroundColor3 = INK, BackgroundTransparency = 0.35, Size = UDim2.fromScale(1, 1), Visible = false, Parent = gui })
	local c = card(resultsLayer, { AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5), Size = UDim2.new(0.62, 0, 0.76, 0) }, "RACE RESULTS", GOLD)
	new("UISizeConstraint", { MaxSize = Vector2.new(780, 580), MinSize = Vector2.new(340, 320), Parent = c })
	resultsTitle = (c:FindFirstChildOfClass("Frame") :: Frame):FindFirstChildOfClass("TextLabel") :: TextLabel
	local header = new("Frame", { BackgroundTransparency = 1, Position = UDim2.new(0, 24, 0, 60), Size = UDim2.new(1, -48, 0, 20), Parent = c })
	local cols: { { label: string, x: number, w: number } } = {
		{ label = "POS", x = 0, w = 0.14 },
		{ label = "DRIVER", x = 0.14, w = 0.42 },
		{ label = "TOTAL", x = 0.56, w = 0.22 },
		{ label = "BEST LAP", x = 0.78, w = 0.22 },
	}
	for _, h in cols do
		text({ Text = h.label, FontFace = DISPLAY, TextColor3 = Color3.fromRGB(120, 116, 140), Stroke = 0, Position = UDim2.fromScale(h.x, 0), Size = UDim2.fromScale(h.w, 1), TextXAlignment = Enum.TextXAlignment.Left, Parent = header })
	end
	resultsList = new("ScrollingFrame", { BackgroundTransparency = 1, BorderSizePixel = 0, Position = UDim2.new(0, 24, 0, 86), Size = UDim2.new(1, -48, 1, -180), ScrollBarThickness = 6, AutomaticCanvasSize = Enum.AutomaticSize.Y, CanvasSize = UDim2.new(), Parent = c })
	new("UIListLayout", { Padding = UDim.new(0, 8), SortOrder = Enum.SortOrder.LayoutOrder, Parent = resultsList })
	resultsFooter = text({ Text = "", TextColor3 = Color3.fromRGB(110, 106, 130), Stroke = 0, AnchorPoint = Vector2.new(0, 1), Position = UDim2.new(0, 24, 1, -30), Size = UDim2.new(0.45, 0, 0, 22), TextXAlignment = Enum.TextXAlignment.Left, Parent = c })
	chunky({ text = "BACK TO NEXUS", color = GREEN, size = UDim2.fromOffset(250, 66), position = UDim2.new(1, -20, 1, -16), anchor = Vector2.new(1, 1), parent = c }, function()
		Net.fireServer("RequestReturnToLobby")
		resultsLayer.Visible = false
	end)
end

-- ── SETTINGS ─────────────────────────────────────────────────────────────
local function refreshSettings()
	for name, b in qualityBtns do
		b.setColor(if Settings.quality == name then GREEN else Color3.fromRGB(150, 146, 170))
	end
	for name, b in cameraBtns do
		b.setColor(if Settings.cameraMode == name then BLUE else Color3.fromRGB(150, 146, 170))
	end
	motionBtn.label.Text = if Settings.reducedMotion then "ON" else "OFF"
	motionBtn.setColor(if Settings.reducedMotion then PURPLE else Color3.fromRGB(150, 146, 170))
	leaveRace.root.Visible = RaceClient.participating
end

local function buildSettings()
	-- bottom-left: clear of Roblox's player list (top-right) and the race HUD
	chunky({ text = "OPTIONS", color = PURPLE, size = UDim2.fromOffset(150, 56), position = UDim2.new(0, 16, 1, -50), anchor = Vector2.new(0, 1), parent = gui }, function()
		settingsPanel.Visible = not settingsPanel.Visible
		if settingsPanel.Visible then
			pop(settingsPanel, 0.7)
		end
		refreshSettings()
	end)
	settingsPanel = card(gui, { AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.5), Size = UDim2.fromOffset(520, 420), Visible = false, ZIndex = 30 }, "SETTINGS", PURPLE)
	local function label(y: number, t: string)
		text({ Text = t, FontFace = DISPLAY, TextColor3 = INK, Stroke = 0, Position = UDim2.fromOffset(24, y), Size = UDim2.new(1, -48, 0, 22), TextXAlignment = Enum.TextXAlignment.Left, Parent = settingsPanel })
	end
	label(62, "GRAPHICS")
	for i, q in { "Ultra", "Balanced", "Performance" } do
		qualityBtns[q] = chunky({ text = string.upper(q), color = GREEN, size = UDim2.fromOffset(150, 54), position = UDim2.fromOffset(24 + (i - 1) * 160, 90), parent = settingsPanel }, function()
			Settings.setQuality(q :: any)
			refreshSettings()
		end)
	end
	label(156, "CAMERA (C IN RACE)")
	for i, c in { "Chase", "Close", "Hood" } do
		cameraBtns[c] = chunky({ text = string.upper(c), color = BLUE, size = UDim2.fromOffset(150, 54), position = UDim2.fromOffset(24 + (i - 1) * 160, 184), parent = settingsPanel }, function()
			Settings.setCamera(c :: any)
			refreshSettings()
		end)
	end
	label(250, "REDUCED MOTION")
	motionBtn = chunky({ text = "OFF", color = PURPLE, size = UDim2.fromOffset(150, 54), position = UDim2.fromOffset(24, 278), parent = settingsPanel }, function()
		Settings.setReducedMotion(not Settings.reducedMotion)
		refreshSettings()
	end)
	leaveRace = chunky({ text = "LEAVE RACE", color = RED, size = UDim2.fromOffset(190, 58), position = UDim2.new(0, 24, 1, -16), anchor = Vector2.new(0, 1), parent = settingsPanel }, function()
		Net.fireServer("RequestReturnToLobby")
		settingsPanel.Visible = false
	end)
	chunky({ text = "CLOSE", color = PINK, size = UDim2.fromOffset(150, 58), position = UDim2.new(1, -24, 1, -16), anchor = Vector2.new(1, 1), parent = settingsPanel }, function()
		settingsPanel.Visible = false
	end)
end

local function buildNextMarker()
	nextMarker = new("BillboardGui", { Name = "RiftNextGate", AlwaysOnTop = true, Size = UDim2.fromOffset(150, 74), StudsOffsetWorldSpace = Vector3.new(0, 7, 0), MaxDistance = 2500, LightInfluence = 0, Enabled = false, Parent = player:WaitForChild("PlayerGui") })
	local pill = new("Frame", { BackgroundColor3 = PINK, Size = UDim2.new(1, 0, 0.5, 0), Parent = nextMarker })
	corner(pill, 14)
	outline(pill, 3)
	nextMarkerText = text({ Text = "NEXT", FontFace = DISPLAY, Size = UDim2.new(1, -12, 1, -8), Position = UDim2.fromOffset(6, 4), Stroke = 2, Parent = pill })
	text({ Text = "▼", FontFace = DISPLAY, TextColor3 = YELLOW, Position = UDim2.fromScale(0, 0.5), Size = UDim2.fromScale(1, 0.5), Stroke = 3, Parent = nextMarker })
end

-- ── data → UI ────────────────────────────────────────────────────────────
local function gateModel(index: number): Model?
	local s = RaceClient.state
	if not s then
		return nil
	end
	local tracks = Workspace:FindFirstChild("Tracks")
	local map = tracks and tracks:FindFirstChild(s.mapId)
	local cps = map and map:FindFirstChild("Checkpoints")
	local g = cps and cps:FindFirstChild("Gate" .. index)
	return if g and g:IsA("Model") then g else nil
end

local function onStateChanged(s: Types.RaceStatePayload)
	local phase = RaceClient.phase()
	local racing = phase ~= "Idle"
	lobbyLayer.Visible = not racing
	raceLayer.Visible = racing and phase ~= "Results"
	if racing then
		galleryLayer.Visible = false
		voteLayer.Visible = false
	else
		resultsLayer.Visible = false
		nextMarker.Enabled = false
		countdownLabel.Visible = false
	end
	if phase == "Intro" then
		lastCountdown = -1
		lastSection = nil
		lapLabel.Text = string.format("LAP 1/%d", s.laps)
		bestValue.Text = "--:--.---"
		lastValue.Text = "--:--.---"
		mapValue.Text = s.mapName
		local def = MapDefinitions.Maps[s.mapId]
		showBanner(s.mapName, if def then def.tagline else nil, PURPLE, 3.4)
	end
	refreshSettings()
end

local function onProgress(p: Types.ProgressPayload)
	local s = RaceClient.state
	if not s then
		return
	end
	lapLabel.Text = if p.finished then "FINISHED!" else string.format("LAP %d/%d", p.lap, s.laps)
	pop(lapLabel.Parent :: Frame, 0.8)
	bestValue.Text = Format.raceTime(p.bestLapTime)
	lastValue.Text = Format.raceTime(p.lastLapTime)
	lastGateDist = nil
	if p.event == "lap" then
		play("LapComplete")
		if p.lap == s.laps then
			showBanner("FINAL LAP!", "Last lap  " .. Format.raceTime(p.lastLapTime), ORANGE, 2.6)
		else
			showBanner(string.format("LAP %d", p.lap), "Last lap  " .. Format.raceTime(p.lastLapTime), BLUE, 2.2)
		end
	elseif p.event == "finish" then
		play("RaceFinish")
		local pos = RaceClient.myPosition()
		showBanner("FINISH!", (if pos then Format.ordinal(pos) .. "  ·  " else "") .. Format.raceTime(p.finishTime), GREEN, 4)
	elseif p.event == "invalid" then
		showBanner("LAP INVALID", "Drive through every checkpoint", RED, 2.5)
	elseif p.event == "checkpoint" then
		play("Checkpoint")
	end
	if p.section and p.section ~= lastSection and p.event ~= "finish" then
		if lastSection ~= nil and p.event == "checkpoint" then
			showBanner(p.section, nil, PINK, 1.8)
		end
		lastSection = p.section
	end
	local g = if p.finished then nil else gateModel(p.nextCheckpoint)
	local beam = g and g:FindFirstChild("Beam")
	if beam and beam:IsA("BasePart") then
		nextMarker.Adornee = beam
		nextMarker.Enabled = true
	else
		nextMarker.Enabled = false
	end
end

local function badgeColor(pos: number): Color3
	return if pos == 1 then GOLD elseif pos == 2 then SILVER elseif pos == 3 then BRONZE else BLUE
end

local function onStandings(rows: { Types.StandingRow })
	for i, frame in standingsRows do
		local r = rows[i]
		frame.Visible = r ~= nil
		if r then
			local me = r.u == player.UserId
			local badge = frame:FindFirstChild("Badge") :: Frame
			badge.BackgroundColor3 = badgeColor(r.p)
			;(badge:FindFirstChild("Pos") :: TextLabel).Text = tostring(r.p)
			;(frame:FindFirstChild("Name") :: TextLabel).Text = RaceClient.nameOf(r.u)
			;(frame:FindFirstChild("Lap") :: TextLabel).Text = if r.f then "🏁" else ("L" .. r.l)
			frame.BackgroundColor3 = if me then PINK else INK
		end
	end
	local pos, total = RaceClient.myPosition()
	if pos then
		local txt = Format.ordinal(pos)
		if posLabel.Text ~= txt then
			posLabel.Text = txt
			pop(posLabel, 0.7)
		end
		posTotal.Text = "/" .. total
	end
end

local function onResults(rows: { Types.ResultRow })
	for _, c in resultsList:GetChildren() do
		if c:IsA("Frame") then
			c:Destroy()
		end
	end
	local s = RaceClient.state
	resultsTitle.Text = "RESULTS · " .. (if s then s.mapName else "")
	for i, r in rows do
		local me = r.userId == player.UserId
		local f = new("Frame", { BackgroundColor3 = if me then Color3.fromRGB(255, 230, 240) else WHITE, Size = UDim2.new(1, -8, 0, 46), LayoutOrder = i, Parent = resultsList })
		corner(f, 12)
		outline(f, 3)
		local badge = new("Frame", { BackgroundColor3 = if r.finished then badgeColor(r.position) else RED, Position = UDim2.fromOffset(6, 5), Size = UDim2.fromOffset(60, 36), Parent = f })
		corner(badge, 10)
		outline(badge, 2)
		text({ Text = if r.finished then Format.ordinal(r.position) else "DNF", FontFace = DISPLAY, Size = UDim2.new(1, -8, 1, -8), Position = UDim2.fromOffset(4, 4), Stroke = 2, Parent = badge })
		text({ Text = (if r.position == 1 and r.finished then "🏆 " else "") .. r.name, FontFace = DISPLAY, TextColor3 = INK, Stroke = 0, Position = UDim2.new(0.14, 0, 0, 10), Size = UDim2.new(0.42, 0, 1, -20), TextXAlignment = Enum.TextXAlignment.Left, Parent = f })
		text({ Text = if r.finished then Format.raceTime(r.totalTime) else "—", FontFace = DISPLAY, TextColor3 = INK, Stroke = 0, Position = UDim2.new(0.56, 0, 0, 12), Size = UDim2.new(0.22, 0, 1, -24), TextXAlignment = Enum.TextXAlignment.Left, Parent = f })
		text({ Text = Format.raceTime(r.bestLap), FontFace = DISPLAY, TextColor3 = Color3.fromRGB(120, 116, 140), Stroke = 0, Position = UDim2.new(0.78, 0, 0, 12), Size = UDim2.new(0.22, -10, 1, -24), TextXAlignment = Enum.TextXAlignment.Left, Parent = f })
		pop(f, 0.5)
	end
	resultsUntil = os.clock() + RC.ResultsSeconds
	resultsLayer.Visible = true
	raceLayer.Visible = false
	nextMarker.Enabled = false
end

local function onQueue(q: Types.QueuePayload)
	playBtn.root.Visible = not q.inQueue
	queueCard.Visible = q.inQueue
	if q.inQueue then
		queueCount.Text = string.format("%d / %d", q.count, q.max)
		if q.raceRunning then
			queueTitle.Text = "YOU'RE NEXT!"
			queueTimer.Text = "…"
		else
			local dots = string.rep(".", (math.floor(os.clock() * 2) % 3) + 1)
			queueTitle.Text = "FINDING RACERS" .. dots
			local secs = if q.startsAt then math.max(0, math.ceil((q.startsAt :: number) - RaceClient.now())) else 0
			queueTimer.Text = tostring(secs)
		end
	end
end

-- ── per-frame ────────────────────────────────────────────────────────────
local COUNT_COLORS = { [3] = RED, [2] = ORANGE, [1] = YELLOW, [0] = GREEN }

local function update(dt: number)
	-- vote countdown
	local v = RaceClient.vote
	if voteLayer.Visible and v then
		local remain = math.max(0, v.endsAt - RaceClient.now())
		voteTimer.Text = if v.winner then "!" else tostring(math.ceil(remain))
		voteBar.Size = UDim2.fromScale(if v.winner then 0 else math.clamp(remain / RC.VoteSeconds, 0, 1), 1)
		voteBar.BackgroundColor3 = if remain < 4 then RED else YELLOW
	end

	local phase = RaceClient.phase()
	if phase == "Idle" then
		return
	end
	local s = RaceClient.state :: Types.RaceStatePayload
	local now = RaceClient.now()
	local tel = Vehicle.telemetry
	local prog = RaceClient.progress
	local q = Settings.preset()

	local remaining = s.goTime - now
	if remaining <= RC.CountdownSeconds and remaining > -1 then
		countdownLabel.Visible = true
		local n = if remaining > 0 then math.ceil(remaining) else 0
		if n ~= lastCountdown then
			lastCountdown = n
			countdownLabel.Text = if n > 0 then tostring(n) else "GO!"
			countdownLabel.TextColor3 = COUNT_COLORS[n] or WHITE
			countdownLabel.Rotation = if n % 2 == 0 then 6 else -6
			countdownScale.Scale = 2.2
			TweenService:Create(countdownScale, TweenInfo.new(0.45, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Scale = 1 }):Play()
			play(if n > 0 then "CountdownBeep" else "CountdownGo")
		end
		countdownLabel.TextTransparency = if remaining < 0 then -remaining else 0
	else
		countdownLabel.Visible = false
	end

	local elapsed = math.max(0, now - s.goTime)
	if prog and prog.finished and prog.finishTime then
		elapsed = prog.finishTime :: number
	end
	timeValue.Text = if now < s.goTime then "0:00.000" else Format.raceTime(elapsed)

	speedValue.Text = tostring(math.floor(tel.speedAbs * Config.Vehicle.SpeedDisplayMultiplier + 0.5))
	local ratio = math.clamp(tel.speedAbs / Config.Vehicle.BoostTopSpeed, 0, 1)
	local lit = math.floor(ratio * #ticks + 0.5)
	for i, tick in ticks do
		if i <= lit then
			local f = i / #ticks
			tick.BackgroundColor3 = if tel.boosting then YELLOW elseif f < 0.45 then GREEN elseif f < 0.7 then YELLOW elseif f < 0.85 then ORANGE else RED
		else
			tick.BackgroundColor3 = Color3.fromRGB(70, 66, 96)
		end
	end
	local filled = math.floor(math.clamp(tel.boost, 0, 1) * #boostSegs + 0.5)
	for i, seg in boostSegs do
		seg.BackgroundColor3 = if i <= filled then (if tel.boosting then YELLOW else BLUE:Lerp(PURPLE, i / #boostSegs)) else Color3.fromRGB(70, 66, 96)
	end
	boostLabel.Text = if tel.boosting then "BOOSTING!" elseif tel.boost > 0.98 then "BOOST READY!" else "BOOST"
	boostLabel.TextColor3 = if tel.boosting or tel.boost > 0.98 then YELLOW else WHITE
	if tel.drifting ~= driftSticker.Visible then
		driftSticker.Visible = tel.drifting
		if tel.drifting then
			pop(driftSticker, 0.4)
		end
	end

	local intensity = if q.SpeedLines and not Settings.reducedMotion then math.clamp((ratio - 0.62) / 0.3, 0, 1) else 0
	if tel.boosting and q.SpeedLines and not Settings.reducedMotion then
		intensity = math.max(intensity, 0.8)
	end
	speedLines.Visible = intensity > 0
	if intensity > 0 then
		local t = os.clock()
		for _, f in lineFrames do
			local angle = f:GetAttribute("Angle") :: number
			local seed = f:GetAttribute("Seed") :: number
			local travel = (t * 1.8 + seed) % 1
			local r = 0.32 + travel * 0.45
			f.Position = UDim2.fromScale(0.5 + math.cos(angle) * r * 0.75, 0.5 + math.sin(angle) * r)
			f.BackgroundTransparency = 1 - intensity * 0.4 * (1 - travel)
		end
	end

	if prog and not prog.finished and phase == "Racing" and tel.active then
		local g = gateModel(prog.nextCheckpoint)
		local cf = g and g:GetAttribute("GateCFrame")
		local car = RaceClient.car
		if typeof(cf) == "CFrame" and car and car.PrimaryPart then
			local d = (car.PrimaryPart.Position - cf.Position).Magnitude
			if lastGateDist and d > (lastGateDist :: number) + 0.05 and tel.speedAbs > 25 then
				wrongWayTimer += dt
			else
				wrongWayTimer = math.max(0, wrongWayTimer - dt * 2)
			end
			lastGateDist = d
			nextMarkerText.Text = string.format("NEXT · %dm", math.floor(d * 0.28))
		end
	else
		wrongWayTimer = 0
	end
	local ww = wrongWayTimer > 1.6
	if ww ~= wrongWay.Visible then
		wrongWay.Visible = ww
		if ww then
			pop(wrongWay, 0.5)
		end
	end

	if resultsLayer.Visible then
		resultsFooter.Text = string.format("Back to the Nexus in %ds", math.max(0, math.ceil(resultsUntil - os.clock())))
	end
end

function HUD.init()
	gui = new("ScreenGui", { Name = "RiftHUD", ResetOnSpawn = false, IgnoreGuiInset = false, ZIndexBehavior = Enum.ZIndexBehavior.Sibling, DisplayOrder = 10, Parent = player:WaitForChild("PlayerGui") })
	buildLobby()
	buildGallery()
	buildVote()
	buildRace()
	buildResults()
	buildSettings()
	buildNextMarker()
	refreshSettings()

	RaceClient.StateChanged:Connect(onStateChanged)
	RaceClient.ProgressChanged:Connect(onProgress)
	RaceClient.StandingsChanged:Connect(onStandings)
	RaceClient.Results:Connect(onResults)
	RaceClient.QueueChanged:Connect(onQueue)
	RaceClient.VoteChanged:Connect(refreshVote)
	RaceClient.Notice:Connect(function(msg: string, kind: string)
		showBanner(msg, nil, if kind == "warn" then RED else BLUE, 2.4)
	end)
	RaceClient.Recovered:Connect(function()
		lastGateDist = nil
		wrongWayTimer = 0
	end)
	RaceClient.Celebrate:Connect(function(winner: string, mapName: string)
		if RaceClient.phase() == "Idle" then
			-- lobby players see a toast while the fireworks go off
			local toast = text({ Text = "🏆 " .. winner .. " won " .. mapName .. "!", FontFace = DISPLAY, BackgroundTransparency = 0, BackgroundColor3 = GOLD, AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.new(0.5, 0, 0, 90), Size = UDim2.fromOffset(520, 52), Rotation = -2, Stroke = 2.5, Parent = lobbyLayer })
			corner(toast, 14)
			outline(toast, 4)
			pop(toast, 0.3)
			task.delay(5, function()
				toast:Destroy()
			end)
		end
	end)
	Vehicle.PadHit:Connect(function()
		padSticker.Visible = true
		pop(padSticker, 0.3)
		task.delay(1.1, function()
			padSticker.Visible = false
		end)
	end)
	Settings.Changed:Connect(refreshSettings)
end

function HUD.start()
	RunService.RenderStepped:Connect(update)
	task.spawn(function()
		while true do
			task.wait(0.5)
			local q = RaceClient.queue
			if q then
				onQueue(q)
			end
		end
	end)
end

return HUD
