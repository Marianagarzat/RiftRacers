--!strict
-- Client-side lobby toys. All of these only affect YOUR view / YOUR avatar,
-- so they need no server trust:
--   GlowTile  — tiles near your feet flash bright
--   JumpPad   — launches your character upward with a burst
--   SpeedPad  — sprint boost for a few seconds
--   PaintPad  — repaints the showroom car (local preview until the Garage)
--   Fireworks — when a race is won, the plaza sky lights up

local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ProximityPromptService = game:GetService("ProximityPromptService")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local Workspace = game:GetService("Workspace")

local RaceClient = require(script.Parent.RaceClient)
local Settings = require(script.Parent.Settings)

local player = Players.LocalPlayer

local LobbyFun = {}

type TileInfo = { part: BasePart, base: Color3, lit: number }
local tiles: { TileInfo } = {}
local jumpPads: { BasePart } = {}
local speedPads: { BasePart } = {}
local jumpCooldown = 0
local speedUntil = 0
local defaultWalk = 16

local function burst(at: Vector3, colors: { Color3 }, count: number, speed: number)
	local holder = Instance.new("Part")
	holder.Anchored = true
	holder.CanCollide = false
	holder.CanQuery = false
	holder.CanTouch = false
	holder.Transparency = 1
	holder.Size = Vector3.new(1, 1, 1)
	holder.CFrame = CFrame.new(at)
	holder.Parent = Workspace.CurrentCamera
	for _, c in colors do
		local e = Instance.new("ParticleEmitter")
		e.Texture = "rbxasset://textures/particles/sparkles_main.dds"
		e.Color = ColorSequence.new(c)
		e.LightEmission = 1
		e.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1.6), NumberSequenceKeypoint.new(1, 0) })
		e.Lifetime = NumberRange.new(0.8, 1.4)
		e.Speed = NumberRange.new(speed * 0.6, speed)
		e.SpreadAngle = Vector2.new(180, 180)
		e.Drag = 2
		e.Acceleration = Vector3.new(0, -12, 0)
		e.Rate = 0
		e.Parent = holder
		e:Emit(math.floor(count / #colors))
	end
	task.delay(2, function()
		holder:Destroy()
	end)
end

local FIREWORK_COLORS = {
	{ Color3.fromRGB(255, 80, 120), Color3.fromRGB(255, 220, 60) },
	{ Color3.fromRGB(60, 210, 255), Color3.fromRGB(255, 255, 255) },
	{ Color3.fromRGB(150, 100, 255), Color3.fromRGB(255, 140, 220) },
	{ Color3.fromRGB(80, 230, 120), Color3.fromRGB(255, 200, 40) },
}

local function fireworks(count: number)
	if RaceClient.phase() ~= "Idle" then
		return
	end
	for i = 1, count do
		task.delay(i * 0.35, function()
			local a = math.random() * math.pi * 2
			local d = math.random(20, 120)
			local at = Vector3.new(math.cos(a) * d, math.random(70, 120), math.sin(a) * d)
			-- rising streak
			local rocket = Instance.new("Part")
			rocket.Anchored = true
			rocket.CanCollide, rocket.CanQuery, rocket.CanTouch = false, false, false
			rocket.Material = Enum.Material.Neon
			rocket.Color = Color3.fromRGB(255, 240, 200)
			rocket.Size = Vector3.new(0.6, 3, 0.6)
			rocket.CFrame = CFrame.new(at.X, 0, at.Z)
			rocket.Parent = Workspace.CurrentCamera
			local tw = TweenService:Create(rocket, TweenInfo.new(0.7, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { CFrame = CFrame.new(at) })
			tw:Play()
			tw.Completed:Connect(function()
				rocket:Destroy()
				burst(at, FIREWORK_COLORS[math.random(1, #FIREWORK_COLORS)], 140, 45)
			end)
		end)
	end
end

local function humanoidRoot(): (Humanoid?, BasePart?)
	local character = player.Character
	if not character then
		return nil, nil
	end
	local h = character:FindFirstChildOfClass("Humanoid")
	local root = character:FindFirstChild("HumanoidRootPart")
	return h, if root and root:IsA("BasePart") then root else nil
end

local function update(dt: number)
	if RaceClient.phase() ~= "Idle" then
		return
	end
	local humanoid, root = humanoidRoot()
	if not humanoid or not root then
		return
	end
	local pos = root.Position
	local t = os.clock()

	-- glow tiles: light up those within reach of your feet
	for _, info in tiles do
		local tp = info.part.Position
		local dx, dz = tp.X - pos.X, tp.Z - pos.Z
		if dx * dx + dz * dz < 64 and math.abs(pos.Y - tp.Y) < 6 then
			if t - info.lit > 0.4 then
				info.lit = t
				info.part.Material = Enum.Material.Neon
				info.part.Color = info.base:Lerp(Color3.new(1, 1, 1), 0.35)
				task.delay(0.9, function()
					info.part.Material = Enum.Material.SmoothPlastic
					info.part.Color = info.base
				end)
			end
		end
	end

	-- jump pads
	if t > jumpCooldown then
		for _, pad in jumpPads do
			local pp = pad.Position
			local dx, dz = pp.X - pos.X, pp.Z - pos.Z
			if dx * dx + dz * dz < 30 and pos.Y - pp.Y < 5 and pos.Y - pp.Y > -1 then
				jumpCooldown = t + 0.8
				root.AssemblyLinearVelocity = Vector3.new(root.AssemblyLinearVelocity.X, 135, root.AssemblyLinearVelocity.Z)
				humanoid:ChangeState(Enum.HumanoidStateType.Freefall)
				burst(pp + Vector3.new(0, 2, 0), { pad.Color, Color3.new(1, 1, 1) }, 40, 25)
				break
			end
		end
	end

	-- speed pads
	for _, pad in speedPads do
		local lp = pad.CFrame:PointToObjectSpace(pos)
		if math.abs(lp.X) < pad.Size.X / 2 + 1 and math.abs(lp.Z) < pad.Size.Z / 2 + 1 and math.abs(lp.Y) < 6 then
			if t > speedUntil then
				burst(pos - Vector3.new(0, 2.5, 0), { Color3.fromRGB(255, 200, 40), Color3.fromRGB(255, 90, 40) }, 30, 18)
			end
			speedUntil = t + 3
		end
	end
	if t < speedUntil then
		humanoid.WalkSpeed = 42
	elseif humanoid.WalkSpeed == 42 then
		humanoid.WalkSpeed = defaultWalk
	end
	local _ = dt
end

local function paintShowcase(color: Color3)
	local lobby = Workspace:FindFirstChild("NexusLobby")
	local show = lobby and lobby:FindFirstChild("CarShowcase")
	local turntable = show and show:FindFirstChild("Turntable")
	local car = turntable and turntable:FindFirstChild("ShowcaseCar")
	if not car then
		return
	end
	for _, slotName in { "Body", "Spoiler" } do
		local slot = car:FindFirstChild(slotName)
		if slot then
			for _, part in slot:GetDescendants() do
				if part:IsA("BasePart") and part.Material ~= Enum.Material.Neon and part.Name ~= "Wing" and part.Name ~= "Stand" then
					TweenService:Create(part, TweenInfo.new(0.5, Enum.EasingStyle.Quad), { Color = color }):Play()
				end
			end
		end
	end
	local livery = car:FindFirstChild("Livery")
	local mirrors = livery and livery:GetChildren() or {}
	for _, part in mirrors do
		if part:IsA("BasePart") and part.Name == "Mirror" then
			part.Color = color
		end
	end
	local pivot = (car :: Model):GetPivot().Position
	burst(pivot + Vector3.new(0, 4, 0), { color, Color3.new(1, 1, 1) }, 80, 30)
end

function LobbyFun.init()
	local function track(tag: string, add: (Instance) -> ())
		for _, inst in CollectionService:GetTagged(tag) do
			add(inst)
		end
		CollectionService:GetInstanceAddedSignal(tag):Connect(add)
	end
	track("GlowTile", function(inst)
		if inst:IsA("BasePart") then
			local base = inst:GetAttribute("BaseColor")
			table.insert(tiles, { part = inst, base = if typeof(base) == "Color3" then base else inst.Color, lit = 0 })
		end
	end)
	track("JumpPad", function(inst)
		if inst:IsA("BasePart") then
			table.insert(jumpPads, inst)
		end
	end)
	track("SpeedPad", function(inst)
		if inst:IsA("BasePart") then
			table.insert(speedPads, inst)
		end
	end)
	ProximityPromptService.PromptTriggered:Connect(function(prompt: ProximityPrompt)
		local pad = prompt.Parent
		if pad and CollectionService:HasTag(pad, "PaintPad") then
			local c = pad:GetAttribute("Paint")
			if typeof(c) == "Color3" then
				paintShowcase(c)
			end
		end
	end)
	RaceClient.Celebrate:Connect(function()
		fireworks(if Settings.quality == "Performance" then 6 else 14)
	end)
	player.CharacterAdded:Connect(function(character)
		local h = character:WaitForChild("Humanoid", 5)
		if h and h:IsA("Humanoid") then
			defaultWalk = h.WalkSpeed
		end
	end)
end

function LobbyFun.start()
	RunService.Heartbeat:Connect(update)
	-- a little welcome show
	task.delay(3, function()
		fireworks(5)
	end)
end

return LobbyFun
