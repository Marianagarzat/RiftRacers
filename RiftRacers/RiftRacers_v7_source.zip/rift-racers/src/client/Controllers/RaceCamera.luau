--!strict
-- Premium race camera: intro flyover → countdown → smooth chase with
-- speed FOV, drift lean, gentle high-speed shake → results orbit.
-- Modes: Chase / Close / Hood (C or D-pad up). Reduced motion removes
-- shake, lean and most FOV punch.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage.Shared.Config)
local RaceClient = require(script.Parent.RaceClient)
local Vehicle = require(script.Parent.Vehicle)
local Settings = require(script.Parent.Settings)
local Input = require(script.Parent.Input)

local C = Config.Camera
local RC = Config.Race
local player = Players.LocalPlayer

local RaceCamera = {}

local smoothedPos: Vector3? = nil
local smoothedHeading: Vector3? = nil
local fov = C.BaseFov
local lean = 0
local wasRacing = false

local function resetSmoothing()
	smoothedPos = nil
	smoothedHeading = nil
end

local function restoreDefault(camera: Camera)
	camera.CameraType = Enum.CameraType.Custom
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	if humanoid then
		camera.CameraSubject = humanoid
	end
	camera.FieldOfView = C.BaseFov
end

local function chaseCFrame(chassis: BasePart, dt: number, snap: boolean): CFrame
	local tel = Vehicle.telemetry
	local cf = chassis.CFrame
	local flatLook = Vector3.new(cf.LookVector.X, 0, cf.LookVector.Z)
	if flatLook.Magnitude < 0.05 then
		flatLook = Vector3.new(0, 0, -1)
	end
	flatLook = flatLook.Unit
	-- blend heading toward velocity while drifting so the camera "swings"
	local vel = chassis.AssemblyLinearVelocity
	local flatVel = Vector3.new(vel.X, 0, vel.Z)
	local heading = flatLook
	if flatVel.Magnitude > 30 and tel.speed > 0 then
		heading = flatLook:Lerp(flatVel.Unit, 0.35).Unit
	end
	local alpha = if snap then 1 else 1 - math.exp(-C.FollowSharpness * dt)
	smoothedHeading = if smoothedHeading and not snap then (smoothedHeading :: Vector3):Lerp(heading, alpha).Unit else heading
	local h = smoothedHeading :: Vector3

	local mode = Settings.cameraMode
	local speedRatio = math.clamp(tel.speedAbs / Config.Vehicle.TopSpeed, 0, 1.4)
	local dist = if mode == "Close" then C.CloseDistance else C.ChaseDistance
	local height = if mode == "Close" then C.CloseHeight else C.ChaseHeight
	dist += speedRatio * 3
	local target = cf.Position - h * dist + Vector3.new(0, height, 0)
	-- Horizontal position is locked to the car (heading smoothing gives the
	-- swing); only height is smoothed so bumps don't jolt the view.
	local posAlpha = if snap then 1 else 1 - math.exp(-C.FollowSharpness * 1.6 * dt)
	local y = if smoothedPos and not snap then (smoothedPos :: Vector3).Y + (target.Y - (smoothedPos :: Vector3).Y) * posAlpha else target.Y
	smoothedPos = Vector3.new(target.X, y, target.Z)
	local look = cf.Position + h * 10 + Vector3.new(0, 2.2, 0)
	local out = CFrame.lookAt(smoothedPos :: Vector3, look)

	if not Settings.reducedMotion then
		local targetLean = if tel.drifting then -tel.steer * math.rad(C.DriftLeanDegrees) else 0
		lean += (targetLean - lean) * math.min(1, 5 * dt)
		local shake = C.ShakeAmplitude * math.max(0, speedRatio - 0.6) ^ 2 * 6
		if tel.boosting then
			shake += 0.05
		end
		local tNow = os.clock()
		out *= CFrame.Angles(
			math.noise(tNow * 9, 0.3) * shake * 0.05,
			math.noise(tNow * 9, 7.1) * shake * 0.05,
			lean
		)
	end
	return out
end

local function update(dt: number)
	local camera = Workspace.CurrentCamera
	local phase = RaceClient.phase()
	local car = RaceClient.car
	local chassis = car and car.PrimaryPart
	local racing = phase ~= "Idle" and chassis ~= nil
	if not racing then
		if wasRacing then
			wasRacing = false
			restoreDefault(camera)
		end
		return
	end
	assert(chassis)
	local snap = not wasRacing
	wasRacing = true
	camera.CameraType = Enum.CameraType.Scriptable
	local state = RaceClient.state :: any
	local now = RaceClient.now()
	local tel = Vehicle.telemetry
	local reduced = Settings.reducedMotion

	local targetFov = C.BaseFov
	if phase == "Intro" and now < state.goTime - RC.CountdownSeconds then
		-- flyover: sweep from a low front 3/4 to behind the car
		local f = math.clamp((now - state.introStart) / RC.IntroSeconds, 0, 1)
		local e = 1 - (1 - f) ^ 3
		local angle = math.rad(150 - 150 * e) -- 150° (front-ish) → 0° (behind)
		local radius = 30 - 13 * e
		local height = 3 + 3 * e
		local cf = chassis.CFrame
		local offset = (cf * CFrame.Angles(0, angle, 0)).LookVector * -radius
		local pos = cf.Position + offset + Vector3.new(0, height, 0)
		camera.CFrame = CFrame.lookAt(pos, cf.Position + Vector3.new(0, 1.5, 0))
		targetFov = 55 + 15 * e
		resetSmoothing()
	elseif phase == "Results" then
		local cf = chassis.CFrame
		local a = os.clock() * 0.25
		local pos = cf.Position + Vector3.new(math.cos(a) * 22, 7, math.sin(a) * 22)
		camera.CFrame = camera.CFrame:Lerp(CFrame.lookAt(pos, cf.Position + Vector3.new(0, 1.5, 0)), math.min(1, 3 * dt))
		targetFov = 60
		resetSmoothing()
	elseif Settings.cameraMode == "Hood" then
		camera.CFrame = chassis.CFrame * CFrame.new(0, 2.9, -1.5) * CFrame.Angles(math.rad(-3), 0, 0)
		targetFov = C.BaseFov + (if reduced then 4 else C.SpeedFov) * math.clamp(tel.speedAbs / Config.Vehicle.TopSpeed, 0, 1.3)
		resetSmoothing()
	else
		camera.CFrame = chaseCFrame(chassis, dt, snap or smoothedPos == nil)
		local ratio = math.clamp(tel.speedAbs / Config.Vehicle.TopSpeed, 0, 1.3)
		targetFov = C.BaseFov + (if reduced then 4 else C.SpeedFov) * ratio
		if tel.boosting and not reduced then
			targetFov += C.BoostFov
		end
	end
	fov += (targetFov - fov) * math.min(1, 4 * dt)
	camera.FieldOfView = fov
end

function RaceCamera.init()
	RaceClient.Recovered:Connect(resetSmoothing)
	RaceClient.CarChanged:Connect(function()
		resetSmoothing()
	end)
	Input.CameraPressed:Connect(function()
		Settings.cycleCamera()
		resetSmoothing()
	end)
end

function RaceCamera.start()
	RunService:BindToRenderStep("RiftRaceCamera", Enum.RenderPriority.Camera.Value + 1, update)
end

return RaceCamera
