--!strict
-- Client mirror of the server race state. Other controllers read from here
-- and subscribe to its signals; nothing here is authoritative.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Net = require(ReplicatedStorage.Shared.Net)
local Signal = require(ReplicatedStorage.Shared.Util.Signal)
local Types = require(ReplicatedStorage.Shared.Types)

local player = Players.LocalPlayer

local RaceClient = {}

RaceClient.state = nil :: Types.RaceStatePayload?
RaceClient.participating = false
RaceClient.car = nil :: Model?
RaceClient.progress = nil :: Types.ProgressPayload?
RaceClient.standings = {} :: { Types.StandingRow }
RaceClient.queue = nil :: Types.QueuePayload?

RaceClient.StateChanged = Signal.new()
RaceClient.CarChanged = Signal.new()
RaceClient.ProgressChanged = Signal.new()
RaceClient.StandingsChanged = Signal.new()
RaceClient.Results = Signal.new()
RaceClient.QueueChanged = Signal.new()
RaceClient.Notice = Signal.new()
RaceClient.Recovered = Signal.new()
RaceClient.VoteChanged = Signal.new()
RaceClient.Celebrate = Signal.new()
RaceClient.vote = nil :: Types.VotePayload?

function RaceClient.now(): number
	return Workspace:GetServerTimeNow()
end

function RaceClient.phase(): Types.RacePhase
	local s = RaceClient.state
	return if s and RaceClient.participating then s.phase else "Idle"
end

function RaceClient.nameOf(userId: number): string
	local s = RaceClient.state
	if s then
		for _, r in s.racers do
			if r.userId == userId then
				return r.name
			end
		end
	end
	return "Racer"
end

local carRequest = 0
local function findCar()
	carRequest += 1
	local myRequest = carRequest
	task.spawn(function()
		local active = Workspace:WaitForChild("ActiveRace", 10)
		local cars = active and active:WaitForChild("Cars", 10)
		local car = cars and cars:WaitForChild("Car_" .. player.UserId, 10)
		if myRequest ~= carRequest then
			return
		end
		if car and car:IsA("Model") then
			car:WaitForChild("Chassis", 5)
			RaceClient.car = car
			RaceClient.CarChanged:Fire(car)
		end
	end)
end

function RaceClient.init()
	Net.onClient("RaceState", function(payload: Types.RaceStatePayload)
		local was = RaceClient.participating
		local wasRace = RaceClient.state and RaceClient.state.raceId
		RaceClient.state = payload
		local mine = false
		if payload.phase ~= "Idle" then
			for _, r in payload.racers do
				if r.userId == player.UserId then
					mine = true
				end
			end
		end
		RaceClient.participating = mine
		if mine and (not was or wasRace ~= payload.raceId or not RaceClient.car) then
			RaceClient.progress = nil
			RaceClient.standings = {}
			findCar()
		elseif not mine and RaceClient.car then
			carRequest += 1
			RaceClient.car = nil
			RaceClient.CarChanged:Fire(nil)
		end
		RaceClient.StateChanged:Fire(payload)
	end)
	Net.onClient("RaceProgress", function(p: Types.ProgressPayload)
		local s = RaceClient.state
		if s and p.raceId == s.raceId then
			RaceClient.progress = p
			RaceClient.ProgressChanged:Fire(p)
		end
	end)
	Net.onClient("Standings", function(rows: { Types.StandingRow })
		RaceClient.standings = rows
		RaceClient.StandingsChanged:Fire(rows)
	end)
	Net.onClient("RaceResults", function(rows: { Types.ResultRow })
		RaceClient.Results:Fire(rows)
	end)
	Net.onClient("QueueState", function(q: Types.QueuePayload)
		RaceClient.queue = q
		RaceClient.QueueChanged:Fire(q)
	end)
	Net.onClient("VoteState", function(v: Types.VotePayload)
		RaceClient.vote = v
		RaceClient.VoteChanged:Fire(v)
	end)
	Net.onClient("Celebrate", function(winner: string, mapName: string)
		RaceClient.Celebrate:Fire(winner, mapName)
	end)
	Net.onClient("Notice", function(text: string, kind: string)
		RaceClient.Notice:Fire(text, kind)
	end)
	Net.onClient("Recovered", function(cf: CFrame)
		local car = RaceClient.car
		if car and car.PrimaryPart and typeof(cf) == "CFrame" then
			car:PivotTo(cf)
			car.PrimaryPart.AssemblyLinearVelocity = Vector3.zero
			car.PrimaryPart.AssemblyAngularVelocity = Vector3.zero
		end
		RaceClient.Recovered:Fire()
	end)
end

function RaceClient.myPosition(): (number?, number)
	for _, row in RaceClient.standings do
		if row.u == player.UserId then
			return row.p, #RaceClient.standings
		end
	end
	return nil, #RaceClient.standings
end

return RaceClient
