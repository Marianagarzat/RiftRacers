--!strict
-- Arcade raycast-suspension vehicle, simulated by the owning client.
-- Four suspension rays push the chassis with spring/damper impulses; drive,
-- lateral grip, yaw and boost are applied as impulses / velocity shaping.
-- The handling numbers are shared (Config.Vehicle) — every car is equal.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Config = require(ReplicatedStorage.Shared.Config)
local Net = require(ReplicatedStorage.Shared.Net)
local RaceClient = require(script.Parent.RaceClient)
local Input = require(script.Parent.Input)

local V = Config.Vehicle
local player = Players.LocalPlayer

export type Telemetry = {
	active: boolean,
	speed: number, -- signed forward speed, studs/s
	speedAbs: number,
	sideSpeed: number,
	throttle: number,
	steer: number, -- smoothed -1..1
	braking: boolean,
	drifting: boolean,
	boosting: boolean,
	boost: number, -- 0..1 meter
	grounded: boolean,
	yawRate: number,
}

local Vehicle = {}

Vehicle.telemetry = {
	active = false,
	speed = 0,
	speedAbs = 0,
	sideSpeed = 0,
	throttle = 0,
	steer = 0,
	braking = false,
	drifting = false,
	boosting = false,
	boost = 0.5,
	grounded = false,
	yawRate = 0,
} :: Telemetry

local rayParams = RaycastParams.new()
rayParams.FilterType = Enum.RaycastFilterType.Exclude
rayParams.CollisionGroup = "RiftWheelRay"
rayParams.IgnoreWater = true

local WHEELS = { "FL", "FR", "RL", "RR" }
local padUntil = 0
Vehicle.PadHit = require(ReplicatedStorage.Shared.Util.Signal).new()
local flippedFor = 0
local controlsDisabled = false

local function setCharacterControls(enabled: boolean)
	if controlsDisabled == not enabled then
		return
	end
	controlsDisabled = not enabled
	local ok, playerModule = pcall(function()
		return require(player:WaitForChild("PlayerScripts"):WaitForChild("PlayerModule") :: ModuleScript) :: any
	end)
	if ok and playerModule then
		local controls = playerModule:GetControls()
		if enabled then
			controls:Enable()
		else
			controls:Disable()
		end
	end
	local character = player.Character
	local humanoid = character and character:FindFirstChildOfClass("Humanoid")
	if humanoid then
		humanoid:SetStateEnabled(Enum.HumanoidStateType.Jumping, enabled)
	end
end

local function step(dt: number)
	local t = Vehicle.telemetry
	local car = RaceClient.car
	local phase = RaceClient.phase()
	local driving = car ~= nil and (phase == "Racing" or phase == "Results")
	local chassis = car and car.PrimaryPart
	if not driving or not chassis or chassis.Anchored or not chassis:IsDescendantOf(workspace) then
		t.active = false
		t.speed, t.speedAbs, t.sideSpeed = 0, 0, 0
		t.drifting, t.boosting, t.braking = false, false, false
		return
	end
	assert(car and chassis)
	t.active = true
	dt = math.min(dt, 1 / 20)

	local input = Input.read()
	local finished = RaceClient.progress and RaceClient.progress.finished
	if phase == "Results" or finished then
		-- coast to a stop after the flag
		input.throttle = if t.speedAbs > 5 then -0.25 else 0
		input.boost = false
		input.handbrake = false
	end

	rayParams.FilterDescendantsInstances = { car }
	local mass = chassis.AssemblyMass
	local cf = chassis.CFrame
	local up = cf.UpVector
	local g = workspace.Gravity
	local rayLen = V.RestLength + V.WheelRadius
	local k = (mass * g / 4) / V.RestCompression
	local c = 2 * V.SpringDamping * math.sqrt(k * mass / 4)

	-- ── Suspension ──────────────────────────────────────────────────────
	local grounded = 0
	local normalSum = Vector3.zero
	for _, name in WHEELS do
		local offset = V.WheelOffsets[name] :: Vector3
		local origin = cf:PointToWorldSpace(offset)
		local hit = workspace:Raycast(origin, -up * rayLen, rayParams)
		if hit then
			if hit.Instance:GetAttribute("BoostPad") and os.clock() > padUntil - V.BoostPadSeconds + 0.4 then
				if os.clock() > padUntil then
					Vehicle.PadHit:Fire()
				end
				padUntil = os.clock() + V.BoostPadSeconds
				t.boost = math.min(1, t.boost + 0.1)
			end
			grounded += 1
			normalSum += hit.Normal
			local compression = rayLen - hit.Distance
			local pointVel = chassis:GetVelocityAtPosition(origin)
			local force = k * compression - c * pointVel:Dot(up)
			force = math.clamp(force, 0, mass * g * 3)
			chassis:ApplyImpulseAtPosition(up * force * dt, origin)
		end
	end

	local vel = chassis.AssemblyLinearVelocity
	local isGrounded = grounded >= 2
	local normal = if grounded > 0 then normalSum.Unit else Vector3.yAxis
	local fwd = cf.LookVector
	fwd = (fwd - normal * fwd:Dot(normal))
	if fwd.Magnitude < 1e-3 then
		fwd = cf.LookVector
	end
	fwd = fwd.Unit
	local right = fwd:Cross(normal).Unit
	local fwdSpeed = vel:Dot(fwd)
	local sideSpeed = vel:Dot(right)

	-- ── Boost meter ─────────────────────────────────────────────────────
	local drifting = input.handbrake and isGrounded and math.abs(fwdSpeed) > V.DriftMinSpeed
	local onPad = os.clock() < padUntil
	local boosting = (input.boost and t.boost > 0.02 and fwdSpeed > 10) or onPad
	if boosting and not onPad then
		t.boost = math.max(0, t.boost - V.BoostDrainPerSecond * dt)
	else
		t.boost = math.min(1, t.boost + V.BoostPassiveRecharge * dt)
	end
	if drifting and math.abs(sideSpeed) > 12 then
		t.boost = math.min(1, t.boost + V.BoostDriftRecharge * dt)
	end

	-- ── Steering smoothing (keyboard ramps, analog follows directly) ───
	local target = input.steer
	local response = if input.analogSteer then 18 else V.SteerResponse
	t.steer += (target - t.steer) * math.min(1, response * dt)

	local braking = false
	if isGrounded then
		-- Drive / brake
		local top = if onPad then V.BoostPadSpeed elseif boosting then V.BoostTopSpeed else V.TopSpeed
		local accel = if onPad then V.BoostAcceleration * 1.8 elseif boosting then V.BoostAcceleration else V.Acceleration
		local dv = 0
		if boosting and fwdSpeed < top then
			dv = accel * dt
		elseif input.throttle > 0.05 then
			if fwdSpeed < top then
				local ratio = math.clamp(fwdSpeed / top, 0, 1)
				dv = accel * input.throttle * (1 - ratio * ratio * 0.85) * dt
			end
		elseif input.throttle < -0.05 then
			if fwdSpeed > 2 then
				braking = true
				dv = -math.min(V.BrakeDeceleration * -input.throttle * dt, fwdSpeed)
			elseif fwdSpeed > -V.ReverseTopSpeed then
				dv = V.Acceleration * 0.6 * input.throttle * dt
			end
		else
			-- coast
			dv = -math.sign(fwdSpeed) * math.min(V.CoastDeceleration * dt, math.abs(fwdSpeed))
		end
		-- over top speed (after boost ends): bleed off smoothly
		if fwdSpeed > top + 1 then
			dv = math.min(dv, -(fwdSpeed - top) * 1.2 * dt)
		end
		if input.handbrake then
			dv -= math.sign(fwdSpeed) * math.min(12 * dt, math.abs(fwdSpeed))
		end
		chassis:ApplyImpulse(fwd * dv * mass)

		-- Lateral grip
		local grip = if drifting then V.DriftGrip else V.Grip
		local removal = sideSpeed * math.min(1, grip * dt)
		chassis:ApplyImpulse(-right * removal * mass)

		-- Downforce keeps the car planted at speed
		local df = V.Downforce * math.clamp(math.abs(fwdSpeed) / V.TopSpeed, 0, 1.4)
		chassis:ApplyImpulse(-normal * g * df * mass * dt)

		-- Yaw (arcade: shape angular velocity about the ground normal)
		local speedFactor = math.clamp(math.abs(fwdSpeed) / 22, 0, 1)
		local ratio = math.clamp(math.abs(fwdSpeed) / V.TopSpeed, 0, 1)
		local yawMax = V.MaxYawRateLow + (V.MaxYawRateHigh - V.MaxYawRateLow) * ratio
		if drifting then
			yawMax *= V.DriftYawMultiplier
		end
		local dir = if fwdSpeed >= 0 then 1 else -1
		local desiredYaw = -t.steer * yawMax * speedFactor * dir
		local ang = chassis.AssemblyAngularVelocity
		local curYaw = ang:Dot(normal)
		local newYaw = curYaw + (desiredYaw - curYaw) * math.min(1, 10 * dt)
		local other = ang - normal * curYaw
		other *= (1 - math.min(1, 2.5 * dt)) -- damp roll/pitch wobble
		chassis.AssemblyAngularVelocity = other + normal * newYaw
	else
		-- Airborne: gently level the car for clean landings
		local ang = chassis.AssemblyAngularVelocity
		local axis = up:Cross(Vector3.yAxis)
		chassis.AssemblyAngularVelocity = ang * (1 - math.min(1, 1.5 * dt)) + axis * V.AirStabilize * dt * 10
	end

	-- ── Auto-recover when flipped / stuck upside down ──────────────────
	if up.Y < 0.25 and vel.Magnitude < 20 then
		flippedFor += dt
		if flippedFor > V.FlipRecoverSeconds then
			flippedFor = -1
			Net.fireServer("RequestRecover")
		end
	else
		flippedFor = math.max(0, flippedFor)
		if flippedFor > 0 then
			flippedFor = 0
		end
	end

	t.speed = fwdSpeed
	t.speedAbs = math.abs(fwdSpeed)
	t.sideSpeed = sideSpeed
	t.throttle = input.throttle
	t.braking = braking
	t.drifting = drifting
	t.boosting = boosting
	t.grounded = isGrounded
	t.yawRate = chassis.AssemblyAngularVelocity:Dot(normal)
end

function Vehicle.init()
	Input.RecoverPressed:Connect(function()
		if RaceClient.phase() == "Racing" then
			Net.fireServer("RequestRecover")
		end
	end)
	RaceClient.StateChanged:Connect(function()
		local p = RaceClient.phase()
		local racing = p == "Intro" or p == "Racing" or p == "Results"
		setCharacterControls(not racing)
		Input.setEnabled(racing)
		if p == "Intro" then
			Vehicle.telemetry.boost = 0.5
		end
	end)
	player.CharacterAdded:Connect(function(character: Model)
		local p = RaceClient.phase()
		if p == "Intro" or p == "Racing" then
			local h = character:WaitForChild("Humanoid", 5) :: Humanoid?
			if h then
				h:SetStateEnabled(Enum.HumanoidStateType.Jumping, false)
			end
		end
	end)
end

function Vehicle.start()
	RunService.PreSimulation:Connect(step)
end

return Vehicle
