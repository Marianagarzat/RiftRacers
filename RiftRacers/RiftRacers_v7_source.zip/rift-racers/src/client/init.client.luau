--!strict
-- RIFT RACERS · the single client entry point (two-phase boot).

local Controllers = script:WaitForChild("Controllers")
local ORDER = {
	"Settings",
	"RaceClient",
	"Input",
	"Vehicle",
	"VehicleVisuals",
	"RaceCamera",
	"Environment",
	"LobbyFun",
	"HUD",
}

local loaded: { [string]: any } = {}
for _, name in ORDER do
	loaded[name] = require(Controllers:WaitForChild(name) :: ModuleScript) :: any
end
for _, name in ORDER do
	local c = loaded[name]
	if typeof(c.init) == "function" then
		c.init()
	end
end
for _, name in ORDER do
	local c = loaded[name]
	if typeof(c.start) == "function" then
		task.spawn(c.start)
	end
end
