--!strict
-- THE NEXUS — a bright, playful racing-festival plaza.
-- Interactive bits (handled client-side by Controllers/LobbyFun):
--   • GlowTile  — painted plaza tiles that light up when you step on them
--   • JumpPad   — trampolines that launch you into the air
--   • SpeedPad  — sprint strips that boost walk speed for a few seconds
--   • PaintPad  — prompts that repaint the showroom car (local preview)
--   • Fireworks — launched over the plaza when a race is won
-- Plus: Race Portal, World Preview posters, winners board, food stalls,
-- fountains, balloons, bunting and parked show cars.

local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Config = require(ReplicatedStorage.Shared.Config)
local MapDefinitions = require(ReplicatedStorage.Shared.MapDefinitions)
local PosterArt = require(ReplicatedStorage.Shared.Util.PosterArt)
local Style = require(script.Parent.Style)
local Props = require(script.Parent.Props)
local CarFactory = require(script.Parent.CarFactory)

local UI = Config.UI

export type LobbyHandles = {
	model: Folder,
	spawn: SpawnLocation,
	portalPrompt: ProximityPrompt,
	winnerRows: { TextLabel },
	statusLabel: TextLabel,
}

local LobbyBuilder = {}

local FESTIVAL = {
	Color3.fromRGB(255, 80, 120), -- pink
	Color3.fromRGB(255, 160, 40), -- orange
	Color3.fromRGB(255, 220, 60), -- yellow
	Color3.fromRGB(60, 210, 140), -- green
	Color3.fromRGB(50, 180, 255), -- blue
	Color3.fromRGB(150, 100, 255), -- purple
}
LobbyBuilder.FESTIVAL = FESTIVAL
local WHITE = Color3.fromRGB(250, 250, 248)
local INK = Color3.fromRGB(30, 28, 45)

local function p(parent: Instance, name: string, size: Vector3, cf: CFrame, color: Color3, material: Enum.Material?, extra: { [string]: any }?): BasePart
	local spec: Style.PartSpec = { name = name, size = size, cframe = cf, color = color, material = material or Enum.Material.Plastic, parent = parent }
	if extra then
		for k, v in extra do
			(spec :: any)[k] = v
		end
	end
	return Style.part(spec)
end

local function cartoonSign(part: BasePart, face: Enum.NormalId, text: string, color: Color3, ppm: number?, font: Enum.Font?): TextLabel
	local l = Style.sign(part, face, text, color, ppm or 16, font or Enum.Font.LuckiestGuy)
	local st = l:FindFirstChildOfClass("UIStroke")
	if st then
		st.Color = INK
		st.Thickness = 5
		st.Transparency = 0
	end
	local g = l.Parent :: SurfaceGui
	g.Brightness = 1.2
	g.LightInfluence = 0.4
	return l
end

local function marquee(parent: Instance, cf: CFrame, w: number, h: number)
	-- bulbs around a sign frame
	local n = math.floor((w + h) / 2.2)
	for i = 0, n - 1 do
		local t = i / n
		local perim = 2 * (w + h)
		local d = t * perim
		local x, y
		if d < w then
			x, y = -w / 2 + d, h / 2
		elseif d < w + h then
			x, y = w / 2, h / 2 - (d - w)
		elseif d < 2 * w + h then
			x, y = w / 2 - (d - w - h), -h / 2
		else
			x, y = -w / 2, -h / 2 + (d - 2 * w - h)
		end
		local b = p(parent, "Bulb", Vector3.new(0.8, 0.8, 0.8), cf * CFrame.new(x, y, -0.4), Color3.fromRGB(255, 235, 150), Enum.Material.Neon, { shape = Enum.PartType.Ball, collide = false, query = false, castShadow = false })
		b:SetAttribute("Order", i)
		CollectionService:AddTag(b, "MarqueeBulb")
	end
end

local function fountain(parent: Instance, pos: Vector3)
	local m = Instance.new("Model")
	m.Name = "Fountain"
	m.Parent = parent
	p(m, "Basin", Vector3.new(3, 26, 26), CFrame.new(pos + Vector3.new(0, 1.5, 0)) * CFrame.Angles(0, 0, math.rad(90)), WHITE, Enum.Material.Marble, { shape = Enum.PartType.Cylinder })
	p(m, "Water", Vector3.new(0.4, 23, 23), CFrame.new(pos + Vector3.new(0, 2.9, 0)) * CFrame.Angles(0, 0, math.rad(90)), Color3.fromRGB(60, 180, 255), Enum.Material.Glass, { shape = Enum.PartType.Cylinder, transparency = 0.3, collide = false, reflectance = 0.3 })
	p(m, "Column", Vector3.new(6, 2.6, 2.6), CFrame.new(pos + Vector3.new(0, 5.5, 0)) * CFrame.Angles(0, 0, math.rad(90)), WHITE, Enum.Material.Marble, { shape = Enum.PartType.Cylinder })
	local bowl = p(m, "Bowl", Vector3.new(1.4, 10, 10), CFrame.new(pos + Vector3.new(0, 8.5, 0)) * CFrame.Angles(0, 0, math.rad(90)), WHITE, Enum.Material.Marble, { shape = Enum.PartType.Cylinder })
	local att = Instance.new("Attachment")
	att.Position = Vector3.new(0.8, 0, 0)
	att.CFrame = CFrame.new(0.8, 0, 0) * CFrame.Angles(0, 0, math.rad(-90)) -- emit straight up
	att.Parent = bowl
	local e = Instance.new("ParticleEmitter")
	e.Name = "Jet"
	e.Color = ColorSequence.new(Color3.fromRGB(200, 240, 255), Color3.fromRGB(120, 200, 255))
	e.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.5), NumberSequenceKeypoint.new(1, 0.15) })
	e.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(1, 0.8) })
	e.Lifetime = NumberRange.new(1.2, 1.5)
	e.Speed = NumberRange.new(24, 30)
	e.SpreadAngle = Vector2.new(12, 12)
	e.Acceleration = Vector3.new(0, -40, 0)
	e.Rate = 120
	e.LightEmission = 0.3
	e.Parent = att
	CollectionService:AddTag(e, "DecorFX")
end

local function table_(parent: Instance, pos: Vector3, umbrellaColor: Color3)
	local m = Instance.new("Model")
	m.Name = "CafeTable"
	m.Parent = parent
	p(m, "Top", Vector3.new(0.4, 5, 5), CFrame.new(pos + Vector3.new(0, 3.2, 0)) * CFrame.Angles(0, 0, math.rad(90)), WHITE, Enum.Material.Marble, { shape = Enum.PartType.Cylinder })
	p(m, "Leg", Vector3.new(0.5, 3, 0.5), CFrame.new(pos + Vector3.new(0, 1.5, 0)), INK, Enum.Material.Metal)
	for k = 0, 2 do
		local a = k / 3 * math.pi * 2
		local cp = pos + Vector3.new(math.cos(a) * 4, 0, math.sin(a) * 4)
		p(m, "Chair", Vector3.new(2, 0.4, 2), CFrame.new(cp + Vector3.new(0, 2, 0)), FESTIVAL[(k % #FESTIVAL) + 1], Enum.Material.Plastic)
		p(m, "ChairLeg", Vector3.new(0.4, 2, 0.4), CFrame.new(cp + Vector3.new(0, 1, 0)), INK, Enum.Material.Metal)
	end
	Props.umbrella(m, pos, umbrellaColor, WHITE)
end

function LobbyBuilder.build(parent: Instance): LobbyHandles
	local root = Style.folder("NexusLobby", parent)
	local rng = Random.new(77)

	-- ── Ground: park, plaza, painted tile ring ──────────────────────────
	p(root, "Park", Vector3.new(1600, 2, 1600), CFrame.new(0, -2.2, 0), Color3.fromRGB(90, 190, 90), Enum.Material.Grass)
	p(root, "Plaza", Vector3.new(2, 360, 360), CFrame.new(0, -1, 0) * CFrame.Angles(0, 0, math.rad(90)), Color3.fromRGB(236, 226, 210), Enum.Material.Pavement, { shape = Enum.PartType.Cylinder })
	local tiles = Instance.new("Model")
	tiles.Name = "GlowTiles"
	tiles.Parent = root
	local sectors = 40
	for ring = 0, 2 do
		local r = 122 + ring * 15
		for k = 0, sectors - 1 do
			local a = (k + ring * 0.5) / sectors * math.pi * 2
			local w = 2 * math.pi * r / sectors - 0.8
			local t = p(tiles, "Tile", Vector3.new(14, 0.2, w), CFrame.new(math.cos(a) * r, 0.05, math.sin(a) * r) * CFrame.Angles(0, -a, 0), FESTIVAL[((k + ring * 2) % #FESTIVAL) + 1], Enum.Material.SmoothPlastic, { castShadow = false })
			t:SetAttribute("BaseColor", t.Color)
			CollectionService:AddTag(t, "GlowTile")
		end
	end
	-- radial walkway stripes
	for k = 0, 7 do
		local a = k / 8 * math.pi * 2 + math.pi / 8
		local mid = Vector3.new(math.cos(a), 0, math.sin(a)) * 80
		p(root, "Walk", Vector3.new(6, 0.1, 80), CFrame.lookAt(mid + Vector3.new(0, 0.03, 0), mid * 2 + Vector3.new(0, 0.03, 0)), Color3.fromRGB(250, 245, 235), Enum.Material.Marble, { castShadow = false })
	end

	-- ── Central showroom ────────────────────────────────────────────────
	local show = Instance.new("Model")
	show.Name = "CarShowcase"
	show.Parent = root
	p(show, "Base", Vector3.new(3, 52, 52), CFrame.new(0, 1.5, 0) * CFrame.Angles(0, 0, math.rad(90)), WHITE, Enum.Material.Marble, { shape = Enum.PartType.Cylinder })
	p(show, "Ring", Vector3.new(3.2, 46, 46), CFrame.new(0, 1.6, 0) * CFrame.Angles(0, 0, math.rad(90)), Color3.fromRGB(40, 40, 60), Enum.Material.SmoothPlastic, { shape = Enum.PartType.Cylinder, reflectance = 0.2 })
	local turntable = Instance.new("Model")
	turntable.Name = "Turntable"
	turntable.Parent = show
	local disc = p(turntable, "Disc", Vector3.new(0.6, 40, 40), CFrame.new(0, 3.4, 0) * CFrame.Angles(0, 0, math.rad(90)), Color3.fromRGB(28, 28, 40), Enum.Material.SmoothPlastic, { shape = Enum.PartType.Cylinder, reflectance = 0.3 })
	for k = 0, 11 do
		local a = k / 12 * math.pi * 2
		p(turntable, "DiscLight", Vector3.new(0.2, 1, 3), CFrame.new(math.cos(a) * 18.5, 3.75, math.sin(a) * 18.5) * CFrame.Angles(0, -a, 0), FESTIVAL[(k % #FESTIVAL) + 1], Enum.Material.Neon, { collide = false, query = false, castShadow = false })
	end
	local _ = disc
	local displayCar = CarFactory.build({ name = "ShowcaseCar", paint = Color3.fromRGB(255, 70, 110), accent = Color3.fromRGB(255, 220, 60), anchored = true, number = 1 })
	displayCar:PivotTo(CFrame.new(0, 3.7 + 2.7, 0) * CFrame.Angles(0, math.rad(35), 0))
	displayCar.Parent = turntable
	turntable:SetAttribute("SpinSpeed", 0.25)
	turntable:SetAttribute("Pivot", Vector3.zero)
	CollectionService:AddTag(turntable, "Spin")
	-- paint pads around the showroom
	local paints: { { name: string, color: Color3 } } = {
		{ name = "HOT PINK", color = Color3.fromRGB(255, 70, 110) },
		{ name = "SUNSET", color = Color3.fromRGB(255, 140, 40) },
		{ name = "TAXI", color = Color3.fromRGB(255, 210, 40) },
		{ name = "LIME", color = Color3.fromRGB(120, 220, 60) },
		{ name = "OCEAN", color = Color3.fromRGB(40, 160, 255) },
		{ name = "GRAPE", color = Color3.fromRGB(140, 80, 255) },
		{ name = "PEARL", color = Color3.fromRGB(245, 245, 250) },
		{ name = "STEALTH", color = Color3.fromRGB(30, 30, 36) },
	}
	for k, spec in paints do
		local a = (k - 1) / #paints * math.pi * 2
		local pos = Vector3.new(math.cos(a) * 34, 0, math.sin(a) * 34)
		local pad = p(show, "PaintPad", Vector3.new(0.8, 7, 7), CFrame.new(pos + Vector3.new(0, 0.4, 0)) * CFrame.Angles(0, 0, math.rad(90)), spec.color, Enum.Material.SmoothPlastic, { shape = Enum.PartType.Cylinder, reflectance = 0.15 })
		p(show, "PadRim", Vector3.new(0.7, 8, 8), CFrame.new(pos + Vector3.new(0, 0.35, 0)) * CFrame.Angles(0, 0, math.rad(90)), WHITE, Enum.Material.Plastic, { shape = Enum.PartType.Cylinder })
		local can = p(show, "PaintCan", Vector3.new(2.4, 2.4, 2.4), CFrame.new(pos + Vector3.new(0, 2.2, 0)) * CFrame.Angles(0, 0, math.rad(90)), spec.color, Enum.Material.Metal, { shape = Enum.PartType.Cylinder, collide = false })
		p(show, "Lid", Vector3.new(0.3, 2.5, 2.5), can.CFrame * CFrame.new(1.25, 0, 0), Color3.fromRGB(190, 190, 200), Enum.Material.Metal, { shape = Enum.PartType.Cylinder, collide = false })
		pad:SetAttribute("Paint", spec.color)
		pad:SetAttribute("PaintName", spec.name)
		local prompt = Instance.new("ProximityPrompt")
		prompt.Name = "PaintPrompt"
		prompt.ActionText = "Paint " .. spec.name
		prompt.ObjectText = "Showroom preview"
		prompt.HoldDuration = 0
		prompt.MaxActivationDistance = 10
		prompt.RequiresLineOfSight = false
		prompt.Parent = pad
		CollectionService:AddTag(pad, "PaintPad")
	end
	-- spot towers
	for i = 0, 3 do
		local a = i * math.pi / 2 + math.pi / 4
		local pos = Vector3.new(math.cos(a) * 44, 0, math.sin(a) * 44)
		p(show, "Truss", Vector3.new(1.6, 30, 1.6), CFrame.new(pos + Vector3.new(0, 15, 0)), Color3.fromRGB(60, 60, 70), Enum.Material.DiamondPlate)
		local head = p(show, "SpotHead", Vector3.new(3, 3, 4), CFrame.lookAt(pos + Vector3.new(0, 30, 0), Vector3.new(0, 5, 0)), INK, Enum.Material.Metal)
		local spot = Instance.new("SpotLight")
		spot.Face = Enum.NormalId.Front
		spot.Range = 70
		spot.Angle = 30
		spot.Brightness = 3
		spot.Color = FESTIVAL[(i % #FESTIVAL) + 1]:Lerp(WHITE, 0.6)
		spot.Shadows = true
		spot.Parent = head
	end

	-- ── Big marquee sign over the showroom ──────────────────────────────
	local signM = Instance.new("Model")
	signM.Name = "BigSign"
	signM.Parent = root
	for _, face in { 0, math.pi } do
		local cf = CFrame.new(0, 52, 0) * CFrame.Angles(0, face, 0) * CFrame.new(0, 0, -1)
		local board = p(signM, "Board", Vector3.new(64, 16, 1), cf, INK, Enum.Material.SmoothPlastic, { collide = false, query = false })
		local l = cartoonSign(board, Enum.NormalId.Front, "RIFT RACERS", Color3.fromRGB(255, 220, 60), 12)
		local g = Instance.new("UIGradient")
		g.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 220, 60)), ColorSequenceKeypoint.new(0.5, Color3.fromRGB(255, 120, 60)), ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 80, 140)) })
		g.Rotation = 90
		g.Parent = l
		marquee(signM, cf, 66, 18)
	end
	p(signM, "Mast", Vector3.new(2, 40, 2), CFrame.new(0, 24, 0), Color3.fromRGB(60, 60, 70), Enum.Material.Metal, { collide = false })
	signM:SetAttribute("SpinSpeed", 0.12)
	signM:SetAttribute("Pivot", Vector3.zero)
	signM:SetAttribute("Bob", 0.8)
	CollectionService:AddTag(signM, "Spin")

	-- ── RACE PORTAL (north) — rainbow arch ──────────────────────────────
	local portal = Instance.new("Model")
	portal.Name = "RacePortal"
	portal.Parent = root
	local pcf = CFrame.lookAt(Vector3.new(0, 0, -132), Vector3.zero)
	for band = 1, #FESTIVAL do
		local r = 16 + band * 1.8
		for k = 0, 15 do
			local a0, a1 = k / 16 * math.pi, (k + 1) / 16 * math.pi
			local p0 = Vector3.new(math.cos(a0) * r, math.sin(a0) * r, 0)
			local p1 = Vector3.new(math.cos(a1) * r, math.sin(a1) * r, 0)
			p(portal, "Arch", Vector3.new(1.9, 3, (p1 - p0).Magnitude + 0.2), pcf * CFrame.new(0, 2, 0) * CFrame.lookAt((p0 + p1) / 2, p1), FESTIVAL[band], Enum.Material.SmoothPlastic)
		end
	end
	local veil = p(portal, "Veil", Vector3.new(0.3, 32, 32), pcf * CFrame.new(0, 2, 0) * CFrame.Angles(0, math.rad(90), 0), Color3.fromRGB(150, 220, 255), Enum.Material.ForceField, { shape = Enum.PartType.Cylinder, transparency = 0.15, collide = false, query = false, castShadow = false })
	local _v = veil
	local pad = p(portal, "Pad", Vector3.new(30, 0.6, 18), pcf * CFrame.new(0, 0.3, -11), WHITE, Enum.Material.SmoothPlastic)
	for c = 0, 9 do
		for rr = 0, 1 do
			p(portal, "Check", Vector3.new(3, 0.08, 3), pcf * CFrame.new(-13.5 + c * 3, 0.64, -19.5 + rr * 3), if (c + rr) % 2 == 0 then INK else WHITE, Enum.Material.SmoothPlastic, { collide = false, query = false, castShadow = false })
		end
	end
	for k = 0, 2 do
		for _, s in { -1, 1 } do
			p(portal, "Arrow", Vector3.new(1, 0.1, 5), pcf * CFrame.new(s * 1.8, 0.65, -4 - k * 4.5) * CFrame.Angles(0, math.rad(s * -35), 0), Color3.fromRGB(255, 200, 40), Enum.Material.Neon, { collide = false, query = false, castShadow = false })
		end
	end
	local signBoard = p(portal, "Sign", Vector3.new(34, 7, 1), pcf * CFrame.new(0, 34, 0), INK, Enum.Material.SmoothPlastic, { collide = false })
	cartoonSign(signBoard, Enum.NormalId.Front, "RACE!", Color3.fromRGB(255, 220, 60), 14)
	marquee(portal, pcf * CFrame.new(0, 34, 0), 35, 8)
	local statusPart = p(portal, "Status", Vector3.new(28, 3, 0.3), pcf * CFrame.new(0, 29, -0.6), INK, Enum.Material.SmoothPlastic, { collide = false, query = false })
	local statusLabel = cartoonSign(statusPart, Enum.NormalId.Front, "STEP ON THE PAD!", WHITE, 18, Enum.Font.FredokaOne)
	local prompt = Instance.new("ProximityPrompt")
	prompt.Name = "EnterRace"
	prompt.ActionText = "Join Race"
	prompt.ObjectText = "Race Portal"
	prompt.KeyboardKeyCode = Enum.KeyCode.E
	prompt.GamepadKeyCode = Enum.KeyCode.ButtonX
	prompt.HoldDuration = 0
	prompt.MaxActivationDistance = 20
	prompt.RequiresLineOfSight = false
	prompt.Parent = pad
	for _, s in { -1, 1 } do
		Props.flag(portal, (pcf * CFrame.new(s * 30, 0, 0)).Position, FESTIVAL[if s < 0 then 1 else 5], 26)
		Props.balloons(portal, (pcf * CFrame.new(s * 24, 0, -6)).Position, FESTIVAL, rng)
	end

	-- ── WORLD PREVIEW: three poster boards (north-east) ─────────────────
	local preview = Instance.new("Model")
	preview.Name = "WorldPreview"
	preview.Parent = root
	local wcf = CFrame.lookAt(Vector3.new(96, 0, -96), Vector3.zero)
	p(preview, "Stage", Vector3.new(70, 1.2, 16), wcf * CFrame.new(0, 0.6, 0), WHITE, Enum.Material.Marble)
	local titleBoard = p(preview, "Title", Vector3.new(40, 5, 0.6), wcf * CFrame.new(0, 28, 0.5), INK, Enum.Material.SmoothPlastic, { collide = false })
	cartoonSign(titleBoard, Enum.NormalId.Front, "VOTE YOUR WORLD", Color3.fromRGB(120, 230, 255), 14)
	for k, id in MapDefinitions.Order do
		local x = (k - 2) * 22
		p(preview, "Easel", Vector3.new(1, 22, 1), wcf * CFrame.new(x, 11, 1.2), Color3.fromRGB(150, 105, 65), Enum.Material.Wood)
		local board = p(preview, "Poster", Vector3.new(18, 22, 0.5), wcf * CFrame.new(x, 13, 0), WHITE, Enum.Material.SmoothPlastic, { collide = false })
		local gui = Instance.new("SurfaceGui")
		gui.Face = Enum.NormalId.Front
		gui.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
		gui.PixelsPerStud = 14
		gui.LightInfluence = 0.3
		gui.Parent = board
		PosterArt.draw(gui, id)
		local name = Instance.new("TextLabel")
		name.BackgroundColor3 = INK
		name.BorderSizePixel = 0
		name.AnchorPoint = Vector2.new(0, 1)
		name.Position = UDim2.fromScale(0, 1)
		name.Size = UDim2.fromScale(1, 0.16)
		name.Text = MapDefinitions.Maps[id].displayName
		name.TextScaled = true
		name.TextColor3 = WHITE
		name.FontFace = Font.fromEnum(Enum.Font.LuckiestGuy)
		name.ZIndex = 5
		name.Parent = gui
		p(preview, "Frame", Vector3.new(19, 23, 0.4), wcf * CFrame.new(x, 13, 0.4), FESTIVAL[(k * 2 % #FESTIVAL) + 1], Enum.Material.Plastic)
	end

	-- ── Garage (west) and Mystery Box tease (east) ──────────────────────
	do
		local gcf = CFrame.lookAt(Vector3.new(-132, 0, 0), Vector3.zero)
		local g = Instance.new("Model")
		g.Name = "Garage"
		g.Parent = root
		p(g, "Building", Vector3.new(60, 30, 34), gcf * CFrame.new(0, 15, 6), Color3.fromRGB(70, 140, 220), Enum.Material.Brick)
		p(g, "Roof", Vector3.new(64, 2, 38), gcf * CFrame.new(0, 31, 6), WHITE, Enum.Material.Metal)
		for k = 0, 9 do
			p(g, "Door", Vector3.new(44, 2, 0.6), gcf * CFrame.new(0, 1 + k * 2.1, -11.2), if k % 2 == 0 then Color3.fromRGB(230, 230, 235) else Color3.fromRGB(200, 200, 210), Enum.Material.Metal)
		end
		p(g, "DoorFrame", Vector3.new(48, 2, 1), gcf * CFrame.new(0, 22, -11.4), Color3.fromRGB(255, 200, 40), Enum.Material.Plastic)
		local sign = p(g, "Sign", Vector3.new(44, 7, 1), gcf * CFrame.new(0, 27, -11.6), INK, Enum.Material.SmoothPlastic, { collide = false })
		cartoonSign(sign, Enum.NormalId.Front, "GARAGE", Color3.fromRGB(120, 230, 255), 14)
		local soon = p(g, "Soon", Vector3.new(22, 3, 0.4), gcf * CFrame.new(0, 12, -11.9), Color3.fromRGB(255, 200, 40), Enum.Material.SmoothPlastic, { collide = false })
		cartoonSign(soon, Enum.NormalId.Front, "OPENING SOON", INK, 18, Enum.Font.FredokaOne)
		for k = 0, 3 do
			Props.tireStack(g, (gcf * CFrame.new(-26 + k * 3.5, 0, -16)).Position, FESTIVAL[k + 1])
		end
		Props.cone(g, (gcf * CFrame.new(18, 0, -16)).Position)
		Props.cone(g, (gcf * CFrame.new(22, 0, -18)).Position)
	end
	do
		local mcf = CFrame.lookAt(Vector3.new(132, 0, 0), Vector3.zero)
		local m = Instance.new("Model")
		m.Name = "MysteryBoxes"
		m.Parent = root
		p(m, "Pedestal", Vector3.new(4, 30, 30), mcf * CFrame.new(0, 2, 0) * CFrame.Angles(0, 0, math.rad(90)), WHITE, Enum.Material.Marble, { shape = Enum.PartType.Cylinder })
		local box = Instance.new("Model")
		box.Name = "GiantBox"
		box.Parent = m
		local bc = mcf * CFrame.new(0, 16, 0)
		p(box, "Cube", Vector3.new(18, 18, 18), bc, Color3.fromRGB(150, 90, 255), Enum.Material.SmoothPlastic, { reflectance = 0.1 })
		p(box, "RibbonA", Vector3.new(3, 18.3, 18.3), bc, Color3.fromRGB(255, 210, 50), Enum.Material.SmoothPlastic)
		p(box, "RibbonB", Vector3.new(18.3, 18.3, 3), bc, Color3.fromRGB(255, 210, 50), Enum.Material.SmoothPlastic)
		for _, s in { -1, 1 } do
			p(box, "Bow", Vector3.new(6, 4, 3), bc * CFrame.new(s * 3, 10.5, 0) * CFrame.Angles(0, 0, math.rad(s * 25)), Color3.fromRGB(255, 210, 50), Enum.Material.SmoothPlastic, { shape = Enum.PartType.Ball })
		end
		local face = p(box, "QFace", Vector3.new(12, 12, 0.2), bc * CFrame.new(5, 0, -9.2), Color3.new(0, 0, 0), Enum.Material.SmoothPlastic, { transparency = 1, collide = false, query = false })
		cartoonSign(face, Enum.NormalId.Front, "?", WHITE, 14)
		local face2 = p(box, "QFace2", Vector3.new(12, 12, 0.2), bc * CFrame.new(-5, 0, 9.2), Color3.new(0, 0, 0), Enum.Material.SmoothPlastic, { transparency = 1, collide = false, query = false })
		cartoonSign(face2, Enum.NormalId.Back, "?", WHITE, 14)
		box:SetAttribute("SpinSpeed", 0.4)
		box:SetAttribute("Pivot", bc.Position)
		box:SetAttribute("Bob", 1.5)
		CollectionService:AddTag(box, "Spin")
		local sign = p(m, "Sign", Vector3.new(40, 6, 1), mcf * CFrame.new(0, 33, 8), INK, Enum.Material.SmoothPlastic, { collide = false })
		cartoonSign(sign, Enum.NormalId.Front, "MYSTERY BOXES", Color3.fromRGB(255, 210, 50), 14)
		local soon = p(m, "Soon", Vector3.new(22, 3, 0.4), mcf * CFrame.new(0, 3, -16), Color3.fromRGB(255, 200, 40), Enum.Material.SmoothPlastic, { collide = false })
		cartoonSign(soon, Enum.NormalId.Front, "OPENING SOON", INK, 18, Enum.Font.FredokaOne)
		local sparkle = Instance.new("ParticleEmitter")
		sparkle.Texture = "rbxasset://textures/particles/sparkles_main.dds"
		sparkle.Color = ColorSequence.new(Color3.fromRGB(255, 230, 120), Color3.fromRGB(200, 150, 255))
		sparkle.Size = NumberSequence.new(1.2, 0)
		sparkle.Lifetime = NumberRange.new(1, 2)
		sparkle.Speed = NumberRange.new(3, 6)
		sparkle.SpreadAngle = Vector2.new(180, 180)
		sparkle.Rate = 25
		sparkle.LightEmission = 1
		sparkle.Parent = box:FindFirstChild("Cube")
		CollectionService:AddTag(sparkle, "DecorFX")
	end

	-- ── Winners board (south-east) ──────────────────────────────────────
	local boardCf = CFrame.lookAt(Vector3.new(96, 0, 96), Vector3.zero)
	local board = Instance.new("Model")
	board.Name = "WinnersBoard"
	board.Parent = root
	for _, x in { -15, 15 } do
		p(board, "Leg", Vector3.new(1.6, 12, 1.6), boardCf * CFrame.new(x, 6, 0), Color3.fromRGB(60, 60, 70), Enum.Material.Metal)
	end
	local screen = p(board, "Screen", Vector3.new(34, 20, 1), boardCf * CFrame.new(0, 21, 0), INK, Enum.Material.SmoothPlastic)
	p(board, "Frame", Vector3.new(36, 22, 0.6), boardCf * CFrame.new(0, 21, 0.4), Color3.fromRGB(255, 200, 40), Enum.Material.Plastic)
	marquee(board, boardCf * CFrame.new(0, 21, 0), 36, 22)
	local gui = Instance.new("SurfaceGui")
	gui.Face = Enum.NormalId.Front
	gui.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	gui.PixelsPerStud = 20
	gui.LightInfluence = 0
	gui.Brightness = 1.4
	gui.Parent = screen
	local boardTitle = Instance.new("TextLabel")
	boardTitle.BackgroundTransparency = 1
	boardTitle.Size = UDim2.new(1, 0, 0.2, 0)
	boardTitle.Text = "🏆 RECENT WINNERS"
	boardTitle.TextScaled = true
	boardTitle.FontFace = Font.fromEnum(Enum.Font.LuckiestGuy)
	boardTitle.TextColor3 = Color3.fromRGB(255, 210, 50)
	boardTitle.Parent = gui
	local rows: { TextLabel } = {}
	for i = 1, 5 do
		local row = Instance.new("TextLabel")
		row.Name = "Row" .. i
		row.BackgroundColor3 = FESTIVAL[((i - 1) % #FESTIVAL) + 1]
		row.BorderSizePixel = 0
		row.Position = UDim2.new(0.04, 0, 0.22 + (i - 1) * 0.15, 0)
		row.Size = UDim2.new(0.92, 0, 0.13, 0)
		row.Text = if i == 1 then "No races yet — be the first!" else ""
		row.TextScaled = true
		row.TextXAlignment = Enum.TextXAlignment.Left
		row.FontFace = Font.fromEnum(Enum.Font.FredokaOne)
		row.TextColor3 = WHITE
		row.Parent = gui
		local c = Instance.new("UICorner")
		c.CornerRadius = UDim.new(0.3, 0)
		c.Parent = row
		local pad_ = Instance.new("UIPadding")
		pad_.PaddingLeft = UDim.new(0.03, 0)
		pad_.Parent = row
		local st = Instance.new("UIStroke")
		st.Color = INK
		st.Thickness = 2
		st.ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual
		st.Parent = row
		table.insert(rows, row)
	end

	-- ── Interactive pads ────────────────────────────────────────────────
	for k = 0, 3 do
		local a = k / 4 * math.pi * 2 + math.pi / 4
		local pos = Vector3.new(math.cos(a) * 100, 0, math.sin(a) * 100)
		local jm = Instance.new("Model")
		jm.Name = "JumpPad"
		jm.Parent = root
		p(jm, "Base", Vector3.new(1.2, 14, 14), CFrame.new(pos + Vector3.new(0, 0.6, 0)) * CFrame.Angles(0, 0, math.rad(90)), INK, Enum.Material.Metal, { shape = Enum.PartType.Cylinder })
		local top = p(jm, "Bounce", Vector3.new(0.5, 11, 11), CFrame.new(pos + Vector3.new(0, 1.35, 0)) * CFrame.Angles(0, 0, math.rad(90)), FESTIVAL[(k * 2 % #FESTIVAL) + 1], Enum.Material.Neon, { shape = Enum.PartType.Cylinder })
		CollectionService:AddTag(top, "JumpPad")
		local hint = p(jm, "Hint", Vector3.new(10, 2.4, 0.2), CFrame.lookAt(pos + Vector3.new(0, 6, 0), Vector3.new(0, 6, 0)), Color3.new(0, 0, 0), Enum.Material.SmoothPlastic, { transparency = 1, collide = false, query = false })
		cartoonSign(hint, Enum.NormalId.Front, "JUMP!", WHITE, 18)
		cartoonSign(hint, Enum.NormalId.Back, "JUMP!", WHITE, 18)
	end
	for k = 0, 3 do
		local a = k / 4 * math.pi * 2
		local dir = Vector3.new(math.cos(a), 0, math.sin(a))
		local mid = dir * 60
		local strip = p(root, "SpeedPad", Vector3.new(8, 0.15, 24), CFrame.lookAt(mid + Vector3.new(0, 0.08, 0), mid + dir + Vector3.new(0, 0.08, 0)), Color3.fromRGB(255, 200, 40), Enum.Material.SmoothPlastic, { castShadow = false })
		for i = 0, 2 do
			for _, s in { -1, 1 } do
				p(strip, "Arrow", Vector3.new(0.8, 0.05, 4.5), strip.CFrame * CFrame.new(s * 1.6, 0.1, 6 - i * 6) * CFrame.Angles(0, math.rad(s * 35), 0), Color3.fromRGB(255, 80, 30), Enum.Material.Neon, { collide = false, query = false, castShadow = false })
			end
		end
		CollectionService:AddTag(strip, "SpeedPad")
	end

	-- ── Food stalls, tables, fountains, trees, balloons, bunting ───────
	local stalls = { "NITRO NOODLES", "TURBO TACOS", "PIT STOP PIZZA", "BOOST BOBA" }
	for k, title in stalls do
		local a = (k - 1) / #stalls * math.pi * 2 + math.pi / 4 + 0.32
		local pos = Vector3.new(math.cos(a) * 196, 0, math.sin(a) * 196)
		Props.kiosk(root, CFrame.lookAt(pos, Vector3.zero), title, FESTIVAL[(k % #FESTIVAL) + 1], FESTIVAL[((k + 2) % #FESTIVAL) + 1], WHITE)
		for t = -1, 1, 2 do
			local tp = (CFrame.lookAt(pos, Vector3.zero) * CFrame.new(t * 12, 0, -16)).Position
			table_(root, tp, FESTIVAL[((k + t + 3) % #FESTIVAL) + 1])
		end
	end
	for k = 0, 1 do
		local a = k * math.pi + math.pi / 2 + 0.3
		fountain(root, Vector3.new(math.cos(a) * 92, 0, math.sin(a) * 92))
	end
	for k = 0, 23 do
		local a = k / 24 * math.pi * 2
		local pos = Vector3.new(math.cos(a) * rng:NextNumber(232, 280), 0, math.sin(a) * rng:NextNumber(232, 280))
		if rng:NextNumber() < 0.6 then
			Props.roundTree(root, pos, rng:NextNumber(18, 30), Color3.fromRGB(80, 180, 80):Lerp(Color3.fromRGB(255, 160, 200), if rng:NextNumber() < 0.3 then 0.7 else 0), rng)
		else
			Props.palm(root, pos, rng:NextNumber(24, 34), rng)
		end
	end
	for k = 0, 7 do
		local a = k / 8 * math.pi * 2 + math.pi / 8
		Props.flowerBed(root, CFrame.lookAt(Vector3.new(math.cos(a) * 168, 0, math.sin(a) * 168), Vector3.zero), Vector2.new(16, 6), FESTIVAL, rng)
	end
	-- lamp posts with bunting between them
	local lampPts: { Vector3 } = {}
	for k = 0, 15 do
		local a = k / 16 * math.pi * 2
		local pos = Vector3.new(math.cos(a) * 176, 0, math.sin(a) * 176)
		local lm = Instance.new("Model")
		lm.Name = "Lamp"
		lm.Parent = root
		p(lm, "Pole", Vector3.new(0.9, 18, 0.9), CFrame.new(pos + Vector3.new(0, 9, 0)), INK, Enum.Material.Metal)
		local globe = p(lm, "Globe", Vector3.new(2.4, 2.4, 2.4), CFrame.new(pos + Vector3.new(0, 18.6, 0)), Color3.fromRGB(255, 240, 200), Enum.Material.Neon, { shape = Enum.PartType.Ball, collide = false })
		Style.pointLight(globe, Color3.fromRGB(255, 220, 170), 30, 1, true)
		table.insert(lampPts, pos + Vector3.new(0, 17, 0))
	end
	for k = 1, #lampPts do
		local a, b = lampPts[k], lampPts[(k % #lampPts) + 1]
		if k % 2 == 0 then
			Props.bunting(root, a, b, FESTIVAL)
		else
			Props.stringLights(root, a, b, FESTIVAL)
		end
	end
	for _ = 1, 10 do
		local a = rng:NextNumber(0, math.pi * 2)
		local d = rng:NextNumber(60, 170)
		Props.balloons(root, Vector3.new(math.cos(a) * d, 0, math.sin(a) * d), FESTIVAL, rng)
	end

	-- ── Parked show cars on podiums ─────────────────────────────────────
	local parked = Instance.new("Folder")
	parked.Name = "ParkedCars"
	parked.Parent = root
	local specs = {
		{ pos = Vector3.new(-70, 0, -88), paint = Color3.fromRGB(40, 160, 255), accent = Color3.fromRGB(255, 220, 60) },
		{ pos = Vector3.new(52, 0, 104), paint = Color3.fromRGB(255, 160, 40), accent = Color3.fromRGB(40, 40, 50) },
		{ pos = Vector3.new(-96, 0, 60), paint = Color3.fromRGB(120, 220, 60), accent = Color3.fromRGB(255, 80, 140) },
	}
	for i, s in specs do
		p(parked, "Podium", Vector3.new(1.4, 22, 22), CFrame.new(s.pos + Vector3.new(0, 0.7, 0)) * CFrame.Angles(0, 0, math.rad(90)), WHITE, Enum.Material.Marble, { shape = Enum.PartType.Cylinder })
		local car = CarFactory.build({ name = "ParkedCar" .. i, paint = s.paint, accent = s.accent, anchored = true, number = 10 + i })
		car:PivotTo(CFrame.lookAt(s.pos + Vector3.new(0, 1.4 + 2.7, 0), Vector3.new(0, 1.4 + 2.7, 0)) * CFrame.Angles(0, math.rad(30), 0))
		car.Parent = parked
	end

	-- ── Colourful town + hills on the horizon ───────────────────────────
	local town = Style.folder("Town", root)
	for k = 0, 31 do
		local a = k / 32 * math.pi * 2 + rng:NextNumber(-0.04, 0.04)
		local d = rng:NextNumber(330, 420)
		local h = rng:NextNumber(30, 110)
		local w = rng:NextNumber(30, 54)
		local pos = Vector3.new(math.cos(a) * d, h / 2 - 2, math.sin(a) * d)
		local cf = CFrame.lookAt(pos, Vector3.new(0, pos.Y, 0))
		local col = Color3.fromHSV(rng:NextNumber(), rng:NextNumber(0.35, 0.6), 1)
		p(town, "House", Vector3.new(w, h, w), cf, col, Enum.Material.Concrete)
		for f = 1, math.floor(h / 12) do
			p(town, "WindowStrip", Vector3.new(w * 0.8, 3, 0.3), cf * CFrame.new(0, -h / 2 + f * 12 - 4, -w / 2 - 0.1), Color3.fromRGB(170, 220, 255), Enum.Material.Glass, { collide = false, query = false, castShadow = false, reflectance = 0.3 })
		end
		p(town, "RoofTrim", Vector3.new(w + 1, 2, w + 1), cf * CFrame.new(0, h / 2, 0), WHITE, Enum.Material.Plastic, { castShadow = false })
	end
	for k = 0, 11 do
		local a = k / 12 * math.pi * 2
		local r = rng:NextNumber(150, 260)
		p(town, "Hill", Vector3.new(r * 2, r, r * 2), CFrame.new(math.cos(a) * 750, -r * 0.25, math.sin(a) * 750), Color3.fromRGB(110, 190, 100):Lerp(Color3.fromRGB(70, 150, 90), rng:NextNumber()), Enum.Material.Grass, { shape = Enum.PartType.Ball, castShadow = false })
	end

	-- ── Spawn ───────────────────────────────────────────────────────────
	local spawn = Instance.new("SpawnLocation")
	spawn.Name = "NexusSpawn"
	spawn.Size = Vector3.new(14, 0.4, 14)
	spawn.CFrame = CFrame.lookAt(Vector3.new(0, 0.2, 100), Vector3.new(0, 0.2, 0))
	spawn.Anchored = true
	spawn.Transparency = 1
	spawn.CanCollide = false
	spawn.Neutral = true
	spawn.Duration = 0
	spawn.Parent = root
	local decal = spawn:FindFirstChildOfClass("Decal")
	if decal then
		decal:Destroy()
	end
	local _ui = UI

	return {
		model = root,
		spawn = spawn,
		portalPrompt = prompt,
		winnerRows = rows,
		statusLabel = statusLabel,
	}
end

return LobbyBuilder
