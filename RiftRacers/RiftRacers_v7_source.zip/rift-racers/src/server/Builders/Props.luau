--!strict
-- Reusable, hand-composed props. Each one is built from several parts with
-- real Roblox materials (wood, fabric, metal, rock, grass…) instead of plain
-- neon boxes, so scenes read as places rather than abstract shapes.

local CollectionService = game:GetService("CollectionService")
local Style = require(script.Parent.Style)

local Props = {}

local WHITE = Color3.fromRGB(245, 245, 240)
local DARK = Color3.fromRGB(40, 40, 48)
local METAL = Color3.fromRGB(150, 155, 165)

local function p(parent: Instance, name: string, size: Vector3, cf: CFrame, color: Color3, material: Enum.Material?, extra: { [string]: any }?): BasePart
	local spec: Style.PartSpec = {
		name = name,
		size = size,
		cframe = cf,
		color = color,
		material = material or Enum.Material.Plastic,
		parent = parent,
	}
	if extra then
		for k, v in extra do
			(spec :: any)[k] = v
		end
	end
	return Style.part(spec)
end

local function model(parent: Instance, name: string): Model
	local m = Instance.new("Model")
	m.Name = name
	m.Parent = parent
	return m
end

local function deco(extra: { [string]: any }?): { [string]: any }
	local t: { [string]: any } = { collide = false, query = false }
	if extra then
		for k, v in extra do
			t[k] = v
		end
	end
	return t
end

-- ── Nature ───────────────────────────────────────────────────────────────
function Props.palm(parent: Instance, base: Vector3, height: number, rng: Random)
	local m = model(parent, "Palm")
	local segs = 7
	local lean = rng:NextNumber(-0.35, 0.35)
	local yaw = rng:NextNumber(0, math.pi * 2)
	local pos = base
	local dir = CFrame.Angles(0, yaw, 0) * CFrame.Angles(lean, 0, 0)
	local segLen = height / segs
	for i = 1, segs do
		local bend = CFrame.Angles(lean * 0.12 * i, 0, 0)
		local cf = CFrame.new(pos) * dir * bend * CFrame.new(0, segLen / 2, 0)
		local r = 2.2 - i * 0.15
		p(m, "Trunk", Vector3.new(segLen + 0.3, r, r), cf * CFrame.Angles(0, 0, math.rad(90)), Color3.fromRGB(150, 110, 70):Lerp(Color3.fromRGB(120, 90, 60), i / segs), Enum.Material.Wood, deco({ shape = Enum.PartType.Cylinder }))
		pos = (cf * CFrame.new(0, segLen / 2, 0)).Position
	end
	local top = CFrame.new(pos)
	for i = 0, 7 do
		local a = i / 8 * math.pi * 2 + rng:NextNumber(-0.2, 0.2)
		local frond = top * CFrame.Angles(0, a, 0) * CFrame.Angles(math.rad(-25 - rng:NextNumber(0, 20)), 0, 0) * CFrame.new(0, 0, -5)
		local green = Color3.fromRGB(40, 150, 60):Lerp(Color3.fromRGB(110, 190, 70), rng:NextNumber())
		p(m, "Frond", Vector3.new(3.2, 0.3, 11), frond, green, Enum.Material.LeafyGrass, deco())
		p(m, "FrondTip", Vector3.new(1.6, 0.3, 4), frond * CFrame.new(0, -0.6, -6.5) * CFrame.Angles(math.rad(-25), 0, 0), green, Enum.Material.LeafyGrass, deco())
	end
	for i = 0, 2 do
		p(m, "Coconut", Vector3.new(1.4, 1.4, 1.4), top * CFrame.Angles(0, i * 2.1, 0) * CFrame.new(0.9, -1, 0), Color3.fromRGB(110, 80, 40), Enum.Material.Wood, deco({ shape = Enum.PartType.Ball }))
	end
end

function Props.roundTree(parent: Instance, base: Vector3, height: number, leaf: Color3, rng: Random)
	local m = model(parent, "Tree")
	p(m, "Trunk", Vector3.new(height * 0.5, 1.8, 1.8), CFrame.new(base + Vector3.new(0, height * 0.25, 0)) * CFrame.Angles(0, 0, math.rad(90)), Color3.fromRGB(120, 85, 55), Enum.Material.Wood, deco({ shape = Enum.PartType.Cylinder }))
	for i = 1, 4 do
		local off = Vector3.new(rng:NextNumber(-2, 2), height * 0.55 + rng:NextNumber(0, 3), rng:NextNumber(-2, 2))
		local s = height * rng:NextNumber(0.35, 0.5)
		p(m, "Leaves", Vector3.new(s, s, s), CFrame.new(base + off), leaf:Lerp(Color3.new(1, 1, 1), rng:NextNumber(0, 0.15)), Enum.Material.LeafyGrass, deco({ shape = Enum.PartType.Ball }))
	end
end

function Props.flowerBed(parent: Instance, cf: CFrame, size: Vector2, colors: { Color3 }, rng: Random)
	local m = model(parent, "FlowerBed")
	p(m, "Planter", Vector3.new(size.X, 1.6, size.Y), cf * CFrame.new(0, 0.8, 0), Color3.fromRGB(230, 225, 215), Enum.Material.Concrete)
	p(m, "Soil", Vector3.new(size.X - 1, 0.3, size.Y - 1), cf * CFrame.new(0, 1.6, 0), Color3.fromRGB(70, 140, 60), Enum.Material.Grass, deco())
	local count = math.floor(size.X * size.Y / 10)
	for _ = 1, count do
		local x = rng:NextNumber(-size.X / 2 + 1, size.X / 2 - 1)
		local z = rng:NextNumber(-size.Y / 2 + 1, size.Y / 2 - 1)
		p(m, "Flower", Vector3.new(1, 1, 1), cf * CFrame.new(x, 2.2, z), colors[rng:NextInteger(1, #colors)], Enum.Material.Plastic, deco({ shape = Enum.PartType.Ball, castShadow = false }))
	end
end

-- ── Racing furniture ─────────────────────────────────────────────────────
function Props.tireStack(parent: Instance, pos: Vector3, band: Color3)
	local m = model(parent, "Tires")
	for i = 0, 3 do
		local tire = p(m, "Tire", Vector3.new(1.2, 3.2, 3.2), CFrame.new(pos + Vector3.new(0, 0.6 + i * 1.2, 0)) * CFrame.Angles(0, 0, math.rad(90)), Color3.fromRGB(25, 25, 28), Enum.Material.Rubber, { shape = Enum.PartType.Cylinder })
		if i % 2 == 0 then
			p(m, "Band", Vector3.new(0.5, 3.3, 3.3), tire.CFrame, band, Enum.Material.Plastic, deco({ shape = Enum.PartType.Cylinder }))
		end
	end
end

function Props.cone(parent: Instance, pos: Vector3)
	local m = model(parent, "Cone")
	p(m, "Base", Vector3.new(1.6, 0.2, 1.6), CFrame.new(pos + Vector3.new(0, 0.1, 0)), Color3.fromRGB(255, 110, 20), Enum.Material.Plastic, deco())
	for i = 0, 2 do
		local s = 1.1 - i * 0.3
		p(m, "Body", Vector3.new(0.7, s, s), CFrame.new(pos + Vector3.new(0, 0.55 + i * 0.6, 0)) * CFrame.Angles(0, 0, math.rad(90)), if i == 1 then WHITE else Color3.fromRGB(255, 110, 20), Enum.Material.Plastic, deco({ shape = Enum.PartType.Cylinder }))
	end
end

-- Chevron board: arrows point toward `dir` (+1 = right, -1 = left) in cf space.
function Props.chevron(parent: Instance, cf: CFrame, dir: number, bg: Color3, fg: Color3)
	local m = model(parent, "Chevron")
	p(m, "Post", Vector3.new(0.5, 6, 0.5), cf * CFrame.new(0, 3, 0.3), METAL, Enum.Material.Metal, deco())
	local board = p(m, "Board", Vector3.new(7, 3, 0.3), cf * CFrame.new(0, 6.5, 0), bg, Enum.Material.Plastic, deco())
	for i = -1, 1 do
		for _, s in { 1, -1 } do
			p(m, "Arrow", Vector3.new(0.5, 1.6, 0.1), board.CFrame * CFrame.new(i * 2 + dir * 0.35, s * 0.55, -0.2) * CFrame.Angles(0, 0, math.rad(dir * s * 40)), fg, Enum.Material.Neon, deco({ castShadow = false }))
		end
	end
end

function Props.flag(parent: Instance, base: Vector3, color: Color3, height: number?)
	local h = height or 14
	local m = model(parent, "Flag")
	p(m, "Pole", Vector3.new(0.35, h, 0.35), CFrame.new(base + Vector3.new(0, h / 2, 0)), WHITE, Enum.Material.Metal, deco())
	local cloth = p(m, "Cloth", Vector3.new(0.1, 2.6, 4.2), CFrame.new(base + Vector3.new(0, h - 1.6, 2.2)), color, Enum.Material.Fabric, deco())
	CollectionService:AddTag(cloth, "FlagCloth")
end

-- Pennant bunting from a to b (sagging), alternating colours.
function Props.bunting(parent: Instance, a: Vector3, b: Vector3, colors: { Color3 })
	local m = model(parent, "Bunting")
	local n = math.max(4, math.floor((b - a).Magnitude / 3))
	local function at(t: number): Vector3
		return a:Lerp(b, t) - Vector3.new(0, math.sin(t * math.pi) * (b - a).Magnitude * 0.06, 0)
	end
	for i = 0, n - 1 do
		local t0, t1 = i / n, (i + 1) / n
		local p0, p1 = at(t0), at(t1)
		p(m, "String", Vector3.new(0.08, 0.08, (p1 - p0).Magnitude), CFrame.lookAt((p0 + p1) / 2, p1), DARK, Enum.Material.Fabric, deco({ castShadow = false }))
		local mid = (p0 + p1) / 2
		local look = CFrame.lookAt(mid, p1)
		local tri = Instance.new("WedgePart")
		tri.Name = "Pennant"
		tri.Size = Vector3.new(0.05, 1.8, 1.4)
		tri.CFrame = look * CFrame.new(0, -0.9, 0) * CFrame.Angles(math.pi, 0, 0)
		tri.Color = colors[(i % #colors) + 1]
		tri.Material = Enum.Material.Fabric
		tri.Anchored = true
		tri.CanCollide = false
		tri.CanQuery = false
		tri.CanTouch = false
		tri.CastShadow = false
		tri.Parent = m
	end
end

-- String of glowing bulbs from a to b.
function Props.stringLights(parent: Instance, a: Vector3, b: Vector3, colors: { Color3 })
	local m = model(parent, "StringLights")
	local n = math.max(4, math.floor((b - a).Magnitude / 4))
	local prev = a
	for i = 1, n do
		local t = i / n
		local pt = a:Lerp(b, t) - Vector3.new(0, math.sin(t * math.pi) * (b - a).Magnitude * 0.08, 0)
		p(m, "Wire", Vector3.new(0.06, 0.06, (pt - prev).Magnitude), CFrame.lookAt((prev + pt) / 2, pt), DARK, Enum.Material.Plastic, deco({ castShadow = false }))
		if i < n then
			p(m, "Bulb", Vector3.new(0.6, 0.6, 0.6), CFrame.new(pt - Vector3.new(0, 0.4, 0)), colors[(i % #colors) + 1], Enum.Material.Neon, deco({ shape = Enum.PartType.Ball, castShadow = false }))
		end
		prev = pt
	end
	CollectionService:AddTag(m, "TwinkleLights")
end

-- Grandstand with seats, roof, crowd rows (tagged for client "cheer").
function Props.grandstand(parent: Instance, cf: CFrame, length: number, seatColors: { Color3 }, roofColor: Color3, rng: Random)
	local m = model(parent, "Grandstand")
	local rows = 6
	for r = 0, rows - 1 do
		local step = cf * CFrame.new(0, 1 + r * 1.8, r * 2.6)
		p(m, "Step", Vector3.new(length, 1.8 + r * 1.8, 2.6), step * CFrame.new(0, -(r * 1.8) / 2, 0), Color3.fromRGB(200, 200, 205), Enum.Material.Concrete)
		local row = Instance.new("Model")
		row.Name = "CrowdRow"
		row.Parent = m
		local seatColor = seatColors[(r % #seatColors) + 1]
		local seats = math.floor(length / 2.4)
		for s = 0, seats - 1 do
			local x = -length / 2 + 1.2 + s * 2.4
			p(m, "Seat", Vector3.new(1.8, 0.6, 1.4), step * CFrame.new(x, 1.2, 0.2), seatColor, Enum.Material.Plastic, deco())
			if rng:NextNumber() < 0.72 then
				local shirt = Color3.fromHSV(rng:NextNumber(), 0.7, 0.95)
				local skin = ({ Color3.fromRGB(255, 220, 180), Color3.fromRGB(200, 150, 110), Color3.fromRGB(140, 95, 65), Color3.fromRGB(240, 200, 160) })[rng:NextInteger(1, 4)]
				p(row, "Body", Vector3.new(1.4, 1.8, 0.9), step * CFrame.new(x, 2.4, 0.3), shirt, Enum.Material.Fabric, deco({ castShadow = false }))
				p(row, "Head", Vector3.new(1.1, 1.1, 1.1), step * CFrame.new(x, 3.8, 0.3), skin, Enum.Material.SmoothPlastic, deco({ shape = Enum.PartType.Ball, castShadow = false }))
				if rng:NextNumber() < 0.25 then
					p(row, "Sign", Vector3.new(1.6, 1.0, 0.1), step * CFrame.new(x, 5.2, 0.3), seatColors[rng:NextInteger(1, #seatColors)], Enum.Material.Plastic, deco({ castShadow = false }))
				end
			end
		end
		row:SetAttribute("Phase", r * 0.7 + rng:NextNumber())
		CollectionService:AddTag(row, "CrowdRow")
	end
	local backZ = rows * 2.6
	local roofY = 1 + rows * 1.8 + 8
	for _, x in { -length / 2 + 1, 0, length / 2 - 1 } do
		p(m, "Column", Vector3.new(1, roofY, 1), cf * CFrame.new(x, roofY / 2, backZ), METAL, Enum.Material.Metal)
	end
	p(m, "Roof", Vector3.new(length + 4, 0.8, rows * 2.6 + 6), cf * CFrame.new(0, roofY, backZ / 2 - 1) * CFrame.Angles(math.rad(-8), 0, 0), roofColor, Enum.Material.Metal)
	p(m, "RoofTrim", Vector3.new(length + 4.2, 0.6, 0.6), cf * CFrame.new(0, roofY - 1, -3.5), WHITE, Enum.Material.Plastic, deco())
	for i = 0, 4 do
		Props.flag(m, (cf * CFrame.new(-length / 2 + i * length / 4, roofY + 0.5, backZ / 2)).Position, seatColors[(i % #seatColors) + 1], 8)
	end
end

-- Banner sign with text (SurfaceGui), on two posts.
function Props.banner(parent: Instance, cf: CFrame, width: number, text: string, bg: Color3, fg: Color3, font: Enum.Font?)
	local m = model(parent, "Banner")
	for _, x in { -width / 2, width / 2 } do
		p(m, "Post", Vector3.new(0.6, 9, 0.6), cf * CFrame.new(x, 4.5, 0), METAL, Enum.Material.Metal, deco())
	end
	local board = p(m, "Board", Vector3.new(width, 3.4, 0.25), cf * CFrame.new(0, 7.5, 0), bg, Enum.Material.Fabric, deco())
	for _, face in { Enum.NormalId.Front, Enum.NormalId.Back } do
		local l = Style.sign(board, face, text, fg, 18, font or Enum.Font.LuckiestGuy)
		local g = l.Parent :: SurfaceGui
		g.Brightness = 1
		g.LightInfluence = 1
	end
end

-- Food / merch kiosk with striped awning and a painted sign.
function Props.kiosk(parent: Instance, cf: CFrame, title: string, body: Color3, stripeA: Color3, stripeB: Color3)
	local m = model(parent, "Kiosk")
	p(m, "Counter", Vector3.new(12, 4, 6), cf * CFrame.new(0, 2, 0), body, Enum.Material.WoodPlanks)
	p(m, "CounterTop", Vector3.new(12.6, 0.4, 6.6), cf * CFrame.new(0, 4.2, 0), WHITE, Enum.Material.Marble)
	p(m, "Back", Vector3.new(12, 10, 0.6), cf * CFrame.new(0, 5, 3), body:Lerp(Color3.new(0, 0, 0), 0.15), Enum.Material.WoodPlanks)
	for _, x in { -5.8, 5.8 } do
		p(m, "Post", Vector3.new(0.5, 9, 0.5), cf * CFrame.new(x, 8.5, -3), WHITE, Enum.Material.Metal)
	end
	for i = 0, 7 do
		local x = -5.25 + i * 1.5
		p(m, "Awning", Vector3.new(1.5, 0.3, 7.5), cf * CFrame.new(x, 12.3, -0.4) * CFrame.Angles(math.rad(14), 0, 0), if i % 2 == 0 then stripeA else stripeB, Enum.Material.Fabric, deco())
	end
	local sign = p(m, "Sign", Vector3.new(10, 2.6, 0.3), cf * CFrame.new(0, 14.2, 2.8), WHITE, Enum.Material.Plastic, deco())
	local l = Style.sign(sign, Enum.NormalId.Front, title, stripeA, 18, Enum.Font.LuckiestGuy)
	local g = l.Parent :: SurfaceGui
	g.Brightness = 1
	g.LightInfluence = 1
	local st = l:FindFirstChildOfClass("UIStroke")
	if st then
		st.Color = Color3.fromRGB(30, 30, 40)
		st.Transparency = 0
	end
	-- goods on the counter
	for i = 0, 4 do
		p(m, "Item", Vector3.new(1, 1.2, 1), cf * CFrame.new(-4 + i * 2, 5, -1.5), Color3.fromHSV((i * 0.17) % 1, 0.7, 1), Enum.Material.Plastic, deco({ shape = Enum.PartType.Cylinder }))
	end
	Style.pointLight(sign, Color3.fromRGB(255, 230, 190), 18, 0.8, true)
end

function Props.umbrella(parent: Instance, base: Vector3, a: Color3, b: Color3)
	local m = model(parent, "Umbrella")
	p(m, "Pole", Vector3.new(0.3, 8, 0.3), CFrame.new(base + Vector3.new(0, 4, 0)), WHITE, Enum.Material.Wood, deco())
	for i = 0, 7 do
		local ang = i / 8 * math.pi * 2
		local w = Instance.new("WedgePart")
		w.Size = Vector3.new(0.2, 1.2, 4.2)
		w.CFrame = CFrame.new(base + Vector3.new(0, 8, 0)) * CFrame.Angles(0, ang, 0) * CFrame.new(0, -0.4, -2.1) * CFrame.Angles(0, math.pi, 0)
		w.Color = if i % 2 == 0 then a else b
		w.Material = Enum.Material.Fabric
		w.Anchored, w.CanCollide, w.CanQuery, w.CanTouch = true, false, false, false
		w.Size = Vector3.new(3.4, 1.2, 4.2)
		w.Parent = m
	end
	p(m, "Towel", Vector3.new(3, 0.1, 6), CFrame.new(base + Vector3.new(3.5, 0.1, 0)), b, Enum.Material.Fabric, deco())
end

function Props.surfboard(parent: Instance, base: Vector3, color: Color3, yaw: number)
	local m = model(parent, "Surfboard")
	local cf = CFrame.new(base) * CFrame.Angles(0, yaw, 0) * CFrame.Angles(math.rad(-12), 0, 0)
	p(m, "Board", Vector3.new(2, 7, 0.35), cf * CFrame.new(0, 3.5, 0), color, Enum.Material.SmoothPlastic, deco())
	p(m, "Stripe", Vector3.new(0.4, 6.8, 0.38), cf * CFrame.new(0, 3.5, 0), WHITE, Enum.Material.SmoothPlastic, deco())
	p(m, "Nose", Vector3.new(0.35, 2, 2), cf * CFrame.new(0, 7, 0) * CFrame.Angles(0, math.rad(90), 0), color, Enum.Material.SmoothPlastic, deco({ shape = Enum.PartType.Cylinder }))
end

function Props.beachHouse(parent: Instance, cf: CFrame, wall: Color3, trim: Color3, rng: Random)
	local m = model(parent, "BeachHouse")
	local w, d = rng:NextNumber(26, 36), rng:NextNumber(22, 28)
	local floors = rng:NextInteger(1, 2)
	local h = floors * 11
	p(m, "Stilts", Vector3.new(w - 2, 3, d - 2), cf * CFrame.new(0, 1.5, 0), Color3.fromRGB(160, 120, 80), Enum.Material.WoodPlanks)
	p(m, "Walls", Vector3.new(w, h, d), cf * CFrame.new(0, 3 + h / 2, 0), wall, Enum.Material.WoodPlanks)
	p(m, "Porch", Vector3.new(w + 4, 0.6, 8), cf * CFrame.new(0, 3.3, -d / 2 - 4), Color3.fromRGB(190, 150, 105), Enum.Material.WoodPlanks)
	for _, x in { -w / 2 - 1.5, w / 2 + 1.5 } do
		p(m, "PorchPost", Vector3.new(0.6, 9, 0.6), cf * CFrame.new(x, 8, -d / 2 - 7.5), trim, Enum.Material.Wood)
	end
	p(m, "PorchRoof", Vector3.new(w + 5, 0.6, 9), cf * CFrame.new(0, 12.7, -d / 2 - 4), trim, Enum.Material.WoodPlanks)
	-- gable roof from two wedges
	local roofH = 8
	for _, s in { 1, -1 } do
		local wdg = Instance.new("WedgePart")
		wdg.Size = Vector3.new(w + 2, roofH, d / 2 + 1)
		wdg.CFrame = cf * CFrame.new(0, 3 + h + roofH / 2, s * (d / 4 + 0.5)) * CFrame.Angles(0, if s > 0 then math.pi else 0, 0)
		wdg.Color = Color3.fromRGB(240, 240, 235)
		wdg.Material = Enum.Material.Slate
		wdg.Anchored = true
		wdg.Parent = m
	end
	-- windows with shutters on the front
	for f = 0, floors - 1 do
		for i = -1, 1 do
			if not (f == 0 and i == 0) then
				local wc = cf * CFrame.new(i * w / 3.2, 3 + 5.5 + f * 11, -d / 2 - 0.15)
				p(m, "Window", Vector3.new(4, 4.5, 0.2), wc, Color3.fromRGB(150, 210, 240), Enum.Material.Glass, deco({ transparency = 0.1, reflectance = 0.2 }))
				p(m, "Frame", Vector3.new(4.6, 0.4, 0.3), wc * CFrame.new(0, -2.4, 0), WHITE, Enum.Material.Wood, deco())
				for _, sx in { -2.8, 2.8 } do
					p(m, "Shutter", Vector3.new(1.2, 4.8, 0.25), wc * CFrame.new(sx, 0, 0), trim, Enum.Material.WoodPlanks, deco())
				end
			end
		end
	end
	p(m, "Door", Vector3.new(4.5, 8, 0.3), cf * CFrame.new(0, 7, -d / 2 - 0.15), trim, Enum.Material.WoodPlanks, deco())
	if rng:NextNumber() < 0.6 then
		Props.stringLights(m, (cf * CFrame.new(-w / 2 - 1.5, 12, -d / 2 - 7.8)).Position, (cf * CFrame.new(w / 2 + 1.5, 12, -d / 2 - 7.8)).Position, { Color3.fromRGB(255, 220, 120), Color3.fromRGB(255, 140, 120), Color3.fromRGB(140, 220, 255) })
	end
end

function Props.boat(parent: Instance, cf: CFrame, hull: Color3, sail: boolean)
	local m = model(parent, "Boat")
	p(m, "Hull", Vector3.new(10, 3, 26), cf * CFrame.new(0, 1, 0), hull, Enum.Material.SmoothPlastic)
	local bow = Instance.new("WedgePart")
	bow.Size = Vector3.new(10, 3, 8)
	bow.CFrame = cf * CFrame.new(0, 1, -17)
	bow.Color = hull
	bow.Material = Enum.Material.SmoothPlastic
	bow.Anchored = true
	bow.Parent = m
	p(m, "Deck", Vector3.new(9, 0.4, 25), cf * CFrame.new(0, 2.7, 0), Color3.fromRGB(200, 160, 110), Enum.Material.WoodPlanks)
	p(m, "Cabin", Vector3.new(7, 4, 8), cf * CFrame.new(0, 4.8, 4), WHITE, Enum.Material.SmoothPlastic)
	if sail then
		p(m, "Mast", Vector3.new(0.6, 26, 0.6), cf * CFrame.new(0, 15, -4), WHITE, Enum.Material.Metal)
		local s = Instance.new("WedgePart")
		s.Size = Vector3.new(0.2, 20, 12)
		s.CFrame = cf * CFrame.new(0, 15, 2) * CFrame.Angles(0, math.pi, 0)
		s.Color = WHITE
		s.Material = Enum.Material.Fabric
		s.Anchored = true
		s.Parent = m
	end
end

-- ── Dreamland ────────────────────────────────────────────────────────────
function Props.cloud(parent: Instance, center: Vector3, scale: number, color: Color3, rng: Random)
	local m = model(parent, "Cloud")
	for _ = 1, 6 do
		local s = scale * rng:NextNumber(0.5, 1)
		local off = Vector3.new(rng:NextNumber(-1, 1) * scale, rng:NextNumber(-0.25, 0.25) * scale, rng:NextNumber(-0.6, 0.6) * scale)
		p(m, "Puff", Vector3.new(s, s * 0.7, s), CFrame.new(center + off), color, Enum.Material.SmoothPlastic, deco({ shape = Enum.PartType.Ball, castShadow = false, transparency = 0.05 }))
	end
	return m
end

function Props.lollipop(parent: Instance, base: Vector3, height: number, a: Color3, b: Color3)
	local m = model(parent, "Lollipop")
	p(m, "Stick", Vector3.new(height, 1.2, 1.2), CFrame.new(base + Vector3.new(0, height / 2, 0)) * CFrame.Angles(0, 0, math.rad(90)), WHITE, Enum.Material.SmoothPlastic, deco({ shape = Enum.PartType.Cylinder }))
	local top = CFrame.new(base + Vector3.new(0, height + 5, 0))
	for i = 0, 3 do
		local r = 12 - i * 3
		p(m, "Swirl", Vector3.new(1.4 + i * 0.05, r, r), top * CFrame.new(0, 0, -i * 0.05) * CFrame.Angles(0, math.rad(90), 0), if i % 2 == 0 then a else b, Enum.Material.SmoothPlastic, deco({ shape = Enum.PartType.Cylinder }))
	end
	CollectionService:AddTag(m, "SpinSlow")
	m:SetAttribute("Pivot", top.Position)
end

function Props.candyCane(parent: Instance, base: Vector3, height: number)
	local m = model(parent, "CandyCane")
	local n = math.floor(height / 3)
	for i = 0, n - 1 do
		p(m, "Seg", Vector3.new(3, 2.2, 2.2), CFrame.new(base + Vector3.new(0, 1.5 + i * 3, 0)) * CFrame.Angles(0, 0, math.rad(90)), if i % 2 == 0 then Color3.fromRGB(255, 70, 100) else WHITE, Enum.Material.SmoothPlastic, deco({ shape = Enum.PartType.Cylinder }))
	end
	local topY = n * 3
	for i = 1, 5 do
		local a = i / 5 * math.pi
		local pos = base + Vector3.new(-(1 - math.cos(a)) * 3, topY + math.sin(a) * 3, 0)
		p(m, "Hook", Vector3.new(2.4, 2.4, 2.4), CFrame.new(pos), if i % 2 == 0 then Color3.fromRGB(255, 70, 100) else WHITE, Enum.Material.SmoothPlastic, deco({ shape = Enum.PartType.Ball }))
	end
end

function Props.mushroom(parent: Instance, base: Vector3, scale: number, cap: Color3)
	local m = model(parent, "Mushroom")
	p(m, "Stem", Vector3.new(scale * 1.6, scale * 1.2, scale * 1.2), CFrame.new(base + Vector3.new(0, scale * 0.8, 0)) * CFrame.Angles(0, 0, math.rad(90)), Color3.fromRGB(255, 245, 225), Enum.Material.SmoothPlastic, deco({ shape = Enum.PartType.Cylinder }))
	p(m, "Cap", Vector3.new(scale * 3, scale * 1.6, scale * 3), CFrame.new(base + Vector3.new(0, scale * 1.8, 0)), cap, Enum.Material.SmoothPlastic, deco({ shape = Enum.PartType.Ball }))
	for i = 0, 4 do
		local a = i / 5 * math.pi * 2
		p(m, "Dot", Vector3.new(scale * 0.5, scale * 0.5, scale * 0.5), CFrame.new(base + Vector3.new(math.cos(a) * scale * 1.1, scale * 2.3, math.sin(a) * scale * 1.1)), WHITE, Enum.Material.SmoothPlastic, deco({ shape = Enum.PartType.Ball }))
	end
end

function Props.heart(parent: Instance, cf: CFrame, size: number, color: Color3, glow: boolean?)
	local m = model(parent, "Heart")
	local mat = if glow then Enum.Material.Neon else Enum.Material.SmoothPlastic
	for _, s in { -1, 1 } do
		p(m, "Lobe", Vector3.new(size * 0.6, size * 0.6, size * 0.3), cf * CFrame.new(s * size * 0.22, size * 0.15, 0), color, mat, deco({ shape = Enum.PartType.Cylinder }) :: any)
	end
	p(m, "Point", Vector3.new(size * 0.62, size * 0.62, size * 0.3), cf * CFrame.new(0, -size * 0.12, 0) * CFrame.Angles(0, 0, math.rad(45)), color, mat, deco())
	-- cylinders face along X by default; turn lobes to face forward
	for _, lobe in m:GetChildren() do
		if lobe:IsA("BasePart") and lobe.Name == "Lobe" then
			lobe.Size = Vector3.new(size * 0.3, size * 0.6, size * 0.6)
			lobe.CFrame = lobe.CFrame * CFrame.Angles(0, math.rad(90), 0)
		end
	end
	return m
end

function Props.sparkle(parent: Instance, pos: Vector3, size: number, color: Color3)
	local m = model(parent, "Sparkle")
	p(m, "Core", Vector3.new(size * 0.5, size * 0.5, size * 0.5), CFrame.new(pos), color, Enum.Material.Neon, deco({ shape = Enum.PartType.Ball, castShadow = false }))
	for i = 0, 3 do
		p(m, "Ray", Vector3.new(size * 0.15, size * 1.8, size * 0.15), CFrame.new(pos) * CFrame.Angles(0, 0, i * math.pi / 4), color, Enum.Material.Neon, deco({ castShadow = false, transparency = 0.2 }))
	end
	CollectionService:AddTag(m, "Twinkle")
	return m
end

function Props.floatingIsland(parent: Instance, center: Vector3, radius: number, grass: Color3, rng: Random)
	local m = model(parent, "Island")
	p(m, "Top", Vector3.new(4, radius * 2, radius * 2), CFrame.new(center) * CFrame.Angles(0, 0, math.rad(90)), grass, Enum.Material.Grass, { shape = Enum.PartType.Cylinder })
	for i = 1, 4 do
		local r = radius * (1 - i * 0.2)
		p(m, "Rock", Vector3.new(r * 1.6, r * 1.2, r * 1.6), CFrame.new(center - Vector3.new(0, 2 + i * r * 0.35, 0)), Color3.fromRGB(230, 190, 220):Lerp(Color3.fromRGB(170, 140, 200), i / 4), Enum.Material.SmoothPlastic, deco({ shape = Enum.PartType.Ball }))
	end
	for _ = 1, math.floor(radius / 3) do
		local a = rng:NextNumber(0, math.pi * 2)
		local d = rng:NextNumber(0, radius - 3)
		local pos = center + Vector3.new(math.cos(a) * d, 2, math.sin(a) * d)
		if rng:NextNumber() < 0.5 then
			Props.mushroom(m, pos, rng:NextNumber(1.2, 2.2), Color3.fromHSV(rng:NextNumber(), 0.45, 1))
		else
			p(m, "Flower", Vector3.new(1.4, 1.4, 1.4), CFrame.new(pos + Vector3.new(0, 0.6, 0)), Color3.fromHSV(rng:NextNumber(), 0.5, 1), Enum.Material.SmoothPlastic, deco({ shape = Enum.PartType.Ball }))
		end
	end
	return m
end

function Props.castleTower(parent: Instance, base: Vector3, height: number, radius: number, wall: Color3, roof: Color3)
	local m = model(parent, "Tower")
	p(m, "Wall", Vector3.new(height, radius * 2, radius * 2), CFrame.new(base + Vector3.new(0, height / 2, 0)) * CFrame.Angles(0, 0, math.rad(90)), wall, Enum.Material.SmoothPlastic, { shape = Enum.PartType.Cylinder })
	for i = 0, 3 do
		local r = radius * (1.2 - i * 0.3)
		p(m, "Roof", Vector3.new(radius * 0.9, r * 2, r * 2), CFrame.new(base + Vector3.new(0, height + radius * 0.4 + i * radius * 0.8, 0)) * CFrame.Angles(0, 0, math.rad(90)), roof, Enum.Material.SmoothPlastic, deco({ shape = Enum.PartType.Cylinder }))
	end
	Props.flag(m, base + Vector3.new(0, height + radius * 3.6, 0), roof, 6)
	for i = 0, 5 do
		local a = i / 6 * math.pi * 2
		p(m, "Window", Vector3.new(0.4, 3, 2), CFrame.new(base + Vector3.new(math.cos(a) * radius, height * 0.65, math.sin(a) * radius)) * CFrame.Angles(0, -a, 0), Color3.fromRGB(255, 240, 160), Enum.Material.Neon, deco({ castShadow = false }))
	end
	return m
end

function Props.balloons(parent: Instance, base: Vector3, colors: { Color3 }, rng: Random)
	local m = model(parent, "Balloons")
	for i = 1, 5 do
		local off = Vector3.new(rng:NextNumber(-2, 2), 10 + rng:NextNumber(0, 4), rng:NextNumber(-2, 2))
		local pos = base + off
		p(m, "String", Vector3.new(0.06, off.Magnitude, 0.06), CFrame.lookAt((base + pos) / 2, pos) * CFrame.Angles(math.rad(90), 0, 0), WHITE, Enum.Material.Plastic, deco({ castShadow = false }))
		p(m, "Balloon", Vector3.new(2.4, 3, 2.4), CFrame.new(pos), colors[((i - 1) % #colors) + 1], Enum.Material.SmoothPlastic, deco({ shape = Enum.PartType.Ball, reflectance = 0.15 }))
	end
	m:SetAttribute("Base", base)
	CollectionService:AddTag(m, "Bob")
	return m
end

return Props
