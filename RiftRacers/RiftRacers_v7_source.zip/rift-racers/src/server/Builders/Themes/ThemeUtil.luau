--!strict
-- Helpers shared by theme builders.

local ThemeUtil = {}

export type Ctx = {
	samples: { { position: Vector3, tangent: Vector3, segment: number, distance: number } },
	halfW: number,
	reserved: { { pos: Vector3, radius: number } },
}

-- Horizontal distance from p to the nearest road sample (+ that sample index).
function ThemeUtil.nearest(ctx: Ctx, p: Vector3): (number, number)
	local best, bestI = math.huge, 1
	local samples = ctx.samples
	for i = 1, #samples, 2 do
		local q = samples[i].position
		local dx, dz = q.X - p.X, q.Z - p.Z
		local d = dx * dx + dz * dz
		if d < best then
			best, bestI = d, i
		end
	end
	return math.sqrt(best), bestI
end

function ThemeUtil.isReserved(ctx: Ctx, p: Vector3, pad: number): boolean
	for _, r in ctx.reserved do
		local dx, dz = r.pos.X - p.X, r.pos.Z - p.Z
		if dx * dx + dz * dz < (r.radius + pad) ^ 2 then
			return true
		end
	end
	return false
end

-- Bounds of the circuit in XZ.
function ThemeUtil.bounds(ctx: Ctx): (number, number, number, number)
	local minX, maxX, minZ, maxZ = math.huge, -math.huge, math.huge, -math.huge
	for _, s in ctx.samples do
		minX = math.min(minX, s.position.X)
		maxX = math.max(maxX, s.position.X)
		minZ = math.min(minZ, s.position.Z)
		maxZ = math.max(maxZ, s.position.Z)
	end
	return minX, maxX, minZ, maxZ
end

-- Point beside the road at sample i: side = ±1, lateral offset from centre.
function ThemeUtil.beside(ctx: Ctx, i: number, side: number, lateral: number): (Vector3, CFrame)
	local s = ctx.samples[((i - 1) % #ctx.samples) + 1]
	local cf = CFrame.lookAt(s.position, s.position + s.tangent)
	local p = (cf * CFrame.new(side * lateral, 0, 0)).Position
	return p, cf
end

return ThemeUtil
