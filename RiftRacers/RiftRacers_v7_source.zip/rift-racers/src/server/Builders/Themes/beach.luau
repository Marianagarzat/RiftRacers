--!strict
-- SUNSET BEACH world: terrain ocean, sand and grass, rocky cliffs under the
-- cliff road, palm-lined roads, beach houses, kiosks along the boardwalk,
-- umbrellas, surfboards, boats, a lighthouse and string lights.

local Workspace = game:GetService("Workspace")
local Style = require(script.Parent.Parent.Style)
local Props = require(script.Parent.Parent.Props)
local ThemeUtil = require(script.Parent.ThemeUtil)

local Beach = {}

local KIOSKS = { "SURF SHACK", "TACO LOCO", "SMOOTHIES", "ICE CREAM", "COCO BAR", "FISH TACOS", "SUNSCREEN", "AGUA FRESCA" }

function Beach.build(ctx: any)
	local map = ctx.map
	local folder = ctx.folder :: Folder
	local rng = ctx.rng :: Random
	local palette = map.palette
	local halfW = ctx.halfW :: number
	local samples = ctx.samples
	local n = #samples
	local origin = map.origin :: Vector3
	local terrain = Workspace.Terrain
	local world = Style.folder("Coast", folder)

	local minX, maxX, minZ, maxZ = ThemeUtil.bounds(ctx)
	local cx, cz = (minX + maxX) / 2, (minZ + maxZ) / 2
	-- land rectangle: ocean lies north (high Z) and east (high X) of it
	local landMinX, landMaxX = minX - 420, origin.X + 1010
	local landMinZ, landMaxZ = minZ - 420, origin.Z + 870

	-- ── Terrain ─────────────────────────────────────────────────────────
	-- Terrain is voxel-aligned (4 studs): land surface at origin.Y - 4,
	-- sea surface at origin.Y - 8, roads are 6 studs thick so they sit on it.
	local landTop = origin.Y - 4
	local seaY = origin.Y - 8
	terrain:FillBlock(CFrame.new(cx, seaY - 8, cz), Vector3.new(3600, 16, 3600), Enum.Material.Water)
	local land = CFrame.new((landMinX + landMaxX) / 2, landTop - 8, (landMinZ + landMaxZ) / 2)
	terrain:FillBlock(land, Vector3.new(landMaxX - landMinX, 16, landMaxZ - landMinZ), Enum.Material.Sand)
	-- grass lawns in the infield / inland
	terrain:FillBlock(CFrame.new((landMinX + landMaxX) / 2 - 60, landTop - 8, (landMinZ + landMaxZ) / 2 - 80), Vector3.new(landMaxX - landMinX - 260, 16, landMaxZ - landMinZ - 300), Enum.Material.Grass)
	-- gentle dunes on the beach strip, well away from the road
	for _ = 1, 30 do
		local p = Vector3.new(rng:NextNumber(landMinX, landMaxX), landTop - 10, landMaxZ - rng:NextNumber(10, 50))
		if ThemeUtil.nearest(ctx, p) > halfW + 50 then
			terrain:FillBall(p, rng:NextNumber(12, 16), Enum.Material.Sand)
		end
	end
	-- road embankments + cliffs
	for i = 1, n, 2 do
		local s = samples[i]
		local kind = ctx.kindAt(i)
		local top = math.floor((s.position.Y - 6) / 4) * 4
		local height = top - (origin.Y - 16)
		if height > 1 then
			local cf = CFrame.lookAt(s.position, s.position + Vector3.new(s.tangent.X, 0, s.tangent.Z))
			local mat = if kind == "cliff" then Enum.Material.Rock else Enum.Material.Sand
			terrain:FillBlock(CFrame.new(s.position.X, origin.Y - 16 + height / 2, s.position.Z) * cf.Rotation, Vector3.new(halfW * 2 + 14, height, 24), mat)
			if kind == "cliff" and i % 6 == 1 then
				for _, side in { -1, 1 } do
					local p = (cf * CFrame.new(side * (halfW + 22 + rng:NextNumber(0, 18)), 0, 0)).Position
					terrain:FillBall(Vector3.new(p.X, top - 14 - rng:NextNumber(0, 10), p.Z), rng:NextNumber(18, 30), if rng:NextNumber() < 0.5 then Enum.Material.Rock else Enum.Material.Sandstone)
				end
			end
		end
	end

	-- ── Roadside: palms, houses, kiosks, lights ─────────────────────────
	local houseColors = { Color3.fromRGB(255, 190, 200), Color3.fromRGB(150, 220, 230), Color3.fromRGB(255, 225, 140), Color3.fromRGB(190, 230, 170), Color3.fromRGB(210, 190, 255), Color3.fromRGB(255, 170, 120) }
	local trims = { Color3.fromRGB(40, 160, 180), Color3.fromRGB(255, 110, 90), Color3.fromRGB(80, 120, 200), Color3.fromRGB(255, 255, 255) }
	local kioskN = 0
	for i = 1, n do
		local kind = ctx.kindAt(i)
		local s = samples[i]
		if kind == "street" and i % 6 == 0 then
			for _, side in { -1, 1 } do
				local p = ThemeUtil.beside(ctx, i + (if side > 0 then 3 else 0), side, halfW + 14 + rng:NextNumber(0, 6))
				local d = ThemeUtil.nearest(ctx, p)
				if d > halfW + 8 and not ThemeUtil.isReserved(ctx, p, 2) then
					Props.palm(world, Vector3.new(p.X, math.min(s.position.Y - 1.2, landTop + 0.5), p.Z), rng:NextNumber(22, 34), rng)
				end
			end
		end
		if kind == "street" and i % 19 == 7 then
			local side = if (i // 19) % 2 == 0 then 1 else -1
			local p, cf = ThemeUtil.beside(ctx, i, side, halfW + 48)
			local d = ThemeUtil.nearest(ctx, p)
			local inLand = p.X > landMinX + 30 and p.X < landMaxX - 30 and p.Z > landMinZ + 30 and p.Z < landMaxZ - 60
			if d > halfW + 30 and inLand and not ThemeUtil.isReserved(ctx, p, 20) then
				local face = CFrame.lookAt(Vector3.new(p.X, landTop, p.Z), Vector3.new(s.position.X, landTop, s.position.Z))
				Props.beachHouse(world, face, houseColors[rng:NextInteger(1, #houseColors)], trims[rng:NextInteger(1, #trims)], rng)
			end
			local _ = cf
		end
		if kind == "boardwalk" then
			if i % 6 == 0 then
				for _, side in { -1, 1 } do
					local a = ThemeUtil.beside(ctx, i, side, halfW + 1)
					local b = ThemeUtil.beside(ctx, i + 6, side, halfW + 1)
					Style.part({ name = "LightPost", size = Vector3.new(0.6, 10, 0.6), cframe = CFrame.new(a + Vector3.new(0, 5, 0)), color = Color3.fromRGB(150, 105, 65), material = Enum.Material.Wood, collide = false, query = false, parent = world })
					Props.stringLights(world, a + Vector3.new(0, 10, 0), b + Vector3.new(0, 10, 0), { Color3.fromRGB(255, 220, 120), Color3.fromRGB(255, 120, 150), Color3.fromRGB(120, 220, 255), Color3.fromRGB(180, 255, 140) })
				end
			end
			if i % 14 == 3 then
				kioskN += 1
				local side = if kioskN % 2 == 0 then 1 else -1
				local p = ThemeUtil.beside(ctx, i, side, halfW + 12)
				local face = CFrame.lookAt(Vector3.new(p.X, landTop, p.Z), Vector3.new(s.position.X, landTop, s.position.Z))
				Style.part({ name = "Deck", size = Vector3.new(20, 1, 16), cframe = face * CFrame.new(0, -0.5, 1), color = Color3.fromRGB(176, 128, 84), material = Enum.Material.WoodPlanks, parent = world })
				Props.kiosk(world, face, KIOSKS[((kioskN - 1) % #KIOSKS) + 1], houseColors[rng:NextInteger(1, #houseColors)], palette[(kioskN % #palette) + 1], Color3.fromRGB(255, 255, 255))
			end
		end
		if kind == "street" and i % 21 == 11 then
			local side = if i % 2 == 0 then 1 else -1
			local p = ThemeUtil.beside(ctx, i, side, halfW + 10)
			Props.banner(world, CFrame.lookAt(p, (ThemeUtil.beside(ctx, i, -side, halfW + 10))), 18, ({ "SUN & SPEED", "RIFT RACERS", "PARADISE FM", "PIÑA POWER", "SURF'S UP" })[rng:NextInteger(1, 5)], palette[rng:NextInteger(1, #palette)], Color3.new(1, 1, 1))
		end
	end

	-- ── Beach strip: umbrellas, surfboards, lifeguard tower, volleyball ─
	local beachZ = landMaxZ - 30
	local x = landMinX + 60
	while x < landMaxX - 60 do
		local p = Vector3.new(x + rng:NextNumber(-10, 10), landTop + 0.2, beachZ + rng:NextNumber(-12, 10))
		if ThemeUtil.nearest(ctx, p) > halfW + 20 then
			local r = rng:NextNumber()
			if r < 0.55 then
				Props.umbrella(world, p, palette[rng:NextInteger(1, #palette)], Color3.new(1, 1, 1))
			elseif r < 0.85 then
				for k = 0, 2 do
					Props.surfboard(world, p + Vector3.new(k * 2.4, 0, 0), Color3.fromHSV(rng:NextNumber(), 0.6, 1), rng:NextNumber(-0.2, 0.2))
				end
			else
				local m = Instance.new("Model")
				m.Name = "LifeguardTower"
				m.Parent = world
				for _, sx in { -2, 2 } do
					for _, sz in { -2, 2 } do
						Style.part({ name = "Leg", size = Vector3.new(0.6, 9, 0.6), cframe = CFrame.new(p + Vector3.new(sx, 4.5, sz)), color = Color3.new(1, 1, 1), material = Enum.Material.Wood, parent = m })
					end
				end
				Style.part({ name = "Hut", size = Vector3.new(6, 5, 6), cframe = CFrame.new(p + Vector3.new(0, 11.5, 0)), color = Color3.fromRGB(240, 70, 60), material = Enum.Material.WoodPlanks, parent = m })
				Style.part({ name = "Roof", size = Vector3.new(7.5, 0.6, 7.5), cframe = CFrame.new(p + Vector3.new(0, 14.3, 0)), color = Color3.new(1, 1, 1), material = Enum.Material.WoodPlanks, parent = m })
				Props.flag(m, p + Vector3.new(0, 14.6, 0), Color3.fromRGB(255, 220, 60), 6)
			end
		end
		x += rng:NextNumber(35, 60)
	end

	-- ── Lighthouse on the cliff + boats at sea ─────────────────────────
	local cliffI = 1
	for i = 1, n do
		if ctx.kindAt(i) == "cliff" then
			cliffI = i
			if samples[i].position.X > origin.X + 1120 then
				break
			end
		end
	end
	do
		local p = ThemeUtil.beside(ctx, cliffI, 1, halfW + 60)
		local base = Vector3.new(p.X, samples[cliffI].position.Y - 3, p.Z)
		Workspace.Terrain:FillBall(base - Vector3.new(0, 14, 0), 28, Enum.Material.Rock)
		local m = Instance.new("Model")
		m.Name = "Lighthouse"
		m.Parent = world
		for k = 0, 7 do
			Style.part({ name = "Stripe", size = Vector3.new(7, 10 - k * 0.3, 10 - k * 0.3), cframe = CFrame.new(base + Vector3.new(0, 3.5 + k * 7, 0)) * CFrame.Angles(0, 0, math.rad(90)), color = if k % 2 == 0 then Color3.fromRGB(240, 60, 60) else Color3.new(1, 1, 1), material = Enum.Material.SmoothPlastic, shape = Enum.PartType.Cylinder, parent = m })
		end
		local lamp = Style.neon("Lamp", Vector3.new(5, 5, 5), CFrame.new(base + Vector3.new(0, 60, 0)), Color3.fromRGB(255, 240, 180), m)
		;(lamp :: Part).Shape = Enum.PartType.Ball
		Style.part({ name = "Cap", size = Vector3.new(3, 8, 8), cframe = CFrame.new(base + Vector3.new(0, 64, 0)) * CFrame.Angles(0, 0, math.rad(90)), color = Color3.fromRGB(40, 40, 50), material = Enum.Material.Metal, shape = Enum.PartType.Cylinder, parent = m })
		local beam = Instance.new("SpotLight")
		beam.Range = 120
		beam.Brightness = 4
		beam.Angle = 25
		beam.Color = Color3.fromRGB(255, 240, 180)
		beam.Parent = lamp
	end
	for _ = 1, 10 do
		local north = rng:NextNumber() < 0.6
		local p = if north then Vector3.new(rng:NextNumber(landMinX, landMaxX + 400), seaY + 0.2, landMaxZ + rng:NextNumber(120, 600)) else Vector3.new(landMaxX + rng:NextNumber(260, 700), seaY + 0.2, rng:NextNumber(landMinZ, landMaxZ))
		Props.boat(world, CFrame.new(p) * CFrame.Angles(0, rng:NextNumber(0, math.pi * 2), 0), Color3.fromHSV(rng:NextNumber(), 0.5, 0.95), rng:NextNumber() < 0.5)
	end
	-- inland: flower beds + round trees
	for _ = 1, 40 do
		local p = Vector3.new(rng:NextNumber(landMinX + 40, landMaxX - 40), landTop + 0.2, rng:NextNumber(landMinZ + 40, landMaxZ - 120))
		if ThemeUtil.nearest(ctx, p) > halfW + 30 and not ThemeUtil.isReserved(ctx, p, 10) then
			if rng:NextNumber() < 0.6 then
				Props.roundTree(world, p, rng:NextNumber(16, 26), Color3.fromRGB(70, 170, 70), rng)
			else
				Props.flowerBed(world, CFrame.new(p), Vector2.new(12, 6), { palette[1], palette[3], palette[4], Color3.new(1, 1, 1) }, rng)
			end
		end
	end
end

return Beach
