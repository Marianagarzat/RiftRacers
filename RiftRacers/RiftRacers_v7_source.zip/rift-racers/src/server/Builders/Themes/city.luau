--!strict
-- CYBERPULSE CITY world: glass towers with lit window grids, brick shop
-- fronts with awnings and neon signs, holo billboards, street lamps, steam
-- vents, tunnel light rings, skybridge pillars and a megatower skyline.

local CollectionService = game:GetService("CollectionService")
local Style = require(script.Parent.Parent.Style)
local Props = require(script.Parent.Parent.Props)
local ThemeUtil = require(script.Parent.ThemeUtil)

local City = {}

local ADS = { "RIFT RACERS", "SYNTHWAVE FM", "KAIJU NOODLES", "NIGHT MARKET", "AERO-9", "NEON//PULSE", "DRIVE THE FUTURE", "ZERO-G CLUB", "PIXEL TEA", "OVERCLOCK", "GRID 2099", "HYPERLANE" }
local SHOPS = { "RAMEN", "ARCADE", "TACOS", "BOBA", "PIZZA", "MODS", "TUNING", "DONUTS", "SUSHI", "CAFÉ", "PARTS", "VINYL" }

local function windowGrid(part: BasePart, face: Enum.NormalId, cols: number, rows: number, lit: Color3, rng: Random)
	local gui = Instance.new("SurfaceGui")
	gui.Face = face
	gui.LightInfluence = 0
	gui.Brightness = 1.4
	gui.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	gui.PixelsPerStud = 4
	gui.Parent = part
	local grid = Instance.new("UIGridLayout")
	grid.CellSize = UDim2.new(1 / cols, -6, 1 / rows, -8)
	grid.CellPadding = UDim2.fromOffset(6, 8)
	grid.Parent = gui
	local pad = Instance.new("UIPadding")
	pad.PaddingLeft = UDim.new(0, 4)
	pad.PaddingTop = UDim.new(0, 6)
	pad.Parent = gui
	for _ = 1, cols * rows do
		local f = Instance.new("Frame")
		f.BorderSizePixel = 0
		local on = rng:NextNumber() < 0.45
		f.BackgroundColor3 = if on then lit:Lerp(Color3.fromRGB(255, 240, 200), rng:NextNumber() * 0.5) else Color3.fromRGB(20, 22, 40)
		f.BackgroundTransparency = if on then 0.05 else 0.3
		f.Parent = gui
	end
end

local function shop(parent: Instance, cf: CFrame, rng: Random, palette: { Color3 })
	local m = Instance.new("Model")
	m.Name = "Shop"
	m.Parent = parent
	local w, d, h = rng:NextNumber(26, 40), rng:NextNumber(20, 30), rng:NextNumber(18, 34)
	local brick = ({ Color3.fromRGB(150, 60, 70), Color3.fromRGB(60, 110, 130), Color3.fromRGB(170, 120, 60), Color3.fromRGB(90, 70, 140) })[rng:NextInteger(1, 4)]
	Style.part({ name = "Body", size = Vector3.new(w, h, d), cframe = cf * CFrame.new(0, h / 2 - 0.5, 0), color = brick, material = Enum.Material.Brick, parent = m })
	local front = cf * CFrame.new(0, 0, -d / 2 - 0.1)
	local glow = palette[rng:NextInteger(1, #palette)]
	Style.part({ name = "Storefront", size = Vector3.new(w - 6, 9, 0.3), cframe = front * CFrame.new(0, 5, 0), color = glow:Lerp(Color3.new(1, 1, 1), 0.5), material = Enum.Material.Glass, transparency = 0.15, reflectance = 0.2, collide = false, parent = m })
	Style.pointLight(Style.part({ name = "Inside", size = Vector3.new(1, 1, 1), cframe = front * CFrame.new(0, 5, 3), transparency = 1, collide = false, query = false, parent = m }), glow, 22, 1.2, true)
	for i = 0, 5 do
		Style.part({ name = "Awning", size = Vector3.new((w - 4) / 6, 0.3, 5), cframe = front * CFrame.new(-w / 2 + 2 + (w - 4) / 6 * (i + 0.5), 10.6, -2.2) * CFrame.Angles(math.rad(15), 0, 0), color = if i % 2 == 0 then glow else Color3.fromRGB(240, 240, 245), material = Enum.Material.Fabric, collide = false, query = false, parent = m })
	end
	local sign = Style.neon("Sign", Vector3.new(w * 0.6, 4, 0.4), front * CFrame.new(0, 14, -0.3), Color3.fromRGB(20, 20, 30), m)
	sign.Material = Enum.Material.SmoothPlastic
	local l = Style.sign(sign, Enum.NormalId.Front, SHOPS[rng:NextInteger(1, #SHOPS)], glow, 14, Enum.Font.Bangers)
	l.Parent = l.Parent
	if h > 22 then
		windowGrid(m:FindFirstChild("Body") :: BasePart, Enum.NormalId.Front, math.floor(w / 6), math.floor((h - 18) / 6), glow, rng)
	end
	for _ = 1, 2 do
		Style.part({ name = "ACUnit", size = Vector3.new(4, 2.4, 3), cframe = cf * CFrame.new(rng:NextNumber(-w / 3, w / 3), h + 0.7, rng:NextNumber(-d / 3, d / 3)), color = Color3.fromRGB(170, 170, 180), material = Enum.Material.DiamondPlate, parent = m })
	end
end

local function tower(parent: Instance, cf: CFrame, w: number, d: number, h: number, rng: Random, palette: { Color3 }, detailed: boolean)
	local m = Instance.new("Model")
	m.Name = "Tower"
	m.Parent = parent
	local hue = ({ Color3.fromRGB(30, 50, 90), Color3.fromRGB(60, 30, 90), Color3.fromRGB(20, 70, 80), Color3.fromRGB(80, 30, 60) })[rng:NextInteger(1, 4)]
	local body = Style.part({ name = "Body", size = Vector3.new(w, h, d), cframe = cf * CFrame.new(0, h / 2 - 1, 0), color = hue, material = Enum.Material.Glass, reflectance = 0.25, castShadow = detailed, parent = m })
	local accent = palette[rng:NextInteger(1, #palette)]
	if detailed then
		windowGrid(body, Enum.NormalId.Front, math.floor(w / 7), math.floor(h / 9), accent, rng)
		windowGrid(body, Enum.NormalId.Left, math.floor(d / 7), math.floor(h / 9), accent, rng)
		windowGrid(body, Enum.NormalId.Right, math.floor(d / 7), math.floor(h / 9), accent, rng)
		windowGrid(body, Enum.NormalId.Back, math.floor(w / 7), math.floor(h / 9), accent, rng)
	end
	-- corner pillars in concrete give the glass box structure
	for _, sx in { -1, 1 } do
		for _, sz in { -1, 1 } do
			Style.part({ name = "Pillar", size = Vector3.new(2, h, 2), cframe = cf * CFrame.new(sx * w / 2, h / 2 - 1, sz * d / 2), color = Color3.fromRGB(60, 60, 75), material = Enum.Material.Concrete, castShadow = false, parent = m })
		end
	end
	local bands = rng:NextInteger(1, 3)
	for k = 1, bands do
		Style.neon("Band", Vector3.new(w + 0.6, 0.8, d + 0.6), cf * CFrame.new(0, h * k / (bands + 1), 0), accent, m, 0.15)
	end
	-- stepped crown
	if rng:NextNumber() < 0.6 then
		local h2 = rng:NextNumber(15, 40)
		Style.part({ name = "Top", size = Vector3.new(w * 0.65, h2, d * 0.65), cframe = cf * CFrame.new(0, h + h2 / 2 - 1, 0), color = hue:Lerp(Color3.new(0, 0, 0), 0.2), material = Enum.Material.Glass, reflectance = 0.25, castShadow = false, parent = m })
		Style.neon("Crown", Vector3.new(w * 0.65 + 0.6, 1.2, d * 0.65 + 0.6), cf * CFrame.new(0, h + h2 - 1, 0), accent, m)
		h += h2
	else
		Style.neon("Crown", Vector3.new(w + 0.8, 1.4, d + 0.8), cf * CFrame.new(0, h - 1, 0), accent, m)
	end
	if rng:NextNumber() < 0.4 then
		Style.part({ name = "Antenna", size = Vector3.new(0.6, 30, 0.6), cframe = cf * CFrame.new(0, h + 15, 0), color = Color3.fromRGB(150, 150, 160), material = Enum.Material.Metal, castShadow = false, parent = m })
		local beacon = Style.neon("Beacon", Vector3.new(1.4, 1.4, 1.4), cf * CFrame.new(0, h + 30.5, 0), Color3.fromRGB(255, 40, 70), m)
		CollectionService:AddTag(beacon, "Blink")
	end
	return m
end

function City.build(ctx: any)
	local map = ctx.map
	local folder = ctx.folder :: Folder
	local rng = ctx.rng :: Random
	local palette = map.palette
	local halfW = ctx.halfW
	local samples = ctx.samples
	local n = #samples
	local origin = map.origin
	local cityF = Style.folder("City", folder)
	local decoF = folder:FindFirstChild("Decor") :: Folder

	local minX, maxX, minZ, maxZ = ThemeUtil.bounds(ctx)
	local pad = 520
	local cx, cz = (minX + maxX) / 2, (minZ + maxZ) / 2
	local sizeX, sizeZ = maxX - minX + pad * 2, maxZ - minZ + pad * 2
	Style.part({ name = "CityFloor", size = Vector3.new(sizeX, 2, sizeZ), cframe = CFrame.new(cx, origin.Y - 1.4, cz), color = Color3.fromRGB(34, 32, 46), material = Enum.Material.Pavement, parent = cityF })
	for gx = minX - pad + 100, maxX + pad - 100, 200 do
		Style.part({ name = "StreetLine", size = Vector3.new(0.6, 0.06, sizeZ), cframe = CFrame.new(gx, origin.Y - 0.37, cz), color = Color3.fromRGB(220, 200, 90), material = Enum.Material.SmoothPlastic, collide = false, query = false, castShadow = false, parent = cityF })
	end

	-- per-sample street furniture, tunnels, bridge pillars
	local ringIndex = 0
	for i = 1, n do
		local s = samples[i]
		local kind = ctx.kindAt(i)
		local cf = CFrame.lookAt(s.position, s.position + s.tangent)
		if (kind == "tunnel" or kind == "underground") and i % 3 == 0 then
			ringIndex += 1
			local ring = Instance.new("Model")
			ring.Name = "TunnelRing"
			local col = if kind == "underground" then Color3.fromRGB(255, 110, 40) else palette[(ringIndex % 2) + 1]
			for _, side in { -1, 1 } do
				Style.neon("Post", Vector3.new(0.6, 24, 0.6), cf * CFrame.new(side * (halfW - 0.4), 11, 0), col, ring)
			end
			local top = Style.neon("Top", Vector3.new(halfW * 2, 0.6, 0.6), cf * CFrame.new(0, 23, 0), col, ring)
			if ringIndex % 2 == 0 then
				Style.pointLight(top, col, 32, 1.6, true)
			end
			ring:SetAttribute("Phase", ringIndex)
			ring:SetAttribute("Underground", kind == "underground")
			CollectionService:AddTag(ring, "TunnelRing")
			ring.Parent = decoF
			if ringIndex % 4 == 1 then
				for _, side in { -1, 1 } do
					local panel = Style.part({ name = "HoloAd", size = Vector3.new(0.2, 12, 26), cframe = cf * CFrame.new(side * (halfW - 0.15), 11, 0), color = Color3.new(0, 0, 0), collide = false, query = false, parent = decoF })
					local label = Style.sign(panel, if side > 0 then Enum.NormalId.Left else Enum.NormalId.Right, ADS[rng:NextInteger(1, #ADS)], Color3.new(1, 1, 1), 14, Enum.Font.Bangers)
					local g = Instance.new("UIGradient")
					g.Color = ColorSequence.new(palette[1], palette[2])
					g.Parent = label
					CollectionService:AddTag(g, "HoloGradient")
				end
			end
		end
		if kind == "bridge" and i % 6 == 0 and s.position.Y > origin.Y + 6 then
			local h = s.position.Y - origin.Y - 2
			local base = Vector3.new(s.position.X, origin.Y - 0.4 + h / 2, s.position.Z)
			local pcf = CFrame.lookAt(base, base + Vector3.new(s.tangent.X, 0, s.tangent.Z))
			for _, side in { -1, 1 } do
				Style.part({ name = "Pillar", size = Vector3.new(5, h, 5), cframe = pcf * CFrame.new(side * (halfW - 6), 0, 0), color = Color3.fromRGB(80, 78, 95), material = Enum.Material.Concrete, parent = decoF })
				Style.neon("PillarLight", Vector3.new(0.3, h - 4, 0.3), pcf * CFrame.new(side * (halfW - 6), 0, -2.6), palette[3], decoF, 0.2)
			end
			Style.part({ name = "Crossbeam", size = Vector3.new(halfW * 2 - 4, 3, 4), cframe = cf * CFrame.new(0, -3.5, 0), color = Color3.fromRGB(80, 78, 95), material = Enum.Material.Concrete, parent = decoF })
		end
		if kind == "street" and i % 9 == 0 then
			local side = if (i // 9) % 2 == 0 then 1 else -1
			local lamp = Instance.new("Model")
			lamp.Name = "StreetLamp"
			lamp.Parent = decoF
			local base = cf * CFrame.new(side * (halfW + 4.5), 0, 0)
			Style.part({ name = "Pole", size = Vector3.new(0.9, 22, 0.9), cframe = base * CFrame.new(0, 10, 0), color = Color3.fromRGB(80, 80, 95), material = Enum.Material.Metal, parent = lamp })
			Style.part({ name = "Arm", size = Vector3.new(9, 0.6, 0.6), cframe = base * CFrame.new(-side * 4.3, 20.7, 0), color = Color3.fromRGB(80, 80, 95), material = Enum.Material.Metal, parent = lamp })
			local col = palette[((i // 9) % 3) + 1]
			local head = Style.neon("Head", Vector3.new(4, 0.35, 1.4), base * CFrame.new(-side * 8.2, 20.3, 0), col, lamp)
			Style.pointLight(head, col, 46, 1.6, true)
		end
		if kind == "street" and i % 23 == 5 then
			local side = if i % 2 == 0 then 1 else -1
			local vent = Style.part({ name = "SteamVent", size = Vector3.new(4, 0.1, 4), cframe = cf * CFrame.new(side * (halfW + 8), 0.5, 0), color = Color3.fromRGB(40, 40, 50), material = Enum.Material.DiamondPlate, collide = false, query = false, parent = decoF })
			local e = Instance.new("ParticleEmitter")
			e.Texture = "rbxasset://textures/particles/smoke_main.dds"
			e.Color = ColorSequence.new(Color3.fromRGB(220, 200, 255))
			e.LightEmission = 0.15
			e.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 2), NumberSequenceKeypoint.new(1, 9) })
			e.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.7), NumberSequenceKeypoint.new(1, 1) })
			e.Lifetime = NumberRange.new(2, 3.5)
			e.Speed = NumberRange.new(6, 10)
			e.Rate = 6
			e.Rotation = NumberRange.new(0, 360)
			e.Parent = vent
			CollectionService:AddTag(e, "DecorFX")
		end
		if kind == "street" and i % 17 == 8 then
			local side = if i % 2 == 0 then -1 else 1
			local p = (cf * CFrame.new(side * (halfW + 12), 0, 0)).Position
			Props.banner(decoF, CFrame.lookAt(p, p - cf.RightVector * side), 16, ADS[rng:NextInteger(1, #ADS)], palette[rng:NextInteger(1, #palette)], Color3.new(1, 1, 1), Enum.Font.Bangers)
		end
	end

	-- buildings
	local STEP = 120
	for gx = minX - pad + 60, maxX + pad - 60, STEP do
		for gz = minZ - pad + 60, maxZ + pad - 60, STEP do
			local w = rng:NextNumber(38, 76)
			local d = rng:NextNumber(38, 76)
			local p = Vector3.new(gx + rng:NextNumber(-14, 14), origin.Y, gz + rng:NextNumber(-14, 14))
			local dist, si = ThemeUtil.nearest(ctx, p)
			local clearance = halfW + math.sqrt(w * w + d * d) / 2 + 26
			if dist < clearance or ThemeUtil.isReserved(ctx, p, w / 2) then
				continue
			end
			local target = samples[si].position
			local facing = CFrame.lookAt(p, Vector3.new(target.X, p.Y, target.Z))
			local nearTrack = dist < clearance + 110
			if nearTrack and rng:NextNumber() < 0.45 then
				shop(cityF, facing, rng, palette)
			else
				local h = if nearTrack then rng:NextNumber(70, 240) else rng:NextNumber(110, 420)
				local t = tower(cityF, facing, w, d, h, rng, palette, nearTrack)
				if nearTrack and rng:NextNumber() < 0.45 then
					local bw = rng:NextNumber(26, 40)
					local bh = bw * 0.55
					local y = math.clamp(rng:NextNumber(24, h - bh), 24, math.max(24, h - bh / 2 - 4))
					local facePos = (facing * CFrame.new(0, y, -d / 2 - 1.5)).Position
					local board = Style.part({ name = "HoloBoard", size = Vector3.new(bw, bh, 0.4), cframe = CFrame.lookAt(facePos, facePos + facing.LookVector), color = Color3.new(0, 0, 0), transparency = 0.15, collide = false, query = false, castShadow = false, parent = t })
					local label = Style.sign(board, Enum.NormalId.Front, ADS[rng:NextInteger(1, #ADS)], Color3.new(1, 1, 1), 10, Enum.Font.Bangers)
					local g = Instance.new("UIGradient")
					g.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, palette[1]), ColorSequenceKeypoint.new(0.5, palette[2]), ColorSequenceKeypoint.new(1, palette[3]) })
					g.Parent = label
					CollectionService:AddTag(g, "HoloGradient")
					Style.neon("BoardFrame", Vector3.new(bw + 1, bh + 1, 0.2), board.CFrame * CFrame.new(0, 0, 0.35), palette[rng:NextInteger(1, #palette)], t)
				end
			end
		end
	end

	-- skyline
	for i = 0, 35 do
		local a = i / 36 * math.pi * 2
		local r = math.max(sizeX, sizeZ) / 2 + rng:NextNumber(250, 600)
		local h = rng:NextNumber(400, 900)
		local w = rng:NextNumber(90, 180)
		local cf = CFrame.new(cx + math.cos(a) * r, origin.Y + h / 2 - 2, cz + math.sin(a) * r)
		Style.part({ name = "MegaTower", size = Vector3.new(w, h, w), cframe = cf, color = Color3.fromRGB(26, 22, 48), material = Enum.Material.Glass, reflectance = 0.2, castShadow = false, parent = cityF })
		for k = 1, 3 do
			Style.neon("MegaBand", Vector3.new(w + 1, 2, w + 1), cf * CFrame.new(0, -h / 2 + h * k / 4, 0), palette[((i + k) % #palette) + 1], cityF, 0.2)
		end
	end
end

return City
