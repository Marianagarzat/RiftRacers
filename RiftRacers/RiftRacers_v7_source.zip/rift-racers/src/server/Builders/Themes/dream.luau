--!strict
-- KAWAII DREAMLAND world: sky roads above a sea of pastel clouds, floating
-- islands with mushrooms, lollipops and candy canes on the shoulders,
-- rainbow arches over the skybridge, floating hearts and twinkling stars,
-- and the Heart Palace gate the race passes beneath before the finish.

local Style = require(script.Parent.Parent.Style)
local Props = require(script.Parent.Parent.Props)
local ThemeUtil = require(script.Parent.ThemeUtil)

local Dream = {}

local RAINBOW = {
	Color3.fromRGB(255, 90, 110),
	Color3.fromRGB(255, 160, 70),
	Color3.fromRGB(255, 225, 90),
	Color3.fromRGB(120, 220, 120),
	Color3.fromRGB(90, 190, 255),
	Color3.fromRGB(140, 120, 255),
	Color3.fromRGB(220, 120, 255),
}

local function arch(parent: Instance, cf: CFrame, radius: number)
	local m = Instance.new("Model")
	m.Name = "RainbowArch"
	m.Parent = parent
	for band, col in RAINBOW do
		local r = radius + (band - 1) * 1.6
		local segs = 18
		for k = 0, segs - 1 do
			local a0 = k / segs * math.pi
			local a1 = (k + 1) / segs * math.pi
			local p0 = Vector3.new(math.cos(a0) * r, math.sin(a0) * r, 0)
			local p1 = Vector3.new(math.cos(a1) * r, math.sin(a1) * r, 0)
			local mid = (p0 + p1) / 2
			local len = (p1 - p0).Magnitude + 0.3
			local local_ = CFrame.lookAt(mid, p1)
			Style.part({ name = "Band", size = Vector3.new(1.6, 1.6, len), cframe = cf * local_, color = col, material = Enum.Material.SmoothPlastic, collide = false, query = false, castShadow = false, parent = m })
		end
	end
end

local function giantFlower(parent: Instance, base: Vector3, height: number, petal: Color3)
	local m = Instance.new("Model")
	m.Name = "GiantFlower"
	m.Parent = parent
	Style.part({ name = "Stem", size = Vector3.new(height, 1.4, 1.4), cframe = CFrame.new(base + Vector3.new(0, height / 2, 0)) * CFrame.Angles(0, 0, math.rad(90)), color = Color3.fromRGB(120, 210, 130), shape = Enum.PartType.Cylinder, collide = false, query = false, parent = m })
	local head = CFrame.new(base + Vector3.new(0, height, 0)) * CFrame.Angles(math.rad(70), 0, 0)
	for k = 0, 7 do
		local a = k / 8 * math.pi * 2
		Style.part({ name = "Petal", size = Vector3.new(4, 1, 4), cframe = head * CFrame.new(math.cos(a) * 3.6, 0, math.sin(a) * 3.6), color = petal, shape = Enum.PartType.Ball, collide = false, query = false, parent = m })
	end
	Style.part({ name = "Center", size = Vector3.new(4, 2, 4), cframe = head * CFrame.new(0, 0.6, 0), color = Color3.fromRGB(255, 220, 90), shape = Enum.PartType.Ball, collide = false, query = false, parent = m })
end

function Dream.build(ctx: any)
	local map = ctx.map
	local folder = ctx.folder :: Folder
	local rng = ctx.rng :: Random
	local palette = map.palette
	local halfW = ctx.halfW :: number
	local samples = ctx.samples
	local n = #samples
	local origin = map.origin :: Vector3
	local world = Style.folder("Sky", folder)

	local minX, maxX, minZ, maxZ = ThemeUtil.bounds(ctx)
	local cx, cz = (minX + maxX) / 2, (minZ + maxZ) / 2

	-- cloud sea below
	for gx = minX - 600, maxX + 600, 170 do
		for gz = minZ - 600, maxZ + 600, 170 do
			local p = Vector3.new(gx + rng:NextNumber(-50, 50), origin.Y - 90 - rng:NextNumber(0, 40), gz + rng:NextNumber(-50, 50))
			local tint = Color3.new(1, 1, 1):Lerp(palette[rng:NextInteger(1, #palette)], rng:NextNumber(0, 0.25))
			Props.cloud(world, p, rng:NextNumber(60, 110), tint, rng)
		end
	end
	-- puffy clouds drifting near the road (below road level)
	for i = 1, n, 11 do
		local side = if (i // 11) % 2 == 0 then 1 else -1
		local p = ThemeUtil.beside(ctx, i, side, halfW + rng:NextNumber(40, 90))
		Props.cloud(world, p - Vector3.new(0, rng:NextNumber(14, 40), 0), rng:NextNumber(20, 36), Color3.new(1, 1, 1):Lerp(palette[rng:NextInteger(1, #palette)], 0.2), rng)
	end

	-- floating islands
	for _ = 1, 16 do
		local p = Vector3.new(rng:NextNumber(minX - 250, maxX + 250), origin.Y + rng:NextNumber(-30, 70), rng:NextNumber(minZ - 250, maxZ + 250))
		if ThemeUtil.nearest(ctx, p) > halfW + 90 then
			local island = Props.floatingIsland(world, p, rng:NextNumber(22, 40), Color3.fromRGB(150, 230, 160):Lerp(palette[rng:NextInteger(1, #palette)], 0.25), rng)
			island:SetAttribute("Base", p)
			game:GetService("CollectionService"):AddTag(island, "Bob")
		end
	end

	-- shoulder decor + arches
	for i = 1, n do
		local kind = ctx.kindAt(i)
		if i % 7 == 0 then
			local side = if (i // 7) % 2 == 0 then 1 else -1
			local p = ThemeUtil.beside(ctx, i, side, halfW + 7)
			local base = p + Vector3.new(0, -0.1, 0)
			local r = rng:NextNumber()
			if r < 0.3 then
				Props.lollipop(world, base, rng:NextNumber(12, 20), palette[rng:NextInteger(1, #palette)], Color3.new(1, 1, 1))
			elseif r < 0.55 then
				Props.candyCane(world, base, rng:NextNumber(12, 18))
			elseif r < 0.8 then
				giantFlower(world, base, rng:NextNumber(10, 16), palette[rng:NextInteger(1, #palette)])
			else
				Props.mushroom(world, base, rng:NextNumber(2.5, 4), palette[rng:NextInteger(1, #palette)])
			end
		end
		if kind == "rainbow" and i % 12 == 0 then
			local s = samples[i]
			local cf = CFrame.lookAt(s.position, s.position + s.tangent) * CFrame.Angles(0, math.rad(90), 0)
			arch(world, cf, halfW + 4)
		end
		if i % 9 == 4 then
			local side = if i % 2 == 0 then 1 else -1
			local p = ThemeUtil.beside(ctx, i, side, halfW + rng:NextNumber(20, 60))
			local spot = p + Vector3.new(0, rng:NextNumber(14, 50), 0)
			if rng:NextNumber() < 0.5 then
				local h = Props.heart(world, CFrame.new(spot) * CFrame.Angles(0, rng:NextNumber(0, math.pi), 0), rng:NextNumber(5, 9), palette[1], rng:NextNumber() < 0.3)
				h:SetAttribute("Base", spot)
				game:GetService("CollectionService"):AddTag(h, "Bob")
			else
				Props.sparkle(world, spot, rng:NextNumber(3, 6), ({ Color3.fromRGB(255, 240, 150), Color3.fromRGB(255, 200, 240), Color3.fromRGB(190, 230, 255) })[rng:NextInteger(1, 3)])
			end
		end
	end

	-- Heart Palace gate spanning the road ~10 samples before the line
	do
		local gi = ((n - 10 - 1) % n) + 1
		local s = samples[gi]
		local cf = CFrame.lookAt(s.position, s.position + s.tangent)
		local m = Instance.new("Model")
		m.Name = "HeartPalace"
		m.Parent = world
		local wall = Color3.fromRGB(255, 225, 240)
		local roof = Color3.fromRGB(255, 120, 180)
		for _, side in { -1, 1 } do
			local base = (cf * CFrame.new(side * (halfW + 14), -4, 0)).Position
			Style.part({ name = "Plinth", size = Vector3.new(26, 4, 26), cframe = CFrame.new(base + Vector3.new(0, -2, 0)), color = Color3.fromRGB(240, 210, 235), parent = m })
			Props.castleTower(m, base, 46, 9, wall, roof)
			Props.castleTower(m, (cf * CFrame.new(side * (halfW + 40), -4, 22)).Position, 34, 7, wall, palette[3])
		end
		-- gate bridge over the road
		Style.part({ name = "GateBridge", size = Vector3.new(halfW * 2 + 30, 10, 12), cframe = cf * CFrame.new(0, 38, 0), color = wall, parent = m })
		for k = -6, 6 do
			Style.part({ name = "Crenel", size = Vector3.new(3, 3, 12), cframe = cf * CFrame.new(k * 5, 44.5, 0), color = wall, parent = m })
		end
		Style.part({ name = "GateTrim", size = Vector3.new(halfW * 2 + 30.4, 1.2, 12.4), cframe = cf * CFrame.new(0, 33.4, 0), color = roof, parent = m })
		local heart = Props.heart(m, cf * CFrame.new(0, 54, 0), 16, Color3.fromRGB(255, 80, 150), true)
		heart.Name = "PalaceHeart"
		local banner = Style.part({ name = "PalaceSign", size = Vector3.new(36, 6, 0.4), cframe = cf * CFrame.new(0, 38, 6.3), color = Color3.new(0, 0, 0), transparency = 1, collide = false, query = false, parent = m })
		local l = Style.sign(banner, Enum.NormalId.Back, "HEART PALACE", Color3.fromRGB(255, 100, 170), 14, Enum.Font.FredokaOne)
		local st = l:FindFirstChildOfClass("UIStroke")
		if st then
			st.Color = Color3.new(1, 1, 1)
			st.Thickness = 4
			st.Transparency = 0
		end
	end

	-- distant pastel castle silhouette + giant moonlike sun puffs
	for k = 0, 7 do
		local a = k / 8 * math.pi * 2
		local p = Vector3.new(cx + math.cos(a) * 1500, origin.Y - 60, cz + math.sin(a) * 1500)
		Props.castleTower(world, p, rng:NextNumber(120, 220), rng:NextNumber(18, 30), Color3.fromRGB(255, 235, 250), palette[(k % #palette) + 1])
	end
end

return Dream
