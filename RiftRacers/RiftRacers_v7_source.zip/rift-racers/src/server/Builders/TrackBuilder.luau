--!strict
-- Generates a complete circuit from a MapDefinition: road surface per
-- section type, kerbs on every corner, themed barriers, chevrons, tyre
-- walls, boost pads, checkpoint gates, start grid, finish gantry with start
-- lights, crowded grandstands — then hands off to the map's theme module
-- (city / beach / dream) for the surrounding world.
--
-- Deterministic (seeded): every server builds the same map.

local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Config = require(ReplicatedStorage.Shared.Config)
local Spline = require(ReplicatedStorage.Shared.Util.Spline)
local MapDefinitions = require(ReplicatedStorage.Shared.MapDefinitions)
local Style = require(script.Parent.Style)
local Props = require(script.Parent.Props)
local Themes = script.Parent.Themes

type Sample = Spline.Sample
type MapDefinition = MapDefinitions.MapDefinition

export type Checkpoint = {
	index: number, -- 0 = start/finish
	cframe: CFrame, -- at road centre, LookVector = direction of travel
	halfWidth: number,
	section: string,
	sampleIndex: number,
}

export type TrackData = {
	map: MapDefinition,
	folder: Folder,
	samples: { Sample },
	total: number,
	width: number,
	checkpoints: { Checkpoint }, -- array, checkpoints[1].index == 0
	grid: { CFrame },
	sectionOf: (sampleIndex: number) -> string,
}

-- Context passed to theme modules
export type BuildContext = {
	map: MapDefinition,
	folder: Folder,
	samples: { Sample },
	total: number,
	halfW: number,
	rng: Random,
	kindAt: (i: number) -> string,
	curvature: { number }, -- signed turn rate per sample (rad/stud, + = left)
	isCheckpointNear: (i: number, range: number) -> boolean,
	reserved: { { pos: Vector3, radius: number } }, -- keep scenery out of these
}

local TrackBuilder = {}

local WHITE = Color3.fromRGB(245, 245, 245)
local CONCRETE = Color3.fromRGB(205, 205, 210)
local METAL = Color3.fromRGB(150, 155, 165)

local RAINBOW = {
	Color3.fromRGB(255, 90, 110),
	Color3.fromRGB(255, 160, 70),
	Color3.fromRGB(255, 225, 90),
	Color3.fromRGB(120, 220, 120),
	Color3.fromRGB(90, 190, 255),
	Color3.fromRGB(140, 120, 255),
	Color3.fromRGB(220, 120, 255),
}
TrackBuilder.RAINBOW = RAINBOW

local function sectionFor(map: MapDefinition, segment: number): MapDefinitions.Section
	for _, s in map.sections do
		if segment >= s.from and segment < s.to then
			return s
		end
	end
	return map.sections[1]
end

local function flatAngle(a: Vector3, b: Vector3): number
	return math.acos(math.clamp(a:Dot(b), -1, 1))
end

function TrackBuilder.build(map: MapDefinition, parent: Instance): TrackData
	local folder = Style.folder(map.id, parent)
	local origin = map.origin
	local W = map.roadWidth
	local halfW = W / 2

	local pts: { Vector3 } = {}
	for i, p in map.controlPoints do
		pts[i] = p + origin
	end
	local samples, total = Spline.sampleClosed(pts, map.sampleSpacing)
	local n = #samples
	local rng = Random.new(2099 + #map.id)
	local palette = map.palette
	local dream = map.theme == "dream"

	local function wrap(i: number): number
		return ((i - 1) % n) + 1
	end
	local function kindAt(i: number): string
		return sectionFor(map, samples[wrap(i)].segment).kind
	end
	local function pos(i: number): Vector3
		return samples[wrap(i)].position
	end

	-- signed curvature per sample
	local curvature: { number } = {}
	for i = 1, n do
		local a = samples[wrap(i - 1)].tangent
		local b = samples[wrap(i + 1)].tangent
		local fa = Vector3.new(a.X, 0, a.Z).Unit
		local fb = Vector3.new(b.X, 0, b.Z).Unit
		local ang = flatAngle(fa, fb)
		local sign = if fa:Cross(fb).Y > 0 then 1 else -1
		curvature[i] = sign * ang / (2 * map.sampleSpacing)
	end

	local cpIdx: { number } = {}
	for k = 0, map.checkpointCount - 1 do
		table.insert(cpIdx, math.floor(k * n / map.checkpointCount) + 1)
	end
	local function isCheckpointNear(i: number, range: number): boolean
		for _, c in cpIdx do
			local d = math.abs(i - c)
			d = math.min(d, n - d)
			if d <= range then
				return true
			end
		end
		return false
	end

	local roadF = Style.folder("Road", folder)
	local wallF = Style.folder("Barriers", folder)
	local decoF = Style.folder("Decor", folder)
	local cpF = Style.folder("Checkpoints", folder)

	-- ── 1. Group samples into straight-ish runs ─────────────────────────
	type Run = { a: number, b: number, kind: string }
	local runs: { Run } = {}
	do
		local i = 1
		while i <= n do
			local kind = kindAt(i)
			local startDir = (pos(i + 1) - pos(i)).Unit
			local j = i + 1
			while j <= n do
				local dir = (pos(j + 1) - pos(j)).Unit
				if flatAngle(startDir, dir) > math.rad(0.6) or kindAt(j) ~= kind or (j - i) * map.sampleSpacing > 300 then
					break
				end
				j += 1
			end
			table.insert(runs, { a = i, b = j - 1, kind = kind })
			i = j
		end
	end

	-- ── 2. Road surface, lines, barriers per run ────────────────────────
	for r, run in runs do
		local a = pos(run.a)
		local b = pos(run.b + 1)
		local dir = b - a
		local len = dir.Magnitude
		if len < 0.1 then
			continue
		end
		local nextRun = runs[(r % #runs) + 1]
		local nextDir = (pos(nextRun.b + 1) - pos(nextRun.a)).Unit
		local turn = flatAngle(dir.Unit, nextDir)
		local overlap = halfW * math.tan(math.min(turn, 1.2) / 2) * 2 + 0.6
		local cf = CFrame.lookAt((a + b) / 2, b)
		local L = len + overlap
		local kind = run.kind

		-- surface
		local thick = if dream then 4 elseif map.theme == "beach" then 6 else 2
		local surfaceColor = map.roadColor
		local surfaceMat = map.roadMaterial
		if kind == "boardwalk" then
			surfaceColor, surfaceMat = Color3.fromRGB(176, 128, 84), Enum.Material.WoodPlanks
		elseif kind == "rainbow" then
			surfaceColor, surfaceMat = WHITE, Enum.Material.SmoothPlastic
		end
		local road = Style.part({ name = "Road", size = Vector3.new(W, thick, L), cframe = cf * CFrame.new(0, -thick / 2, 0), color = surfaceColor, material = surfaceMat, reflectance = if map.theme == "city" then 0.1 else 0, parent = roadF })
		if dream then
			Style.part({ name = "Underside", size = Vector3.new(W + 2, 1.5, L), cframe = cf * CFrame.new(0, -thick - 0.6, 0), color = palette[(r % #palette) + 1], material = Enum.Material.SmoothPlastic, collide = false, query = false, parent = roadF })
		end
		local _ = road
		if kind == "rainbow" then
			local stripeW = (W - 4) / #RAINBOW
			for s, col in RAINBOW do
				Style.part({ name = "Stripe", size = Vector3.new(stripeW, 0.05, L), cframe = cf * CFrame.new(-halfW + 2 + stripeW * (s - 0.5), 0.03, 0), color = col, material = Enum.Material.SmoothPlastic, collide = false, query = false, castShadow = false, parent = roadF })
			end
		end

		-- edge lines
		local lineColor = if map.theme == "city" then palette[2] else WHITE
		local lineMat = if map.theme == "city" then Enum.Material.Neon else Enum.Material.SmoothPlastic
		if kind ~= "rainbow" then
			for _, side in { -1, 1 } do
				Style.part({ name = "EdgeLine", size = Vector3.new(0.7, 0.06, L), cframe = cf * CFrame.new(side * (halfW - 2.4), 0.03, 0), color = lineColor, material = lineMat, collide = false, query = false, castShadow = false, parent = roadF })
			end
		end

		-- barriers
		local tall = kind == "tunnel" or kind == "underground"
		for _, side in { -1, 1 } do
			local lat = side * (halfW + 1)
			if tall then
				Style.part({ name = "Wall", size = Vector3.new(2, 28, L), cframe = cf * CFrame.new(lat, 12.5, 0), color = Color3.fromRGB(40, 36, 58), material = Enum.Material.Concrete, parent = wallF })
				Style.neon("WallStripe", Vector3.new(0.2, 0.5, L), cf * CFrame.new(side * (halfW - 0.05), 2.5, 0), if kind == "underground" then Color3.fromRGB(255, 120, 40) else palette[(r % 2) + 1], wallF, 0.05)
			elseif kind == "bridge" or kind == "rainbow" then
				Style.part({ name = "GlassRail", size = Vector3.new(0.6, 5.5, L), cframe = cf * CFrame.new(side * (halfW + 0.6), 1.25, 0), color = if kind == "rainbow" then RAINBOW[(r % #RAINBOW) + 1] else Color3.fromRGB(140, 180, 255), material = Enum.Material.Glass, transparency = 0.5, castShadow = false, parent = wallF })
				Style.part({ name = "RailBase", size = Vector3.new(1.8, 1.4, L), cframe = cf * CFrame.new(side * (halfW + 0.8), -1.3, 0), color = if kind == "rainbow" then WHITE else METAL, material = Enum.Material.Metal, parent = wallF })
				Style.neon("RailTop", Vector3.new(0.6, 0.35, L), cf * CFrame.new(side * (halfW + 0.6), 4.15, 0), if kind == "rainbow" then RAINBOW[((r + 3) % #RAINBOW) + 1] else palette[1], wallF)
			elseif map.theme == "city" then
				Style.part({ name = "Wall", size = Vector3.new(2, 5.5, L), cframe = cf * CFrame.new(lat, 1.25, 0), color = Color3.fromRGB(60, 58, 78), material = Enum.Material.Concrete, parent = wallF })
				Style.neon("WallTop", Vector3.new(2.1, 0.35, L), cf * CFrame.new(lat, 4.15, 0), palette[if side < 0 then 1 else 3], wallF)
				-- sidewalk
				Style.part({ name = "Sidewalk", size = Vector3.new(14, 1.2, L), cframe = cf * CFrame.new(side * (halfW + 9), -0.2, 0), color = Color3.fromRGB(90, 88, 105), material = Enum.Material.Pavement, parent = wallF })
				Style.part({ name = "Curb", size = Vector3.new(0.8, 1.4, L), cframe = cf * CFrame.new(side * (halfW + 15.6), -0.1, 0), color = Color3.fromRGB(150, 150, 160), material = Enum.Material.Concrete, parent = wallF })
			elseif kind == "cliff" then
				Style.part({ name = "StoneWall", size = Vector3.new(2.4, 8, L), cframe = cf * CFrame.new(lat, -1, 0), color = Color3.fromRGB(196, 170, 130), material = Enum.Material.Sandstone, parent = wallF })
				Style.part({ name = "WallCap", size = Vector3.new(2.8, 0.6, L), cframe = cf * CFrame.new(lat, 3.2, 0), color = Color3.fromRGB(235, 225, 205), material = Enum.Material.Limestone, parent = wallF })
			elseif kind == "boardwalk" then
				Style.part({ name = "Collider", size = Vector3.new(1, 6, L), cframe = cf * CFrame.new(lat, 1.5, 0), transparency = 1, castShadow = false, parent = wallF })
				for _, y in { 1.4, 3.2 } do
					Style.part({ name = "Rail", size = Vector3.new(0.5, 0.5, L), cframe = cf * CFrame.new(lat, y, 0), color = Color3.fromRGB(150, 105, 65), material = Enum.Material.Wood, collide = false, query = false, parent = wallF })
				end
			elseif dream then
				Style.part({ name = "Collider", size = Vector3.new(1, 6, L), cframe = cf * CFrame.new(lat, 1.5, 0), transparency = 1, castShadow = false, parent = wallF })
				Style.part({ name = "CandyRail", size = Vector3.new(1.2, 1.2, L), cframe = cf * CFrame.new(lat, 3.6, 0), color = palette[(r % #palette) + 1], material = Enum.Material.SmoothPlastic, collide = false, query = false, parent = wallF })
				Style.part({ name = "Shoulder", size = Vector3.new(10, 3, L), cframe = cf * CFrame.new(side * (halfW + 6), -1.6, 0), color = Color3.fromRGB(255, 240, 248), material = Enum.Material.SmoothPlastic, query = false, parent = wallF })
			else
				-- beach street: white barrier with a bright colour cap + sponsor stripes
				Style.part({ name = "Barrier", size = Vector3.new(1.6, 8, L), cframe = cf * CFrame.new(lat, -1, 0), color = CONCRETE, material = Enum.Material.Concrete, parent = wallF })
				Style.part({ name = "Cap", size = Vector3.new(1.8, 0.7, L), cframe = cf * CFrame.new(lat, 3.3, 0), color = palette[(r % #palette) + 1], material = Enum.Material.Plastic, collide = false, query = false, parent = wallF })
				Style.part({ name = "Sidewalk", size = Vector3.new(10, 6, L), cframe = cf * CFrame.new(side * (halfW + 7), -2.8, 0), color = Color3.fromRGB(225, 215, 195), material = Enum.Material.Pavement, parent = wallF })
			end
		end
		if tall then
			Style.part({ name = "Roof", size = Vector3.new(W + 6, 2, L), cframe = cf * CFrame.new(0, 27.5, 0), color = Color3.fromRGB(40, 36, 58), material = Enum.Material.Concrete, parent = wallF })
		end
	end

	-- ── 3. Per-sample trackside details ─────────────────────────────────
	local kerbToggle = 0
	for i = 1, n do
		local s = samples[i]
		local cf = CFrame.lookAt(s.position, s.position + s.tangent)
		local kind = kindAt(i)
		local curv = curvature[i]
		local radius = if math.abs(curv) > 1e-5 then 1 / math.abs(curv) else math.huge

		-- dashed centre line
		if i % 4 == 0 and kind ~= "rainbow" then
			Style.part({ name = "Dash", size = Vector3.new(0.6, 0.06, 6), cframe = cf * CFrame.new(0, 0.035, 0), color = if map.theme == "city" then Color3.fromRGB(220, 220, 255) else WHITE, material = if map.theme == "city" then Enum.Material.Neon else Enum.Material.SmoothPlastic, transparency = if map.theme == "city" then 0.35 else 0.1, collide = false, query = false, castShadow = false, parent = roadF })
		end

		-- kerbs on every real corner (both edges, alternating colours)
		if radius < 420 then
			kerbToggle += 1
			local col = map.kerb[(kerbToggle % 2) + 1]
			for _, side in { -1, 1 } do
				Style.part({ name = "Kerb", size = Vector3.new(3.2, 0.3, map.sampleSpacing + 0.3), cframe = cf * CFrame.new(side * (halfW - 1.6), 0.12, 0), color = col, material = Enum.Material.SmoothPlastic, castShadow = false, parent = roadF })
			end
		end

		local outer = if curv > 0 then 1 else -1 -- turning left → outside is right (+X)
		-- chevrons + tyre walls on the outside of tight corners
		if radius < 260 and i % 3 == 0 and not (kind == "tunnel" or kind == "underground") then
			local p = (cf * CFrame.new(outer * (halfW + 3.2), 0, 0)).Position
			local face = CFrame.lookAt(p, p - s.tangent * 1 - cf.RightVector * outer * 0.8)
			Props.chevron(decoF, face, -(if curv > 0 then -1 else 1), if map.theme == "city" then Color3.fromRGB(20, 20, 30) else Color3.fromRGB(255, 220, 40), if map.theme == "city" then palette[1] else Color3.fromRGB(30, 30, 30))
		end
		if radius < 300 and i % 4 == 2 and map.theme ~= "dream" and not (kind == "tunnel" or kind == "underground" or kind == "bridge") then
			Props.tireStack(decoF, (cf * CFrame.new(outer * (halfW + 6), 0, 0)).Position, palette[(i % #palette) + 1])
		end
	end

	-- ── 4. Boost pads on straights ──────────────────────────────────────
	do
		local placed = 0
		local last = -1000
		for i = 20, n - 20 do
			if placed >= 5 then
				break
			end
			if i - last < 70 then
				continue
			end
			local straight = true
			for k = 0, 10 do
				if math.abs(curvature[wrap(i + k)]) > 1 / 900 then
					straight = false
					break
				end
			end
			if straight and not isCheckpointNear(i, 5) then
				local s = samples[i]
				local cf = CFrame.lookAt(s.position, s.position + s.tangent)
				local lateral = if placed % 2 == 0 then -halfW / 3 else halfW / 3
				local padCf = cf * CFrame.new(lateral, 0.08, 0)
				local pad = Style.part({ name = "BoostPad", size = Vector3.new(12, 0.16, 18), cframe = padCf, color = Color3.fromRGB(255, 200, 40), material = Enum.Material.SmoothPlastic, collide = false, castShadow = false, parent = decoF })
				pad:SetAttribute("BoostPad", true)
				CollectionService:AddTag(pad, "BoostPad")
				for k = 0, 2 do
					for _, sgn in { -1, 1 } do
						Style.neon("Arrow", Vector3.new(0.9, 0.05, 5.5), padCf * CFrame.new(sgn * 1.8, 0.1, 4 - k * 5) * CFrame.Angles(0, math.rad(sgn * 35), 0), Color3.fromRGB(255, 80, 30), pad)
					end
				end
				placed += 1
				last = i
			end
		end
	end

	-- ── 5. Checkpoints, finish gantry, start lights ─────────────────────
	local checkpoints: { Checkpoint } = {}
	for k, si in cpIdx do
		local idx = k - 1
		local s = samples[si]
		local cf = CFrame.lookAt(s.position, s.position + s.tangent)
		local sec = sectionFor(map, s.segment)
		table.insert(checkpoints, { index = idx, cframe = cf, halfWidth = halfW, section = sec.name, sampleIndex = si })

		local gate = Instance.new("Model")
		gate.Name = "Gate" .. idx
		gate:SetAttribute("CheckpointIndex", idx)
		gate:SetAttribute("Section", sec.name)
		gate:SetAttribute("GateCFrame", cf)
		local isFinish = idx == 0
		local tall = sec.kind == "tunnel" or sec.kind == "underground"
		local height = if isFinish then 30 elseif tall then 21 else 22
		local col = palette[(idx % #palette) + 1]
		for _, side in { -1, 1 } do
			-- solid themed post with a glowing strip (the strip is what highlights)
			Style.part({ name = "PostBody", size = Vector3.new(2.6, height, 2.6), cframe = cf * CFrame.new(side * (halfW + 0.5), height / 2, 0), color = if map.theme == "city" then Color3.fromRGB(30, 28, 44) else WHITE, material = if map.theme == "beach" then Enum.Material.Wood else Enum.Material.SmoothPlastic, parent = gate })
			local glow = Style.neon("Post", Vector3.new(0.6, height - 2, 2.8), cf * CFrame.new(side * (halfW - 0.9), height / 2, 0), if isFinish then Color3.fromRGB(255, 255, 255) else col, gate, 0.1)
			glow.Name = "Post"
		end
		local beam = Style.part({ name = "Beam", size = Vector3.new(W + 6, if isFinish then 6 else 3, 2), cframe = cf * CFrame.new(0, height, 0), color = if isFinish then Color3.fromRGB(20, 20, 26) else (if map.theme == "city" then Color3.fromRGB(30, 28, 44) else col), material = Enum.Material.SmoothPlastic, collide = false, query = false, parent = gate })
		local beamGlow = Style.neon("BeamGlow", Vector3.new(W + 6.2, 0.4, 2.2), cf * CFrame.new(0, height - (if isFinish then 3 else 1.6), 0), if isFinish then Color3.fromRGB(255, 255, 255) else col, gate)
		beamGlow.Name = "Post"
		if isFinish then
			-- checkered banner both faces
			for _, face in { Enum.NormalId.Back, Enum.NormalId.Front } do
				local gui = Instance.new("SurfaceGui")
				gui.Face = face
				gui.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
				gui.PixelsPerStud = 12
				gui.LightInfluence = 0.3
				gui.Parent = beam
				local grid = Instance.new("UIGridLayout")
				grid.CellSize = UDim2.fromScale(1 / 24, 1 / 3)
				grid.CellPadding = UDim2.new()
				grid.Parent = gui
				for c = 0, 71 do
					local f = Instance.new("Frame")
					f.BorderSizePixel = 0
					f.BackgroundColor3 = if ((c % 24) + (c // 24)) % 2 == 0 then WHITE else Color3.fromRGB(15, 15, 20)
					f.Parent = gui
				end
			end
			local title = Style.part({ name = "Title", size = Vector3.new(36, 6, 0.4), cframe = cf * CFrame.new(0, height + 6.5, 0.6), color = Color3.new(0, 0, 0), transparency = 1, collide = false, query = false, parent = gate })
			local t1 = Style.sign(title, Enum.NormalId.Back, "FINISH", Color3.fromRGB(255, 220, 60), 14, Enum.Font.LuckiestGuy)
			local t2 = Style.sign(title, Enum.NormalId.Front, map.displayName, palette[1], 14, Enum.Font.LuckiestGuy)
			for _, t in { t1, t2 } do
				local st = t:FindFirstChildOfClass("UIStroke")
				if st then
					st.Color = Color3.fromRGB(20, 20, 30)
					st.Thickness = 4
					st.Transparency = 0
				end
			end
			for L = 1, 5 do
				local housing = Style.part({ name = "LightBox", size = Vector3.new(3, 3, 1), cframe = cf * CFrame.new((L - 3) * 4.2, height - 7, 1.4), color = Color3.fromRGB(20, 20, 26), collide = false, query = false, parent = gate })
				local bulb = Style.neon("StartLight", Vector3.new(2.2, 2.2, 0.4), housing.CFrame * CFrame.new(0, 0, 0.5), Color3.fromRGB(60, 10, 14), gate)
				;(bulb :: Part).Shape = Enum.PartType.Cylinder
				bulb.Size = Vector3.new(0.4, 2.3, 2.3)
				bulb.CFrame = housing.CFrame * CFrame.new(0, 0, 0.55) * CFrame.Angles(0, math.rad(90), 0)
				bulb:SetAttribute("Order", L)
				CollectionService:AddTag(bulb, "StartLight")
			end
			local cells = 16
			local cw = W / cells
			for row = 0, 1 do
				for c = 0, cells - 1 do
					Style.part({ name = "Checker", size = Vector3.new(cw, 0.06, 3), cframe = cf * CFrame.new(-halfW + cw * (c + 0.5), 0.045, (row - 0.5) * 3), color = if (row + c) % 2 == 0 then WHITE else Color3.fromRGB(12, 12, 16), collide = false, query = false, castShadow = false, parent = gate })
				end
			end
		else
			local sign = Style.part({ name = "Banner", size = Vector3.new(W - 6, 2.4, 0.3), cframe = cf * CFrame.new(0, height - 3.6, 1.2), color = WHITE, material = Enum.Material.Fabric, collide = false, query = false, parent = gate })
			local l = Style.sign(sign, Enum.NormalId.Back, sec.name, Color3.fromRGB(30, 30, 40), 14, Enum.Font.LuckiestGuy)
			local st = l:FindFirstChildOfClass("UIStroke")
			if st then
				st.Transparency = 1
			end
			local g = l.Parent :: SurfaceGui
			g.Brightness = 1
			g.LightInfluence = 1
		end
		CollectionService:AddTag(gate, "CheckpointGate")
		gate.Parent = cpF
	end

	-- ── 6. Start grid ───────────────────────────────────────────────────
	local grid: { CFrame } = {}
	for k = 0, Config.Race.MaxPlayers - 1 do
		local row = k // 2
		local col = k % 2
		local p, t = Spline.atDistance(samples, total, total - (22 + row * 17))
		local base = CFrame.lookAt(p, p + t)
		local slot = base * CFrame.new(if col == 0 then -9 else 9, 0, if col == 1 then 4 else 0)
		table.insert(grid, slot * CFrame.new(0, 3.2, 0))
		Style.part({ name = "GridBox", size = Vector3.new(8, 0.06, 0.5), cframe = slot * CFrame.new(0, 0.04, -7.5), color = WHITE, collide = false, query = false, castShadow = false, parent = roadF })
		for _, sx in { -4, 4 } do
			Style.part({ name = "GridBox", size = Vector3.new(0.5, 0.06, 6), cframe = slot * CFrame.new(sx, 0.04, -4.5), color = WHITE, collide = false, query = false, castShadow = false, parent = roadF })
		end
		local numPart = Style.part({ name = "GridNumber", size = Vector3.new(4, 0.06, 4), cframe = slot * CFrame.new(0, 0.05, -10.5), color = Color3.new(0, 0, 0), transparency = 1, collide = false, query = false, parent = roadF })
		local gui = Instance.new("SurfaceGui")
		gui.Face = Enum.NormalId.Top
		gui.PixelsPerStud = 20
		gui.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
		gui.Parent = numPart
		local lbl = Instance.new("TextLabel")
		lbl.BackgroundTransparency = 1
		lbl.Size = UDim2.fromScale(1, 1)
		lbl.Text = tostring(k + 1)
		lbl.TextScaled = true
		lbl.TextColor3 = WHITE
		lbl.Rotation = 180
		lbl.FontFace = Font.fromEnum(Enum.Font.LuckiestGuy)
		lbl.Parent = gui
	end

	-- ── 7. Grandstands + crowd at the start and two other spots ────────
	local reserved: { { pos: Vector3, radius: number } } = {}
	local function standAt(i: number, side: number, length: number)
		local s = samples[wrap(i)]
		local right = s.tangent:Cross(Vector3.yAxis).Unit
		local p = s.position + right * side * (halfW + if map.theme == "city" then 18 else 12)
		local cf = CFrame.lookAt(p, p - right * side)
		if map.theme == "beach" then
			Style.part({ name = "StandFoundation", size = Vector3.new(length + 6, 8, 24), cframe = cf * CFrame.new(0, -4, 9), color = Color3.fromRGB(225, 215, 195), material = Enum.Material.Concrete, parent = decoF })
		end
		if dream then
			Style.part({ name = "StandDeck", size = Vector3.new(length + 10, 3, 26), cframe = cf * CFrame.new(0, -1.5, 9), color = Color3.fromRGB(255, 240, 248), parent = decoF })
		end
		table.insert(reserved, { pos = (cf * CFrame.new(0, 0, 10)).Position, radius = length / 2 + 30 })
		local seatCols = { palette[1], palette[2], palette[3], palette[4] }
		Props.grandstand(decoF, cf, length, seatCols, palette[(i % #palette) + 1], rng)
	end
	standAt(1, -1, 80)
	standAt(1, 1, 80)
	standAt(math.floor(n * 0.33), -1, 50)
	standAt(math.floor(n * 0.66), 1, 50)

	-- ── 8. Theme world ──────────────────────────────────────────────────
	local ctx: BuildContext = {
		map = map,
		folder = folder,
		samples = samples,
		total = total,
		halfW = halfW,
		rng = rng,
		kindAt = kindAt,
		curvature = curvature,
		isCheckpointNear = isCheckpointNear,
		reserved = reserved,
	}
	local themeModule = Themes:FindFirstChild(map.theme)
	if themeModule and themeModule:IsA("ModuleScript") then
		local theme = require(themeModule) :: any
		theme.build(ctx)
	end

	return {
		map = map,
		folder = folder,
		samples = samples,
		total = total,
		width = W,
		checkpoints = checkpoints,
		grid = grid,
		sectionOf = function(i: number): string
			return sectionFor(map, samples[wrap(i)].segment).name
		end,
	}
end

return TrackBuilder
