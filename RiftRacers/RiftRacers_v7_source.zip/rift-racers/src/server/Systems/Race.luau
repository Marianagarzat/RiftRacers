--!strict
-- Server-authoritative race flow: local-server queue → grid → intro →
-- countdown → racing (checkpoint/lap validation, standings, anti-cheat) →
-- results → back to the Nexus.
--
-- Phase 1 runs one race at a time per server in "Free For All".
-- Phase 4 replaces the queue with MatchmakingService + team modes.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage.Shared.Config)
local Net = require(ReplicatedStorage.Shared.Net)
local Format = require(ReplicatedStorage.Shared.Util.Format)
local Types = require(ReplicatedStorage.Shared.Types)
local MapDefinitions = require(ReplicatedStorage.Shared.MapDefinitions)
local World = require(script.Parent.World)
local Vehicles = require(script.Parent.Vehicles)
local TrackBuilder = require(script.Parent.Parent.Builders.TrackBuilder)

type TrackData = TrackBuilder.TrackData
type RacePhase = Types.RacePhase

local RC = Config.Race

type Racer = {
	player: Player,
	userId: number,
	name: string,
	slot: number,
	car: Model?,
	chassis: BasePart?,
	nextCp: number, -- 0-based gate index to cross next
	passed: number, -- total valid gate crossings
	lapsDone: number,
	lapStart: number,
	lastLap: number?,
	bestLap: number?,
	finished: boolean,
	finishTime: number?,
	dnf: boolean,
	returned: boolean,
	lastPos: Vector3,
	lastCpCFrame: CFrame,
	recoverReadyAt: number,
	graceUntil: number,
	windowStart: number,
	windowPos: Vector3,
	strikes: number,
	lastStrikeAt: number,
	position: number,
	seatConn: RBXScriptConnection?,
	charConn: RBXScriptConnection?,
}

local Race = {}

local phase: RacePhase = "Idle"
local raceId = 0
local track: TrackData
local goTime = 0
local introStart = 0
local firstFinishAt: number? = nil
local racers: { [Player]: Racer } = {}
local order: { Racer } = {}
local queue: { Player } = {}
local queueDeadline: number? = nil
local recentWinners: { string } = {}
-- voting
local voteEntrants: { Player } = {}
local voteOptions: { string } = {}
local votes: { [number]: string } = {} -- userId → mapId
local voteEndsAt = 0
local voteRound = 0
local removeFromVote: (Player) -> () -- assigned below (used by leaveQueue)
local rng = Random.new()

local function now(): number
	return Workspace:GetServerTimeNow()
end

local function inQueue(p: Player): number?
	return table.find(queue, p)
end

-- ── Payload builders ──────────────────────────────────────────────────────
local function racerInfos(): { Types.RacerInfo }
	local list = {}
	for _, r in order do
		if not r.returned then
			table.insert(list, { userId = r.userId, name = r.name })
		end
	end
	return list
end

local function statePayload(): Types.RaceStatePayload
	return {
		phase = phase,
		raceId = raceId,
		mapId = if track then track.map.id else RC.DefaultMap,
		mapName = if track then track.map.displayName else "",
		modeName = "FREE FOR ALL",
		laps = RC.Laps,
		goTime = goTime,
		introStart = introStart,
		racers = racerInfos(),
		checkpointCount = if track then #track.checkpoints else 0,
	}
end

local function broadcastState()
	Net.fireAll("RaceState", statePayload())
end

local function sendProgress(r: Racer, event: string?)
	local cp = track.checkpoints[r.nextCp + 1]
	local payload: Types.ProgressPayload = {
		raceId = raceId,
		lap = math.min(r.lapsDone + 1, RC.Laps),
		nextCheckpoint = r.nextCp,
		lastLapTime = r.lastLap,
		bestLapTime = r.bestLap,
		finished = r.finished,
		finishTime = r.finishTime,
		section = if cp then cp.section else nil,
		event = event,
	}
	Net.fireClient("RaceProgress", r.player, payload)
end

local function sendQueueState(p: Player)
	local payload: Types.QueuePayload = {
		inQueue = inQueue(p) ~= nil,
		count = #queue,
		max = RC.MaxPlayers,
		startsAt = if phase == "Idle" then queueDeadline else nil,
		raceRunning = phase ~= "Idle",
	}
	Net.fireClient("QueueState", p, payload)
end

local function broadcastQueue()
	for _, p in Players:GetPlayers() do
		sendQueueState(p)
	end
	local label = World.lobby.statusLabel
	if phase == "Voting" then
		label.Text = string.format("VOTING · %d RACERS · %ds", #voteEntrants, math.max(0, math.ceil(voteEndsAt - now())))
	elseif phase ~= "Idle" then
		label.Text = if #queue > 0 then string.format("RACE LIVE · %d QUEUED FOR NEXT", #queue) else "RACE LIVE · JOIN FOR NEXT RACE"
	elseif #queue > 0 and queueDeadline then
		label.Text = string.format("QUEUE %d/%d · GO IN %ds", #queue, RC.MaxPlayers, math.max(0, math.ceil(queueDeadline - now())))
	else
		label.Text = "OPEN · STEP ON THE PAD"
	end
end

local function notice(p: Player, text: string, kind: string?)
	Net.fireClient("Notice", p, text, kind or "info")
end

-- ── Queue ─────────────────────────────────────────────────────────────────
local function joinQueue(p: Player)
	if racers[p] and phase ~= "Idle" then
		return
	end
	if table.find(voteEntrants, p) then
		return
	end
	if inQueue(p) then
		return
	end
	table.insert(queue, p)
	if phase == "Idle" then
		local t = now()
		if not queueDeadline then
			queueDeadline = t + RC.QueueSeconds
		end
		if #queue >= RC.MaxPlayers then
			queueDeadline = math.min(queueDeadline :: number, t + RC.QueueFullStartSeconds)
		end
	end
	broadcastQueue()
end

local function leaveQueue(p: Player)
	if phase == "Voting" then
		removeFromVote(p)
	end
	local idx = inQueue(p)
	if idx then
		table.remove(queue, idx)
	end
	if #queue == 0 then
		queueDeadline = nil
	end
	broadcastQueue()
end

-- ── Race lifecycle ───────────────────────────────────────────────────────
local function cleanupRacer(r: Racer)
	if r.seatConn then
		r.seatConn:Disconnect()
		r.seatConn = nil
	end
	if r.charConn then
		r.charConn:Disconnect()
		r.charConn = nil
	end
	Vehicles.destroy(r.car)
	r.car = nil
	r.chassis = nil
end

local function returnToLobby(r: Racer)
	if r.returned then
		return
	end
	r.returned = true
	cleanupRacer(r)
	if r.player.Parent == Players then
		pcall(function()
			r.player:LoadCharacterAsync()
		end)
		Net.fireClient("RaceState", r.player, {
			phase = "Idle",
			raceId = raceId,
			mapId = track.map.id,
			mapName = track.map.displayName,
			modeName = "FREE FOR ALL",
			laps = RC.Laps,
			goTime = 0,
			introStart = 0,
			racers = {},
			checkpointCount = 0,
		} :: Types.RaceStatePayload)
	end
end

local function watchSeat(r: Racer)
	local car = r.car
	if not car then
		return
	end
	local seat = car:FindFirstChild("DriverSeat") :: Seat?
	if not seat then
		return
	end
	r.seatConn = seat:GetPropertyChangedSignal("Occupant"):Connect(function()
		if seat.Occupant == nil and (phase == "Intro" or phase == "Racing") and not r.returned then
			task.delay(0.3, function()
				if r.car and seat.Occupant == nil and not r.returned and r.player.Parent then
					Vehicles.seat(r.player, r.car)
				end
			end)
		end
	end)
	-- Respawned character (reset / death) → put them back in their car.
	r.charConn = r.player.CharacterAdded:Connect(function()
		if (phase == "Intro" or phase == "Racing") and r.car and not r.returned then
			task.wait(0.2)
			if r.car then
				Vehicles.seat(r.player, r.car)
			end
		end
	end)
end

local function computeStandings()
	table.sort(order, function(a: Racer, b: Racer): boolean
		if a.finished ~= b.finished then
			return a.finished
		end
		if a.finished and b.finished then
			return (a.finishTime :: number) < (b.finishTime :: number)
		end
		if a.dnf ~= b.dnf then
			return not a.dnf
		end
		if a.passed ~= b.passed then
			return a.passed > b.passed
		end
		local ga = track.checkpoints[a.nextCp + 1].cframe.Position
		local gb = track.checkpoints[b.nextCp + 1].cframe.Position
		local da = if a.chassis then (a.chassis.Position - ga).Magnitude else math.huge
		local db = if b.chassis then (b.chassis.Position - gb).Magnitude else math.huge
		if da ~= db then
			return da < db
		end
		return a.slot < b.slot
	end)
	for i, r in order do
		r.position = i
	end
end

local function pushWinner(text: string)
	table.insert(recentWinners, 1, text)
	while #recentWinners > 5 do
		table.remove(recentWinners)
	end
	for i, row in World.lobby.winnerRows do
		row.Text = recentWinners[i] or ""
	end
end

local function endRace()
	if phase ~= "Racing" then
		return
	end
	phase = "Results"
	computeStandings()
	local results: { Types.ResultRow } = {}
	for _, r in order do
		table.insert(results, {
			userId = r.userId,
			name = r.name,
			position = r.position,
			finished = r.finished,
			totalTime = r.finishTime,
			bestLap = r.bestLap,
		})
	end
	local winner = order[1]
	if winner and winner.finished then
		Net.fireAll("Celebrate", winner.name, track.map.displayName)
		pushWinner(string.format("🏆  %s  ·  %s  ·  %s", winner.name, track.map.displayName, Format.raceTime(winner.finishTime)))
	end
	broadcastState()
	local anyoneWatching = false
	for _, r in order do
		if r.player.Parent == Players and not r.returned then
			anyoneWatching = true
			Net.fireClient("RaceResults", r.player, results)
		end
	end
	local thisRace = raceId
	task.delay(if anyoneWatching then RC.ResultsSeconds else 0, function()
		if raceId ~= thisRace or (phase :: RacePhase) ~= "Results" then
			return
		end
		for _, r in order do
			returnToLobby(r)
		end
		Vehicles.clearAll()
		racers = {}
		order = {}
		phase = "Idle"
		firstFinishAt = nil
		broadcastState()
		if #queue > 0 then
			queueDeadline = now() + RC.QueueSeconds
		end
		broadcastQueue()
	end)
end

local function beginRacing(thisRace: number)
	if raceId ~= thisRace or phase ~= "Intro" then
		return
	end
	phase = "Racing"
	local t = now()
	for _, r in order do
		if r.car and r.chassis then
			Vehicles.release(r.car, r.player)
			r.lastPos = r.chassis.Position
			r.windowPos = r.lastPos
			r.windowStart = t
			r.lapStart = goTime
		end
	end
	broadcastState()
	broadcastQueue()
end

local function startRace(players: { Player }, mapId: string)
	raceId += 1
	phase = "Intro"
	track = World.loadMap(mapId)
	racers = {}
	order = {}
	firstFinishAt = nil
	local t = now()
	introStart = t
	goTime = t + RC.IntroSeconds + RC.CountdownSeconds

	for slot, p in players do
		local gridCf = track.grid[slot]
		local car = Vehicles.spawn(p, slot, gridCf)
		local r: Racer = {
			player = p,
			userId = p.UserId,
			name = p.DisplayName,
			slot = slot,
			car = car,
			chassis = car.PrimaryPart,
			nextCp = 0,
			passed = 0,
			lapsDone = 0,
			lapStart = goTime,
			lastLap = nil,
			bestLap = nil,
			finished = false,
			finishTime = nil,
			dnf = false,
			returned = false,
			lastPos = gridCf.Position,
			lastCpCFrame = gridCf,
			recoverReadyAt = 0,
			graceUntil = goTime + 2,
			windowStart = goTime,
			windowPos = gridCf.Position,
			strikes = 0,
			lastStrikeAt = 0,
			position = slot,
			seatConn = nil,
			charConn = nil,
		}
		racers[p] = r
		table.insert(order, r)
	end
	-- Seat everyone (may yield on character load) — in parallel.
	for _, r in order do
		task.spawn(function()
			if r.car then
				Vehicles.seat(r.player, r.car)
				watchSeat(r)
			end
		end)
	end
	broadcastState()
	for _, r in order do
		sendProgress(r, nil)
	end
	broadcastQueue()
	local thisRace = raceId
	task.delay(goTime - now(), beginRacing, thisRace)
end

local function recover(r: Racer, reason: string?)
	local t = now()
	if t < r.recoverReadyAt or r.returned then
		return
	end
	r.recoverReadyAt = t + RC.RecoverCooldown
	local lateral = rng:NextNumber(-8, 8)
	local base = r.lastCpCFrame
	if r.passed > 0 then
		base = base * CFrame.new(lateral, 3.4, -8)
	end
	r.graceUntil = t + 2.5
	r.lastPos = base.Position
	r.windowPos = base.Position
	r.windowStart = t
	Net.fireClient("Recovered", r.player, base)
	if reason then
		notice(r.player, reason, "warn")
	end
end

-- Gate crossing test on the segment lastPos → pos (robust at any speed).
local function crossed(cp: TrackBuilder.Checkpoint, from: Vector3, to: Vector3): boolean
	local a = cp.cframe:PointToObjectSpace(from)
	local b = cp.cframe:PointToObjectSpace(to)
	-- travel direction is -Z in gate space
	if not (a.Z > 0 and b.Z <= 0) then
		return false
	end
	local f = a.Z / (a.Z - b.Z)
	local hit = a:Lerp(b, f)
	return math.abs(hit.X) <= cp.halfWidth + 6 and hit.Y > -8 and hit.Y < 34
end

local function onGate(r: Racer, t: number)
	local cpCount = #track.checkpoints
	local gate = r.nextCp
	if gate == 0 and r.passed == 0 then
		-- crossing the start line after GO; lap 1 timing already began at GO
		r.passed = 1
		r.nextCp = 1 % cpCount
		r.lastCpCFrame = track.checkpoints[1].cframe
		sendProgress(r, "start")
		return
	end
	if gate == 0 then
		local lapTime = t - r.lapStart
		if lapTime < RC.MinLapSeconds then
			-- impossible lap: refuse it and make them drive it again
			r.lapStart = t
			r.nextCp = 1 % cpCount
			sendProgress(r, "invalid")
			notice(r.player, "Lap invalidated", "warn")
			warn(string.format("[RiftRacers] %s: rejected %.2fs lap", r.player.Name, lapTime))
			return
		end
		r.lapsDone += 1
		r.passed += 1
		r.lastLap = lapTime
		if not r.bestLap or lapTime < (r.bestLap :: number) then
			r.bestLap = lapTime
		end
		r.lapStart = t
		r.nextCp = 1 % cpCount
		r.lastCpCFrame = track.checkpoints[1].cframe
		if r.lapsDone >= RC.Laps then
			r.finished = true
			r.finishTime = t - goTime
			if not firstFinishAt then
				firstFinishAt = t
			end
			sendProgress(r, "finish")
		else
			sendProgress(r, "lap")
		end
		return
	end
	r.passed += 1
	r.lastCpCFrame = track.checkpoints[gate + 1].cframe
	r.nextCp = (gate + 1) % cpCount
	sendProgress(r, "checkpoint")
end

local function tickRacer(r: Racer, t: number)
	local chassis = r.chassis
	if not chassis or r.returned or r.dnf then
		return
	end
	local pos = chassis.Position

	-- Gate progression (finished cars keep driving but stop scoring)
	if not r.finished then
		local cp = track.checkpoints[r.nextCp + 1]
		if crossed(cp, r.lastPos, pos) then
			onGate(r, t)
		end
	end
	r.lastPos = pos

	-- Fell off the world
	if pos.Y < track.map.killY then
		recover(r, nil)
		return
	end

	-- Teleport / speed sanity check over 0.5 s windows (latency tolerant)
	local dt = t - r.windowStart
	if dt >= 0.5 then
		local speed = (pos - r.windowPos).Magnitude / dt
		if t > r.graceUntil and speed > RC.MaxPlausibleSpeed then
			r.strikes += 1
			r.lastStrikeAt = t
			if r.strikes >= RC.SpeedStrikesBeforeReset then
				r.strikes = 0
				recover(r, "Movement check failed — reset to checkpoint")
				warn(string.format("[RiftRacers] %s moved %.0f studs/s", r.player.Name, speed))
			end
		elseif t - r.lastStrikeAt > 6 then
			r.strikes = 0
		end
		r.windowStart = t
		r.windowPos = pos
	end
end

local lastStandings = 0
local function onHeartbeat()
	if phase ~= "Racing" then
		return
	end
	local t = now()
	local active = 0
	local unfinished = 0
	for _, r in order do
		tickRacer(r, t)
		if not r.dnf and not r.returned then
			active += 1
			if not r.finished then
				unfinished += 1
			end
		end
	end

	if t - lastStandings >= 1 / RC.StandingsHz then
		lastStandings = t
		computeStandings()
		local rows: { Types.StandingRow } = {}
		for _, r in order do
			table.insert(rows, { u = r.userId, p = r.position, l = math.min(r.lapsDone + 1, RC.Laps), f = r.finished })
		end
		local remote = Net.get("Standings")
		for _, r in order do
			if r.player.Parent == Players and not r.returned then
				remote:FireClient(r.player, rows)
			end
		end
	end

	if active == 0 or unfinished == 0 then
		endRace()
	elseif firstFinishAt and t - (firstFinishAt :: number) > RC.FinishGraceSeconds then
		endRace()
	elseif t - goTime > RC.MaxRaceSeconds then
		endRace()
	end
end

-- ── Map voting ───────────────────────────────────────────────────────────
local function votePayload(winner: string?, tieBroken: boolean?): Types.VotePayload
	local byMap: { [string]: { number } } = {}
	for _, id in voteOptions do
		byMap[id] = {}
	end
	for uid, id in votes do
		if byMap[id] then
			table.insert(byMap[id], uid)
		end
	end
	local entrants = {}
	for _, p in voteEntrants do
		table.insert(entrants, { userId = p.UserId, name = p.DisplayName })
	end
	return {
		active = phase == "Voting",
		options = voteOptions,
		endsAt = voteEndsAt,
		votes = byMap,
		entrants = entrants,
		winner = winner,
		tieBroken = tieBroken,
	}
end

local function broadcastVote(winner: string?, tieBroken: boolean?)
	Net.fireAll("VoteState", votePayload(winner, tieBroken))
end

local function pickOptions(): { string }
	local pool = table.clone(MapDefinitions.Order)
	local out = {}
	while #out < math.min(RC.VoteOptions, #MapDefinitions.Order) do
		table.insert(out, table.remove(pool, rng:NextInteger(1, #pool)) :: string)
	end
	return out
end

-- Most votes wins. Ties (including "nobody voted") are broken by a uniform
-- random pick among the tied maps, decided on the server.
local function tally(): (string, boolean)
	local counts: { [string]: number } = {}
	for _, id in voteOptions do
		counts[id] = 0
	end
	for _, id in votes do
		counts[id] = (counts[id] or 0) + 1
	end
	local best = -1
	local tied: { string } = {}
	for _, id in voteOptions do
		local c = counts[id]
		if c > best then
			best = c
			tied = { id }
		elseif c == best then
			table.insert(tied, id)
		end
	end
	return tied[rng:NextInteger(1, #tied)], #tied > 1
end

function removeFromVote(p: Player)
	local i = table.find(voteEntrants, p)
	if i then
		table.remove(voteEntrants, i)
		votes[p.UserId] = nil
		broadcastVote(nil, nil)
	end
end

local function beginVoting(entrants: { Player })
	phase = "Voting"
	voteRound += 1
	local round = voteRound
	voteEntrants = entrants
	votes = {}
	voteOptions = pickOptions()
	voteEndsAt = now() + RC.VoteSeconds
	broadcastVote(nil, nil)
	broadcastQueue()
	task.spawn(function()
		while phase == "Voting" and voteRound == round do
			task.wait(0.2)
			if #voteEntrants == 0 then
				phase = "Idle"
				broadcastVote(nil, nil)
				broadcastQueue()
				return
			end
			local voted = 0
			for _ in votes do
				voted += 1
			end
			-- everyone voted → close early (short grace so the last click shows)
			if voted >= #voteEntrants and voteEndsAt - now() > 1.5 then
				voteEndsAt = now() + 1.5
				broadcastVote(nil, nil)
			end
			if now() >= voteEndsAt then
				break
			end
		end
		if phase ~= "Voting" or voteRound ~= round then
			return
		end
		local winner, tieBroken = tally()
		phase = "Intro" -- lock: no more votes, no new entrants
		broadcastVote(winner, tieBroken)
		task.wait(RC.VoteRevealSeconds)
		local entrantsNow = {}
		for _, p in voteEntrants do
			if p.Parent == Players then
				table.insert(entrantsNow, p)
			end
		end
		voteEntrants = {}
		if #entrantsNow == 0 then
			phase = "Idle"
			broadcastQueue()
			return
		end
		startRace(entrantsNow, winner)
	end)
end

local function queueLoop()
	local ticks = 0
	while true do
		task.wait(0.25)
		ticks += 1
		-- drop players who left
		for i = #queue, 1, -1 do
			if queue[i].Parent ~= Players then
				table.remove(queue, i)
			end
		end
		if phase == "Idle" and #queue == 0 then
			queueDeadline = nil
		end
		if phase == "Idle" and #queue >= RC.MinPlayers and queueDeadline and now() >= queueDeadline then
			local entrants = {}
			for i = 1, math.min(#queue, RC.MaxPlayers) do
				table.insert(entrants, queue[i])
			end
			for _ = 1, #entrants do
				table.remove(queue, 1)
			end
			queueDeadline = nil
			beginVoting(entrants)
		end
		if ticks % 4 == 0 then
			broadcastQueue() -- 1 Hz refresh of the portal sign + queue cards
		end
	end
end

-- ── Remote handlers (all inputs validated, rate limited) ────────────────
local lastRequest: { [Player]: number } = {}
local function rateOk(p: Player, minGap: number): boolean
	local t = os.clock()
	local last = lastRequest[p]
	if last and t - last < minGap then
		return false
	end
	lastRequest[p] = t
	return true
end

function Race.init()
	Net.onServer("RequestJoinQueue", function(p: Player)
		if rateOk(p, 0.4) then
			joinQueue(p)
		end
	end)
	Net.onServer("RequestVote", function(p: Player, mapId: unknown)
		if phase ~= "Voting" or typeof(mapId) ~= "string" or not rateOk(p, 0.15) then
			return
		end
		if not table.find(voteEntrants, p) or not table.find(voteOptions, mapId :: string) then
			return
		end
		votes[p.UserId] = mapId :: string
		broadcastVote(nil, nil)
	end)
	Net.onServer("RequestLeaveQueue", function(p: Player)
		if rateOk(p, 0.4) then
			leaveQueue(p)
		end
	end)
	Net.onServer("RequestRecover", function(p: Player)
		local r = racers[p]
		if r and phase == "Racing" then
			recover(r, nil)
		end
	end)
	Net.onServer("RequestReturnToLobby", function(p: Player)
		local r = racers[p]
		if not r or not rateOk(p, 0.4) then
			return
		end
		if phase == "Racing" and not r.finished then
			r.dnf = true -- quitting never earns completion
		end
		if phase == "Intro" then
			r.dnf = true
		end
		returnToLobby(r)
	end)

	World.lobby.portalPrompt.Triggered:Connect(function(p: Player)
		if rateOk(p, 0.4) then
			joinQueue(p)
		end
	end)

	Players.PlayerAdded:Connect(function(p: Player)
		Net.fireClient("RaceState", p, statePayload())
		sendQueueState(p)
	end)
	Players.PlayerRemoving:Connect(function(p: Player)
		lastRequest[p] = nil
		leaveQueue(p)
		removeFromVote(p)
		local r = racers[p]
		if r then
			r.dnf = true
			r.returned = true
			cleanupRacer(r)
		end
	end)
end

function Race.start()
	for _, p in Players:GetPlayers() do
		Net.fireClient("RaceState", p, statePayload())
		sendQueueState(p)
	end
	RunService.Heartbeat:Connect(onHeartbeat)
	task.spawn(queueLoop)
end

return Race
