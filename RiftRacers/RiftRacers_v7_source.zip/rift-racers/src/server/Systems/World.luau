--!strict
-- Builds the lobby at boot and loads race maps on demand (only the voted
-- map exists in the world at any time — keeps memory low on every device).

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local MapDefinitions = require(ReplicatedStorage.Shared.MapDefinitions)
local LobbyBuilder = require(script.Parent.Parent.Builders.LobbyBuilder)
local TrackBuilder = require(script.Parent.Parent.Builders.TrackBuilder)

local World = {}

World.lobby = (nil :: any) :: LobbyBuilder.LobbyHandles
local tracksFolder: Folder
local current: TrackBuilder.TrackData? = nil

local function countParts(root: Instance): number
	local parts = 0
	for _, d in root:GetDescendants() do
		if d:IsA("BasePart") then
			parts += 1
		end
	end
	return parts
end

function World.init()
	local t0 = os.clock()
	World.lobby = LobbyBuilder.build(Workspace)
	tracksFolder = Instance.new("Folder")
	tracksFolder.Name = "Tracks"
	tracksFolder.Parent = Workspace
	print(string.format("[RiftRacers] Lobby built in %.2fs · %d parts", os.clock() - t0, countParts(World.lobby.model)))
end

-- Returns the requested map, building it (and tearing down the previous one)
-- if necessary.
function World.loadMap(mapId: string): TrackBuilder.TrackData
	local existing = current
	if existing and existing.map.id == mapId and existing.folder.Parent then
		return existing
	end
	local def = MapDefinitions.Maps[mapId]
	assert(def, "Unknown map " .. mapId)
	if existing then
		existing.folder:Destroy()
	end
	Workspace.Terrain:Clear()
	local t0 = os.clock()
	local data = TrackBuilder.build(def, tracksFolder)
	current = data
	print(string.format("[RiftRacers] %s built in %.2fs · %d parts", def.displayName, os.clock() - t0, countParts(data.folder)))
	return data
end

function World.current(): TrackBuilder.TrackData?
	return current
end

return World
