--!strict
-- One list of remotes. The server creates them in Net.serverInit(); clients
-- resolve them lazily. Adding a remote = one line here.

local RunService = game:GetService("RunService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local FOLDER_NAME = "RiftRemotes"

local RELIABLE = {
	-- client → server
	"RequestJoinQueue",
	"RequestLeaveQueue",
	"RequestRecover",
	"RequestReturnToLobby",
	"RequestVote",
	-- server → client
	"QueueState",
	"RaceState",
	"RaceProgress",
	"RaceResults",
	"Recovered",
	"Notice",
	"VoteState",
	"Celebrate",
}
local UNRELIABLE = {
	"Standings", -- server → client, 4 Hz, latest value wins
}

local Net = {}

local cache: { [string]: RemoteEvent | UnreliableRemoteEvent } = {}

function Net.serverInit()
	assert(RunService:IsServer(), "Net.serverInit is server-only")
	local folder = Instance.new("Folder")
	folder.Name = FOLDER_NAME
	for _, name in RELIABLE do
		local r = Instance.new("RemoteEvent")
		r.Name = name
		r.Parent = folder
		cache[name] = r
	end
	for _, name in UNRELIABLE do
		local r = Instance.new("UnreliableRemoteEvent")
		r.Name = name
		r.Parent = folder
		cache[name] = r
	end
	folder.Parent = ReplicatedStorage
end

local function resolve(name: string): RemoteEvent
	local found = cache[name]
	if found then
		return found :: any
	end
	local folder = ReplicatedStorage:WaitForChild(FOLDER_NAME, 30)
	assert(folder, "RiftRemotes folder missing")
	local remote = folder:WaitForChild(name, 30)
	assert(remote, "Remote missing: " .. name)
	cache[name] = remote :: any
	return remote :: any
end

-- Typed-ish helpers. Payload validation happens in each server handler.
function Net.get(name: string): RemoteEvent
	return resolve(name)
end

function Net.fireClient(name: string, player: Player, ...: any)
	resolve(name):FireClient(player, ...)
end

function Net.fireAll(name: string, ...: any)
	resolve(name):FireAllClients(...)
end

function Net.fireServer(name: string, ...: any)
	resolve(name):FireServer(...)
end

function Net.onServer(name: string, handler: (Player, ...any) -> ())
	resolve(name).OnServerEvent:Connect(handler)
end

function Net.onClient(name: string, handler: (...any) -> ())
	resolve(name).OnClientEvent:Connect(handler)
end

return Net
