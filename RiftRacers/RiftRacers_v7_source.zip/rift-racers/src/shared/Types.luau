--!strict
-- Payloads that cross the client/server boundary.

export type RacePhase = "Idle" | "Voting" | "Intro" | "Racing" | "Results"

export type RacerInfo = {
	userId: number,
	name: string,
}

export type RaceStatePayload = {
	phase: RacePhase,
	raceId: number,
	mapId: string,
	mapName: string,
	modeName: string,
	laps: number,
	goTime: number, -- workspace:GetServerTimeNow() timestamp of GO
	introStart: number,
	racers: { RacerInfo },
	checkpointCount: number,
}

export type ProgressPayload = {
	raceId: number,
	lap: number, -- 1-based lap currently being driven (capped at laps)
	nextCheckpoint: number, -- 0 = start/finish gate
	lastLapTime: number?,
	bestLapTime: number?,
	finished: boolean,
	finishTime: number?,
	section: string?,
	event: string?, -- "checkpoint" | "lap" | "finish" | "start" | "invalid"
}

export type StandingRow = {
	u: number, -- userId
	p: number, -- position
	l: number, -- lap
	f: boolean, -- finished
}

export type ResultRow = {
	userId: number,
	name: string,
	position: number,
	finished: boolean,
	totalTime: number?,
	bestLap: number?,
}

export type VotePayload = {
	active: boolean,
	options: { string }, -- map ids
	endsAt: number, -- server time
	votes: { [string]: { number } }, -- mapId → userIds
	entrants: { RacerInfo },
	winner: string?,
	tieBroken: boolean?,
}

export type QueuePayload = {
	inQueue: boolean,
	count: number,
	max: number,
	startsAt: number?, -- server time, nil while a race is running
	raceRunning: boolean,
}

return nil
