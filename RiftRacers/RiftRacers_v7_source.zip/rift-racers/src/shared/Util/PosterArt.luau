--!strict
-- Draws an illustrated "travel poster" for a map using only UI shapes
-- (gradients, circles, rotated frames). Used for voting cards, the lobby
-- World Preview boards and the worlds gallery — no image assets required.

local MapDefinitions = require(script.Parent.Parent.MapDefinitions)

local PosterArt = {}

local function frame(parent: Instance, props: { [string]: any }): Frame
	local f = Instance.new("Frame")
	f.BorderSizePixel = 0
	for k, v in props do
		(f :: any)[k] = v
	end
	f.Parent = parent
	return f
end

local function round(f: GuiObject, scale: number?)
	local c = Instance.new("UICorner")
	c.CornerRadius = UDim.new(scale or 1, 0)
	c.Parent = f
end

local function cityArt(root: Frame, p: MapDefinitions.Poster, rng: Random)
	-- sun with stripes
	local sun = frame(root, { AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.55), Size = UDim2.fromScale(0.62, 0.62), BackgroundColor3 = Color3.new(1, 1, 1), SizeConstraint = Enum.SizeConstraint.RelativeXX })
	round(sun)
	local g = Instance.new("UIGradient")
	g.Color = ColorSequence.new(p.sun, p.accent2)
	g.Rotation = 90
	g.Parent = sun
	for i = 0, 4 do
		frame(sun, { Position = UDim2.fromScale(0, 0.55 + i * 0.09), Size = UDim2.new(1, 0, 0.03 + i * 0.008, 0), BackgroundColor3 = p.skyBottom:Lerp(p.skyTop, 0.3) })
	end
	-- skyline
	local x = 0
	while x < 1 do
		local w = rng:NextNumber(0.06, 0.12)
		local h = rng:NextNumber(0.25, 0.62)
		local b = frame(root, { AnchorPoint = Vector2.new(0, 1), Position = UDim2.fromScale(x, 0.82), Size = UDim2.fromScale(w, h), BackgroundColor3 = p.ground })
		for k = 1, math.floor(h * 14) do
			if rng:NextNumber() < 0.5 then
				frame(b, { Position = UDim2.fromScale(rng:NextNumber(0.15, 0.7), k / (h * 14 + 1)), Size = UDim2.fromScale(0.18, 0.02), BackgroundColor3 = if rng:NextNumber() < 0.5 then p.accent else p.accent2 })
			end
		end
		x += w + 0.01
	end
	-- glowing road with perspective lines
	local road = frame(root, { AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.fromScale(0.5, 0.82), Size = UDim2.fromScale(1, 0.18), BackgroundColor3 = Color3.fromRGB(20, 10, 40) })
	for _, sx in { -1, 1 } do
		frame(road, { AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.fromScale(0.5 + sx * 0.25, 0), Size = UDim2.fromScale(0.012, 1.4), Rotation = sx * -35, BackgroundColor3 = p.accent })
	end
end

local function beachArt(root: Frame, p: MapDefinitions.Poster, rng: Random)
	local sun = frame(root, { AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.6), Size = UDim2.fromScale(0.5, 0.5), BackgroundColor3 = p.sun, SizeConstraint = Enum.SizeConstraint.RelativeXX })
	round(sun)
	local sea = frame(root, { Position = UDim2.fromScale(0, 0.6), Size = UDim2.fromScale(1, 0.4), BackgroundColor3 = p.ground })
	local sg = Instance.new("UIGradient")
	sg.Color = ColorSequence.new(p.ground, p.ground:Lerp(Color3.new(0, 0, 0.3), 0.4))
	sg.Rotation = 90
	sg.Parent = sea
	for i = 1, 6 do
		frame(sea, { AnchorPoint = Vector2.new(0.5, 0), Position = UDim2.fromScale(0.5, i * 0.08), Size = UDim2.fromScale(0.42 - i * 0.05, 0.025), BackgroundColor3 = p.sun, BackgroundTransparency = 0.2 })
	end
	-- sand + palm silhouettes
	local sand = frame(root, { Position = UDim2.fromScale(-0.1, 0.84), Size = UDim2.fromScale(1.2, 0.3), BackgroundColor3 = Color3.fromRGB(255, 215, 150) })
	round(sand, 0.5)
	for _, px in { 0.12, 0.86 } do
		local trunk = frame(root, { AnchorPoint = Vector2.new(0.5, 1), Position = UDim2.fromScale(px, 0.9), Size = UDim2.fromScale(0.025, 0.55), Rotation = if px < 0.5 then 8 else -8, BackgroundColor3 = p.accent2 })
		for k = 0, 5 do
			frame(trunk, { AnchorPoint = Vector2.new(0, 0.5), Position = UDim2.fromScale(0.5, 0), Size = UDim2.new(0, 60, 0, 8), Rotation = k * 60 + rng:NextNumber(-10, 10), BackgroundColor3 = p.accent2 })
		end
	end
	-- birds
	for _ = 1, 3 do
		frame(root, { Position = UDim2.fromScale(rng:NextNumber(0.25, 0.75), rng:NextNumber(0.12, 0.3)), Size = UDim2.fromOffset(14, 3), Rotation = 20, BackgroundColor3 = p.accent2 })
	end
end

local function dreamArt(root: Frame, p: MapDefinitions.Poster, rng: Random)
	local colors = { Color3.fromRGB(255, 90, 110), Color3.fromRGB(255, 160, 70), Color3.fromRGB(255, 225, 90), Color3.fromRGB(120, 220, 120), Color3.fromRGB(90, 190, 255), Color3.fromRGB(140, 120, 255) }
	for i, c in colors do
		local s = 0.95 - (i - 1) * 0.08
		local ring = frame(root, { AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(0.5, 0.82), Size = UDim2.fromScale(s, s), BackgroundTransparency = 1, SizeConstraint = Enum.SizeConstraint.RelativeXX })
		round(ring)
		local st = Instance.new("UIStroke")
		st.Color = c
		st.Thickness = 7
		st.Parent = ring
	end
	for _ = 1, 7 do
		local cx = rng:NextNumber(0, 1)
		local cy = rng:NextNumber(0.65, 0.95)
		for k = 0, 2 do
			local puff = frame(root, { AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(cx + (k - 1) * 0.06, cy - (if k == 1 then 0.04 else 0)), Size = UDim2.fromScale(0.16, 0.16), BackgroundColor3 = p.ground, SizeConstraint = Enum.SizeConstraint.RelativeXX })
			round(puff)
		end
	end
	for _ = 1, 10 do
		local star = frame(root, { AnchorPoint = Vector2.new(0.5, 0.5), Position = UDim2.fromScale(rng:NextNumber(0.05, 0.95), rng:NextNumber(0.05, 0.45)), Size = UDim2.fromOffset(8, 8), Rotation = 45, BackgroundColor3 = p.sun })
		local _ = star
	end
	-- castle
	for _, spec in { { 0.42, 0.34 }, { 0.5, 0.42 }, { 0.58, 0.34 } } do
		local t = frame(root, { AnchorPoint = Vector2.new(0.5, 1), Position = UDim2.fromScale(spec[1], 0.72), Size = UDim2.fromScale(0.07, spec[2]), BackgroundColor3 = Color3.fromRGB(255, 240, 250) })
		local roof = frame(t, { AnchorPoint = Vector2.new(0.5, 1), Position = UDim2.fromScale(0.5, 0.05), Size = UDim2.fromScale(1.3, 0.25), BackgroundColor3 = p.accent })
		round(roof, 0.4)
	end
end

-- Builds the poster into `parent` (fills it) and returns the root frame.
function PosterArt.draw(parent: GuiObject | LayerCollector, mapId: string): Frame
	local def = MapDefinitions.Maps[mapId]
	local root = frame(parent, { Name = "Poster", Size = UDim2.fromScale(1, 1), BackgroundColor3 = Color3.new(1, 1, 1), ClipsDescendants = true })
	if not def then
		return root
	end
	local p = def.poster
	local g = Instance.new("UIGradient")
	g.Color = ColorSequence.new(p.skyTop, p.skyBottom)
	g.Rotation = 90
	g.Parent = root
	local rng = Random.new(#mapId * 31)
	if def.theme == "city" then
		cityArt(root, p, rng)
	elseif def.theme == "beach" then
		beachArt(root, p, rng)
	else
		dreamArt(root, p, rng)
	end
	return root
end

return PosterArt
